import { useEffect, useMemo, useState } from "react";
import { ClipboardList, ListFilter, Plus, Search, X } from "lucide-react";
import type { Task, TaskStatus } from "../../types";
import TaskItem from "./TaskItem";
import { cn } from "../../utils/cn";

interface TaskListProps {
  tasks: Task[];
  onToggle: (id: string) => void;
  onCycleStatus: (id: string) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  globalSearch?: string;
}

type FilterKey = "all" | TaskStatus;

const filters: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "in-progress", label: "In Progress" },
  { key: "completed", label: "Done" },
];

export default function TaskList({ tasks, onToggle, onCycleStatus, onEdit, onDelete, onAdd, globalSearch = "" }: TaskListProps) {
  const [filter, setFilter] = useState<FilterKey>("all");
  const [localSearch, setLocalSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);

  // Combine global and local search
  const searchQuery = globalSearch.trim() || localSearch.trim();

  // When global search is active, show all tasks regardless of filter
  useEffect(() => {
    if (globalSearch.trim()) {
      setFilter("all");
    }
  }, [globalSearch]);

  const filtered = useMemo(() => {
    let list = filter === "all" ? tasks : tasks.filter((t) => t.status === filter);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.subject?.toLowerCase().includes(q),
      );
    }
    return list;
  }, [tasks, filter, searchQuery]);

  const counts = useMemo(() => {
    const c = { all: tasks.length, pending: 0, "in-progress": 0, completed: 0 };
    tasks.forEach((t) => { c[t.status]++; });
    return c;
  }, [tasks]);

  const isSearchActive = searchQuery.length > 0;

  return (
    <div className="rounded-3xl border border-slate-100 bg-white shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 px-4 pt-5 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-md shadow-indigo-200">
            <ClipboardList className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 sm:text-lg">Today's Tasks</h2>
            <p className="text-xs text-slate-400">
              {counts.completed} of {counts.all} completed
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSearch((s) => !s)}
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-xl transition sm:hidden",
              showSearch ? "bg-indigo-100 text-indigo-600" : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
            )}
          >
            <Search className="h-[18px] w-[18px]" />
          </button>
          <button
            onClick={onAdd}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg shadow-indigo-200/50 transition hover:shadow-xl hover:shadow-indigo-200/70 sm:px-4 sm:text-sm"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Add Task</span>
          </button>
        </div>
      </div>

      {/* Search bar - show when global search active or local search toggled */}
      <div className={cn("px-4 pt-3 sm:px-6", (showSearch || isSearchActive) ? "block" : "hidden sm:block")}>
        <div className={cn(
          "flex items-center gap-2 rounded-xl border px-3 py-2.5 transition-all",
          isSearchActive
            ? "border-indigo-300 bg-indigo-50/50 ring-2 ring-indigo-100"
            : "border-slate-200 bg-slate-50 focus-within:border-indigo-300 focus-within:ring-2 focus-within:ring-indigo-100"
        )}>
          <Search className={cn("h-4 w-4 shrink-0", isSearchActive ? "text-indigo-500" : "text-slate-400")} />
          <input
            value={globalSearch || localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            placeholder="Search tasks by title or subject..."
            disabled={!!globalSearch}
            className={cn(
              "w-full bg-transparent text-sm outline-none placeholder:text-slate-400",
              globalSearch ? "text-indigo-700" : "text-slate-700"
            )}
          />
          {isSearchActive && (
            <div className="flex items-center gap-1.5">
              <span className="rounded-md bg-indigo-100 px-1.5 py-0.5 text-[10px] font-bold text-indigo-600">
                {filtered.length} found
              </span>
              {!globalSearch && (
                <button
                  onClick={() => setLocalSearch("")}
                  className="shrink-0 rounded-lg p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-600"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto px-4 pt-3.5 pb-1 sm:px-6 hide-scrollbar">
        <ListFilter className="h-4 w-4 shrink-0 text-slate-400 mr-1" />
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            disabled={!!globalSearch}
            className={cn(
              "relative shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all",
              filter === f.key
                ? "bg-slate-900 text-white shadow-sm"
                : "bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-700",
              globalSearch && "opacity-50 cursor-not-allowed"
            )}
          >
            {f.label}
            <span className={cn(
              "ml-1.5 inline-flex h-4 min-w-[16px] items-center justify-center rounded-full px-1 text-[10px] font-bold",
              filter === f.key ? "bg-white/20 text-white" : "bg-slate-200/60 text-slate-400",
            )}>
              {counts[f.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Task list */}
      <div className="space-y-2 p-4 sm:p-6 sm:pt-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-slate-200 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
              {isSearchActive ? (
                <Search className="h-6 w-6 text-slate-300" />
              ) : (
                <ClipboardList className="h-6 w-6 text-slate-300" />
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-400">
                {isSearchActive
                  ? `No tasks match "${searchQuery}"`
                  : "No tasks in this category"}
              </p>
              {!isSearchActive && (
                <button
                  onClick={onAdd}
                  className="mt-2 text-sm font-semibold text-indigo-600 hover:text-indigo-700 hover:underline"
                >
                  + Create a new task
                </button>
              )}
            </div>
          </div>
        ) : (
          filtered.map((task, idx) => (
            <div
              key={task.id}
              className="animate-slideUp"
              style={{ animationDelay: `${idx * 30}ms` }}
            >
              <TaskItem
                task={task}
                onToggle={onToggle}
                onCycleStatus={onCycleStatus}
                onEdit={onEdit}
                onDelete={onDelete}
                highlightQuery={searchQuery}
              />
            </div>
          ))
        )}
      </div>
    </div>
  );
}
