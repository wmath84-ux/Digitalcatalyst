import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import Composer from "./components/Composer";
import Header from "./components/Header";
import Lightbox from "./components/Lightbox";
import MessageList from "./components/MessageList";
import CoursePlayer from "./components/CoursePlayer";
import PreviewBar, { type PreviewMode } from "./components/PreviewBar";
import ScreenshotOverlay, { type ShotRect } from "./components/ScreenshotOverlay";
import Sidebar from "./components/Sidebar";
import { MODELS, SEED_CHATS } from "./lib/data";
import { formatAnswerSheet, type GenerationSpec } from "./lib/engine";
import { tierOf, useElementWidth } from "./lib/tier";
import { buildCourseContext, gradeQuiz, runTutor } from "./ai/tutor";
import { loadStudentModel, saveStudentModel } from "./ai/studentModel";
import type { StudentModel } from "./ai/types";
import { useViewportKeyboard } from "./lib/useViewportKeyboard";
import { courseBridge, getActiveContext, useCourseContextVersion } from "./course/bridge";
import { abortExcept } from "./course/contentService";
import { prefetchActive } from "./ai/courseGrounding";
import type { Attachment, Chat, Message, ThinkingStep } from "./lib/types";
import { clamp, makeScreenshotAttachment, uid } from "./lib/utils";
import { PERF, perf } from "./lib/perf";
import { cn } from "./utils/cn";

/* Graceful visual fallback if DOM capture is unavailable in this browser. */
function fallbackShot(r: ShotRect): Attachment {
  const w = 640;
  const h = Math.max(220, Math.round((640 * r.h) / Math.max(1, r.w)));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#f1efe8";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#e2e0d5";
    for (let x = 20; x < w; x += 28) for (let y = 20; y < h; y += 28) ctx.fillRect(x, y, 2, 2);
    ctx.beginPath();
    ctx.arc(w / 2, h / 2 - 16, 20, 0, Math.PI * 2);
    ctx.fillStyle = "#4f46e5";
    ctx.fill();
    ctx.fillStyle = "#dcdacc";
    ctx.fillRect(w / 2 - 120, h / 2 + 20, 240, 12);
    ctx.fillRect(w / 2 - 78, h / 2 + 42, 156, 12);
    ctx.fillStyle = "#8c8a7d";
    ctx.font = "12px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`Captured area · ${Math.round(r.w)} × ${Math.round(r.h)}`, w / 2, h - 18);
  }
  return makeScreenshotAttachment(canvas.toDataURL("image/png"), Math.round(r.w), Math.round(r.h));
}

function ResizeHandle({ value, shellW, onChange }: { value: number; shellW: number; onChange: (w: number) => void }) {
  const max = Math.max(200, Math.min(560, shellW - 360));
  const onPointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    const sx = e.clientX;
    const w0 = value;
    const move = (ev: PointerEvent) => onChange(clamp(w0 + (sx - ev.clientX), 200, max));
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  return (
    <div
      role="separator"
      aria-orientation="vertical"
      aria-label="Resize chat panel"
      aria-valuenow={Math.round(value)}
      tabIndex={0}
      onPointerDown={onPointerDown}
      onKeyDown={(e) => {
        if (e.key === "ArrowLeft") onChange(clamp(value + 16, 200, max));
        if (e.key === "ArrowRight") onChange(clamp(value - 16, 200, max));
      }}
      className="focus-ring group flex w-[14px] flex-none cursor-col-resize items-center justify-center"
    >
      <div className="h-8 w-[3px] rounded-full bg-[--border-2] transition-colors group-hover:bg-[--accent] group-focus-visible:bg-[--accent]" />
    </div>
  );
}

export default function App() {
  const [chats, setChats] = useState<Chat[]>(SEED_CHATS);
  const [activeId, setActiveId] = useState(SEED_CHATS[0].id);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [shotMode, setShotMode] = useState(false);
  const [lightbox, setLightbox] = useState<Attachment | null>(null);
  const [mode, setMode] = useState<PreviewMode>("full");
  const [playerW, setPlayerW] = useState(380);
  const [sidebarPinned, setSidebarPinned] = useState(false);
  const [studentModel, setStudentModel] = useState<StudentModel>(loadStudentModel);

  const [shellRef, shellW] = useElementWidth<HTMLDivElement>();
  const [frameRef, frameW] = useElementWidth<HTMLDivElement>();
  const [colRef, colW] = useElementWidth<HTMLElement>();

  // Visual-viewport / keyboard system (CSS-variable driven, no re-render).
  useViewportKeyboard();

  /* Course ↔ AI synchronization. The version counter changes only on
     STRUCTURAL events (resource/page/slide), never on playback ticks. */
  const courseVersion = useCourseContextVersion();
  useEffect(() => {
    const ctx = getActiveContext();
    abortExcept(ctx.resource.resourceId); // cancel extraction for stale resources
    prefetchActive(ctx);                  // warm the cache for the open one
  }, [courseVersion]);

  const reducedMotion = useRef(
    typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches
  ).current;

  const chatsRef = useRef(chats);
  chatsRef.current = chats;

  // The adaptive-learning layer: student model, persistence, introspection
  const studentModelRef = useRef(studentModel);
  studentModelRef.current = studentModel;
  useEffect(() => {
    saveStudentModel(studentModel);
  }, [studentModel]);
  useEffect(() => {
    (window as unknown as { __lumen?: unknown }).__lumen = {
      studentModel: () => studentModelRef.current,
      perf,
    };
  }, []);

  const timersRef = useRef(new Map<string, number[]>());
  const intervalsRef = useRef(new Map<string, number>());

  useEffect(
    () => () => {
      timersRef.current.forEach((t) => t.forEach((id) => window.clearTimeout(id)));
      intervalsRef.current.forEach((id) => window.clearInterval(id));
    },
    []
  );

  // Close the drawer with Escape when it's open
  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setDrawerOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawerOpen]);

  const showPlayer = mode === "player" && shellW >= 940;

  // Publish viewport/player mode so context is layout-independent.
  useEffect(() => {
    courseBridge.setViewport({
      playerMode: showPlayer ? "split" : "hidden",
      viewportMode: colW < 400 ? "narrow-panel" : colW < 700 ? "mobile" : colW < 1020 ? "tablet" : "desktop",
      splitRatio: showPlayer && shellW > 0 ? Math.round((playerW / shellW) * 100) / 100 : undefined,
      aiOpen: true,
    });
  }, [showPlayer, colW, playerW, shellW]);
  // Pinned panel: user preference keeps the sidebar docked through narrow
  // widths (down to a sensible floor). Unpinned: auto-dock on wide frames.
  const dockSidebar = mode !== "player" && (sidebarPinned ? frameW >= 520 : frameW >= 900);
  const tier = tierOf(colW || frameW || shellW || 1280);
  const chat = chats.find((c) => c.id === activeId) ?? chats[0];
  const generating = chat.messages.some(
    (m) => m.role === "assistant" && (m.status === "thinking" || m.status === "streaming")
  );
  const draft = drafts[chat.id] ?? "";

  /* ── state helpers ─────────────────────────────────────── */

  const patchChat = (chatId: string, patch: Partial<Chat> | ((c: Chat) => Partial<Chat>)) =>
    setChats((cs) => cs.map((c) => (c.id !== chatId ? c : { ...c, ...(typeof patch === "function" ? patch(c) : patch) })));

  const patchMessage = (chatId: string, msgId: string, patch: Partial<Message> | ((m: Message) => Partial<Message>)) =>
    setChats((cs) =>
      cs.map((c) =>
        c.id !== chatId
          ? c
          : { ...c, messages: c.messages.map((m) => (m.id !== msgId ? m : { ...m, ...(typeof patch === "function" ? patch(m) : patch) })) }
      )
    );

  const clearRun = (msgId: string) => {
    timersRef.current.get(msgId)?.forEach((id) => window.clearTimeout(id));
    timersRef.current.delete(msgId);
    const iv = intervalsRef.current.get(msgId);
    if (iv !== undefined) window.clearInterval(iv);
    intervalsRef.current.delete(msgId);
  };

  /* ── simulated assistant run ───────────────────────────── */

  const runAssistant = (chatId: string, userText: string, atts: Attachment[], forcedSpec?: GenerationSpec) => {
    const c = chatsRef.current.find((x) => x.id === chatId);
    if (!c) return;
    let spec = forcedSpec;
    if (!spec) {
      // Full tutoring pipeline: intent → memory → student model → course →
      // vision → difficulty → strategy → response → verification → updates
      const out = runTutor({
        text: userText,
        attachments: atts,
        chat: c,
        model: studentModelRef.current,
        course: buildCourseContext(c, showPlayer),
      });
      spec = out.spec;
      setStudentModel(out.model);
    }
    const model = MODELS.find((m) => m.id === c.modelId) ?? MODELS[1];
    const id = uid();
    const steps: ThinkingStep[] = spec.steps.map((s) => ({ ...s, status: "pending" as const }));
    const msg: Message = {
      id,
      role: "assistant",
      content: "",
      createdAt: Date.now(),
      status: "thinking",
      thinking: steps,
      thinkingOpen: true,
      modelLabel: model.name,
      quiz: spec.quiz,
      format: spec.format,
      followUps: spec.followUps,
      image: spec.image ? { ...spec.image, status: "rendering" } : undefined,
    };
    setChats((cs) => cs.map((x) => (x.id === chatId ? { ...x, messages: [...x.messages, msg] } : x)));
    const timers: number[] = [];
    timersRef.current.set(id, timers);
    let i = 0;
    const total = steps.length;

    /** Images finish rendering shortly after the text lands. */
    const finishImage = () => {
      if (!spec.image) return;
      const t = window.setTimeout(
        () => patchMessage(chatId, id, (m) => ({ image: m.image ? { ...m.image, status: "done" } : m.image })),
        reducedMotion ? 0 : 1500
      );
      timers.push(t);
    };

    const startStream = () => {
      if (reducedMotion) {
        patchMessage(chatId, id, (m) => ({
          status: "complete",
          content: spec.text,
          thinkingOpen: false,
          thinkingMs: Date.now() - m.createdAt,
        }));
        finishImage();
        timersRef.current.delete(id);
        return;
      }
      patchMessage(chatId, id, { status: "streaming", thinkingOpen: false });
      const tokens = spec.text.split(/(\s+)/);
      let wi = 0;
      let tick = 0;
      const iv = window.setInterval(() => {
        tick += 1;
        wi += PERF.STREAM_WORDS - 2 + (tick % 3); // 3-4-2-word stagger, natural cadence
        const done = wi >= tokens.length;
        perf.bump("streamCommits");
        patchMessage(chatId, id, { content: done ? spec.text : tokens.slice(0, wi).join("") });
        if (done) {
          window.clearInterval(iv);
          intervalsRef.current.delete(id);
          patchMessage(chatId, id, (m) => ({ status: "complete", thinkingMs: Date.now() - m.createdAt }));
          finishImage();
        }
      }, PERF.STREAM_COMMIT_MS);
      intervalsRef.current.set(id, iv);
    };

    const tick = () => {
      i += 1;
      patchMessage(chatId, id, (m) => ({
        thinking: (m.thinking ?? []).map((s, idx) => ({
          ...s,
          status: idx < i ? ("done" as const) : idx === i ? ("active" as const) : ("pending" as const),
        })),
      }));
      if (i < total) timers.push(window.setTimeout(tick, 560 + ((i * 173) % 460)));
      else timers.push(window.setTimeout(startStream, 380));
    };
    timers.push(window.setTimeout(tick, 460));
  };

  /* ── user actions ──────────────────────────────────────── */

  const send = (textIn?: string) => {
    const text = (textIn ?? draft).trim();
    const atts = attachments;
    if (generating || (!text && atts.length === 0)) return;
    const userMsg: Message = {
      id: uid(),
      role: "user",
      content: text,
      attachments: atts.length ? atts : undefined,
      createdAt: Date.now(),
      status: "complete",
    };
    setChats((cs) =>
      cs.map((c) => {
        if (c.id !== chat.id) return c;
        const title =
          c.title === "New chat"
            ? text
              ? text.length > 36
                ? `${text.slice(0, 36).trimEnd()}…`
                : text
              : "Screenshot question"
            : c.title;
        return { ...c, title, messages: [...c.messages, userMsg] };
      })
    );
    setDrafts((d) => ({ ...d, [chat.id]: "" }));
    setAttachments([]);
    runAssistant(chat.id, text, atts);
  };

  const stopActive = () => {
    const m = [...chat.messages]
      .reverse()
      .find((x) => x.role === "assistant" && (x.status === "thinking" || x.status === "streaming"));
    if (!m) return;
    clearRun(m.id);
    if (!m.content) {
      setChats((cs) => cs.map((c) => (c.id !== chat.id ? c : { ...c, messages: c.messages.filter((x) => x.id !== m.id) })));
    } else {
      patchMessage(chat.id, m.id, (mm) => ({
        status: "complete",
        thinkingOpen: false,
        thinkingMs: mm.thinkingMs ?? Date.now() - mm.createdAt,
      }));
    }
  };

  const retry = (msgId: string) => {
    const msgs = chat.messages;
    const idx = msgs.findIndex((m) => m.id === msgId);
    if (idx < 0) return;
    const userMsg = msgs
      .slice(0, idx)
      .reverse()
      .find((m) => m.role === "user");
    if (!userMsg) return;
    const target = msgs[idx];
    clearRun(target.id);
    setChats((cs) => cs.map((c) => (c.id !== chat.id ? c : { ...c, messages: c.messages.filter((m) => m.id !== target.id) })));
    // Grading messages are regenerated from the quiz's final answer data.
    const quizMsg = userMsg.quizRef ? msgs.find((m) => m.id === userMsg.quizRef) : undefined;
    const regraded = quizMsg?.quiz
      ? gradeQuiz(quizMsg.quiz, chat.id, studentModelRef.current, buildCourseContext(chat, showPlayer))
      : undefined;
    if (regraded) setStudentModel(regraded.model);
    runAssistant(chat.id, userMsg.content, userMsg.attachments ?? [], regraded?.spec);
  };

  /* ── interactive practice quiz ─────────────────────────── */

  const quizAnswer = (msgId: string, qIdx: number, optIdx: number) => {
    patchMessage(chat.id, msgId, (m) => {
      if (!m.quiz || m.quiz.submitted) return {};
      const answers = m.quiz.answers.slice();
      answers[qIdx] = optIdx;
      return { quiz: { ...m.quiz, answers } };
    });
  };

  const quizSubmit = (msgId: string) => {
    if (generating) return;
    const quizMsg = chat.messages.find((m) => m.id === msgId);
    const quiz = quizMsg?.quiz;
    if (!quiz || quiz.submitted || quiz.answers.some((a) => a == null)) return;

    patchMessage(chat.id, msgId, (m) => ({ quiz: m.quiz ? { ...m.quiz, submitted: true } : m.quiz }));

    const sheet: Message = {
      id: uid(),
      role: "user",
      content: formatAnswerSheet(quiz),
      createdAt: Date.now(),
      status: "complete",
      quizRef: msgId,
    };
    setChats((cs) => cs.map((c) => (c.id !== chat.id ? c : { ...c, messages: [...c.messages, sheet] })));
    // Evaluate + classify mistakes + update the student model, then respond
    const graded = gradeQuiz(quiz, chat.id, studentModelRef.current, buildCourseContext(chat, showPlayer));
    setStudentModel(graded.model);
    runAssistant(chat.id, sheet.content, [], graded.spec);
  };

  /* ── stable callback layer ─────────────────────────────────
     Memoized message cells must re-render only when *their own*
     message changes — so conversation handlers delegate through
     refs and keep identity stable across every stream commit. */
  const handlersRef = useRef({ retry, quizAnswer, quizSubmit, send, patchMessage });
  handlersRef.current = { retry, quizAnswer, quizSubmit, send, patchMessage };
  const activeChatRef = useRef(chat);
  activeChatRef.current = chat;

  const cbRetry = useCallback((id: string) => handlersRef.current.retry(id), []);
  const cbQuizAnswer = useCallback((msgId: string, q: number, o: number) => handlersRef.current.quizAnswer(msgId, q, o), []);
  const cbQuizSubmit = useCallback((msgId: string) => handlersRef.current.quizSubmit(msgId), []);
  const cbFollowUp = useCallback((text: string) => handlersRef.current.send(text), []);
  const cbSend = useCallback((text: string) => handlersRef.current.send(text), []);
  const cbToggleThinking = useCallback(
    (msgId: string) => handlersRef.current.patchMessage(activeChatRef.current.id, msgId, (m) => ({ thinkingOpen: !m.thinkingOpen })),
    []
  );
  const cbSuggestion = useCallback(
    (text: string) => setDrafts((d) => (d[activeChatRef.current.id] === text ? d : { ...d, [activeChatRef.current.id]: text })),
    []
  );
  const cbDraftSync = useCallback(
    (v: string) => setDrafts((d) => (d[activeChatRef.current.id] === v ? d : { ...d, [activeChatRef.current.id]: v })),
    []
  );

  const newChat = () => {
    const id = uid();
    setChats((cs) => [
      { id, title: "New chat", course: chat.course, courseShort: chat.courseShort, modelId: chat.modelId, messages: [] },
      ...cs,
    ]);
    setActiveId(id);
    setAttachments([]);
    setDrawerOpen(false);
  };

  const selectChat = (id: string) => {
    if (id !== activeId) {
      setActiveId(id);
      setAttachments([]);
    }
    setDrawerOpen(false);
  };

  /* ── screenshot capture ────────────────────────────────── */

  const captureRegion = async (r: ShotRect) => {
    let att: Attachment | null = null;
    try {
      const { default: html2canvas } = await import("html2canvas");
      const scale = Math.min(PERF.SHOT_SCALE_MAX, window.devicePixelRatio || 1);
      const canvas = await html2canvas(document.documentElement, {
        scale,
        logging: false,
        backgroundColor: "#f7f6f2",
      });
      const sx = Math.max(0, Math.round((r.x + window.scrollX) * scale));
      const sy = Math.max(0, Math.round((r.y + window.scrollY) * scale));
      const sw = Math.max(2, Math.round(r.w * scale));
      const sh = Math.max(2, Math.round(r.h * scale));
      // Bound output size — caps memory + future upload cost on huge regions.
      const outScale = Math.min(1, PERF.SHOT_MAX_EDGE / Math.max(sw, sh));
      const crop = document.createElement("canvas");
      crop.width = Math.round(sw * outScale);
      crop.height = Math.round(sh * outScale);
      const ctx = crop.getContext("2d");
      if (!ctx) throw new Error("capture unsupported");
      ctx.drawImage(canvas, sx, sy, sw, sh, 0, 0, crop.width, crop.height);
      // JPEG for UI captures: far smaller than PNG, visually identical here.
      att = makeScreenshotAttachment(crop.toDataURL("image/jpeg", PERF.SHOT_JPEG_QUALITY), Math.round(r.w), Math.round(r.h));
    } catch {
      att = fallbackShot(r);
    }
    // Link the capture to what was on screen — the AI reads it as
    // "region of THIS resource at THIS position", not a loose image.
    if (showPlayer) {
      const ctx = getActiveContext();
      const pos = ctx.playbackState.currentTime != null
        ? `${Math.floor(ctx.playbackState.currentTime / 60)}m${String(Math.floor(ctx.playbackState.currentTime % 60)).padStart(2, "0")}`
        : ctx.locationState.currentPage != null
          ? `p${ctx.locationState.currentPage}`
          : ctx.locationState.currentSlide != null
            ? `s${ctx.locationState.currentSlide}`
            : "view";
      att = { ...att, name: `${ctx.resource.resourceName} · ${pos}.jpg` };
      courseBridge.noteInteraction(`captured a region of ${ctx.resource.resourceName}`);
    }
    setAttachments((p) => [...p, att]);
    setShotMode(false);
  };

  /* ── layout ────────────────────────────────────────────── */

  const framed = typeof mode === "number";
  const frameStyle: CSSProperties =
    mode === "full"
      ? { width: "100%" }
      : mode === "player"
        ? showPlayer
          ? { width: playerW, flex: "none" }
          : { width: "100%" }
        : { width: `min(${mode}px, 100%)` };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <PreviewBar
        mode={mode}
        onMode={(m) => {
          setMode(m);
          setDrawerOpen(false);
        }}
        chatPx={colW || frameW}
      />

      <div ref={shellRef} className="flex min-h-0 flex-1 justify-center bg-[--bg-2]">
        {showPlayer && <CoursePlayer />}
        {showPlayer && <ResizeHandle value={playerW} shellW={shellW} onChange={setPlayerW} />}

        <div
          ref={frameRef}
          style={frameStyle}
          className={cn("relative flex h-full min-w-0", framed && "border-x border-[--border] bg-[--bg] shadow-[var(--sh-frame)]")}
        >
          {dockSidebar && (
            <div className="h-full flex-none">
              <Sidebar
                mode="docked"
                chats={chats}
                activeId={chat.id}
                panelPinned={sidebarPinned}
                onSelect={selectChat}
                onNewChat={newChat}
                onTogglePin={(id) => patchChat(id, (c) => ({ pinned: !c.pinned }))}
                onTogglePanelPin={() => setSidebarPinned((v) => !v)}
              />
            </div>
          )}

          <section ref={colRef} data-tier={tier} aria-label={`Chat: ${chat.title}`} className="relative flex h-full min-w-0 flex-1 flex-col bg-[--bg]">
            <Header
              chat={chat}
              tier={tier}
              showMenuButton={!dockSidebar}
              onOpenSidebar={() => setDrawerOpen(true)}
              onTogglePin={() => patchChat(chat.id, (c) => ({ pinned: !c.pinned }))}
              onRename={(title) => patchChat(chat.id, { title })}
              onSelectModel={(modelId) => patchChat(chat.id, { modelId })}
            />

            <MessageList
              chat={chat}
              tier={tier}
              generating={generating}
              onSuggestion={cbSuggestion}
              onRetry={cbRetry}
              onImageClick={setLightbox}
              onToggleThinking={cbToggleThinking}
              onQuizAnswer={cbQuizAnswer}
              onQuizSubmit={cbQuizSubmit}
              onFollowUp={cbFollowUp}
            />

            <Composer
              key={chat.id}
              tier={tier}
              courseShort={chat.courseShort}
              initialDraft={drafts[chat.id] ?? ""}
              attachments={attachments}
              generating={generating}
              autofocus
              onDraftSync={cbDraftSync}
              onAddAttachments={(atts) => setAttachments((p) => [...p, ...atts])}
              onRemoveAttachment={(id) => setAttachments((p) => p.filter((a) => a.id !== id))}
              onSend={cbSend}
              onStop={stopActive}
              onScreenshot={() => setShotMode(true)}
            />

            {/* sidebar drawer (narrow containers) */}
            {!dockSidebar && drawerOpen && (
              <div className="absolute inset-0 z-40">
                <div
                  className="anim-fade-in absolute inset-0 bg-[rgba(28,27,23,0.32)]"
                  onClick={() => setDrawerOpen(false)}
                  aria-hidden="true"
                />
                <div className="absolute inset-y-0 left-0">
                  <Sidebar
                    mode="drawer"
                    chats={chats}
                    activeId={chat.id}
                    panelPinned={sidebarPinned}
                    onSelect={selectChat}
                    onNewChat={newChat}
                    onTogglePin={(id) => patchChat(id, (c) => ({ pinned: !c.pinned }))}
                    onTogglePanelPin={() => setSidebarPinned((v) => !v)}
                    onClose={() => setDrawerOpen(false)}
                  />
                </div>
              </div>
            )}
          </section>
        </div>
      </div>

      {shotMode && <ScreenshotOverlay onCancel={() => setShotMode(false)} onCapture={captureRegion} />}
      {lightbox && <Lightbox attachment={lightbox} onClose={() => setLightbox(null)} />}
    </div>
  );
}
