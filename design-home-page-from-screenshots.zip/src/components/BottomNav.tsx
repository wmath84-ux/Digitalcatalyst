import { Home, CalendarDays, Store, Briefcase, Wallet } from "lucide-react";

const navItems = [
  { label: "Home", icon: Home, active: true, badge: 0 },
  { label: "My Day", icon: CalendarDays, active: false, badge: 0 },
  { label: "Store", icon: Store, active: false, badge: 1 },
  { label: "Purchases", icon: Briefcase, active: false, badge: 0 },
  { label: "Wallet", icon: Wallet, active: false, badge: 0 },
];

export default function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-slate-100 bg-white/95 backdrop-blur-md shadow-[0_-8px_24px_-12px_rgba(30,27,75,0.15)]">
      <div className="mx-auto grid max-w-6xl grid-cols-5 items-center gap-1 px-2 py-2 sm:px-6">
        {navItems.map(({ label, icon: Icon, active, badge }) => (
          <button
            key={label}
            className="flex flex-col items-center gap-1 py-1 text-[11px] font-medium transition"
          >
            <span
              className={`relative flex h-9 w-9 items-center justify-center rounded-xl ${
                active
                  ? "bg-indigo-50 text-indigo-600"
                  : "text-slate-400 hover:text-slate-600"
              }`}
            >
              <Icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
              {badge > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white ring-2 ring-white">
                  {badge}
                </span>
              )}
            </span>
            <span className={active ? "text-indigo-600" : "text-slate-400"}>
              {label}
            </span>
          </button>
        ))}
      </div>
    </nav>
  );
}
