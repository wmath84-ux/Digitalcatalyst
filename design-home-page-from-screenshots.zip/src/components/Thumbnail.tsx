import { type LucideIcon } from "lucide-react";

interface ThumbnailProps {
  gradient: string;
  lines: string[];
  accent?: string;
  Icon?: LucideIcon;
  pattern?: "grid" | "waves" | "dots" | "none";
  className?: string;
}

export default function Thumbnail({
  gradient,
  lines,
  accent = "text-white",
  Icon,
  pattern = "grid",
  className = "",
}: ThumbnailProps) {
  return (
    <div
      className={`relative flex h-full w-full flex-col items-start justify-between overflow-hidden rounded-xl p-3 ${gradient} ${className}`}
    >
      {pattern === "grid" && (
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)",
            backgroundSize: "14px 14px",
          }}
        />
      )}
      {pattern === "dots" && (
        <div
          className="absolute inset-0 opacity-25"
          style={{
            backgroundImage:
              "radial-gradient(rgba(255,255,255,0.6) 1px, transparent 1px)",
            backgroundSize: "10px 10px",
          }}
        />
      )}
      {pattern === "waves" && (
        <svg
          className="absolute -bottom-2 left-0 w-full opacity-30"
          viewBox="0 0 200 60"
          fill="none"
        >
          <path
            d="M0 30 Q 25 0, 50 30 T 100 30 T 150 30 T 200 30"
            stroke="white"
            strokeWidth="3"
          />
          <path
            d="M0 45 Q 25 15, 50 45 T 100 45 T 150 45 T 200 45"
            stroke="white"
            strokeWidth="2"
            opacity="0.6"
          />
        </svg>
      )}
      <div className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-white/10 blur-xl" />

      {Icon && (
        <Icon className={`h-6 w-6 ${accent} relative z-10`} strokeWidth={2} />
      )}
      <div className="relative z-10">
        {lines.map((line, i) => (
          <p
            key={i}
            className={`font-extrabold uppercase leading-tight tracking-tight ${accent} ${
              i === 0 ? "text-sm" : "text-sm"
            }`}
          >
            {line}
          </p>
        ))}
      </div>
    </div>
  );
}
