import { useState } from "react";
import { Heart, Star } from "lucide-react";
import Thumbnail, { } from "./Thumbnail";
import { type LucideIcon } from "lucide-react";

export interface Product {
  id: string;
  title: string;
  description?: string;
  category?: string;
  categoryColor?: string;
  rating: number;
  reviews: number;
  price: number;
  originalPrice?: number;
  discount?: string;
  tag?: { label: string; color: string };
  gradient: string;
  lines: string[];
  Icon?: LucideIcon;
  pattern?: "grid" | "waves" | "dots" | "none";
}

export function ProductCardGrid({ product }: { product: Product }) {
  const [liked, setLiked] = useState(false);
  return (
    <div className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-3 shadow-sm transition hover:shadow-md">
      <div className="relative mb-3 h-32 w-full">
        <Thumbnail
          gradient={product.gradient}
          lines={product.lines}
          Icon={product.Icon}
          pattern={product.pattern}
        />
        {product.tag && (
          <span
            className={`absolute left-2 top-2 rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white ${product.tag.color}`}
          >
            {product.tag.label}
          </span>
        )}
        <button
          onClick={() => setLiked((v) => !v)}
          aria-label="Save"
          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-white/90 shadow-sm backdrop-blur"
        >
          <Heart
            className={`h-3.5 w-3.5 ${liked ? "fill-rose-500 text-rose-500" : "text-slate-400"}`}
          />
        </button>
      </div>
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-sm font-semibold text-slate-900">{product.title}</h3>
      </div>
      <div className="mt-1 flex items-center gap-1 text-xs text-slate-500">
        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
        <span className="font-medium text-slate-700">{product.rating}</span>
        <span>({product.reviews})</span>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <span className="text-base font-bold text-slate-900">
          ₹{product.price}
        </span>
        <button className="rounded-lg border border-indigo-200 px-3 py-1.5 text-xs font-semibold text-indigo-600 transition hover:bg-indigo-50">
          View
        </button>
      </div>
    </div>
  );
}

export function ProductCardList({ product }: { product: Product }) {
  const [liked, setLiked] = useState(false);
  return (
    <div className="flex gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm transition hover:shadow-md sm:gap-4 sm:p-4">
      <div className="relative h-24 w-24 shrink-0 sm:h-28 sm:w-28">
        <Thumbnail
          gradient={product.gradient}
          lines={product.lines}
          Icon={product.Icon}
          pattern={product.pattern}
        />
      </div>
      <div className="flex min-w-0 flex-1 flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2">
            {product.category && (
              <span
                className={`inline-block rounded-md px-2 py-0.5 text-[10px] font-semibold ${product.categoryColor}`}
              >
                {product.category}
              </span>
            )}
            <button
              onClick={() => setLiked((v) => !v)}
              aria-label="Save"
              className="shrink-0"
            >
              <Heart
                className={`h-4 w-4 ${liked ? "fill-rose-500 text-rose-500" : "text-slate-300"}`}
              />
            </button>
          </div>
          <h3 className="mt-1 text-sm font-semibold text-slate-900 sm:text-base">
            {product.title}
          </h3>
          {product.description && (
            <p className="mt-0.5 line-clamp-1 text-xs text-slate-400 sm:text-sm">
              {product.description}
            </p>
          )}
          <div className="mt-1 flex items-center gap-1 text-xs text-slate-500">
            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
            <span className="font-medium text-slate-700">{product.rating}</span>
            <span>({product.reviews})</span>
          </div>
        </div>
        <div className="mt-2 flex items-end justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-base font-bold text-slate-900 sm:text-lg">
              ₹{product.price}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-slate-400 line-through">
                ₹{product.originalPrice}
              </span>
            )}
            {product.discount && (
              <span className="rounded-md bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold text-rose-500">
                {product.discount}
              </span>
            )}
          </div>
          <button className="shrink-0 rounded-lg border border-indigo-200 px-3 py-1.5 text-xs font-semibold text-indigo-600 transition hover:bg-indigo-50 sm:text-sm">
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}
