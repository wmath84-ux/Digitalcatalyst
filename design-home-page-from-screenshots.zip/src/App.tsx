import {
  ShoppingBag,
  FileText,
  Search,
  SlidersHorizontal,
  Gift,
  Star,
  Ticket,
  Newspaper,
  ChevronRight,
  CheckCircle2,
  FolderOpen,
  Gem,
} from "lucide-react";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import Thumbnail from "./components/Thumbnail";
import { ProductCardGrid, ProductCardList } from "./components/ProductCard";
import { topRated, allProducts, continueLearning } from "./data/products";

function SectionHeader({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="mb-4 flex items-end justify-between">
      <div>
        <h2 className="text-lg font-bold text-slate-900 sm:text-xl">{title}</h2>
        {subtitle && <p className="mt-0.5 text-xs text-slate-400 sm:text-sm">{subtitle}</p>}
      </div>
      <button className="flex shrink-0 items-center gap-0.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700">
        View All
        <ChevronRight className="h-4 w-4" />
      </button>
    </div>
  );
}

const quickLinks = [
  { label: "My Purchases", icon: ShoppingBag },
  { label: "Free Resources", icon: Gift },
  { label: "Top Rated", icon: Star },
  { label: "Coupons", icon: Ticket },
  { label: "News", icon: Newspaper },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#f3f4fb]">
      <Header />

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-5 sm:px-6">
        {/* Hero */}
        <section className="relative overflow-hidden rounded-3xl border border-indigo-100 bg-gradient-to-br from-indigo-50 via-purple-50 to-white p-6 sm:p-10">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-violet-200/40 blur-3xl" />
          <div className="absolute -bottom-20 left-10 h-56 w-56 rounded-full bg-indigo-200/40 blur-3xl" />
          <div className="relative grid items-center gap-8 sm:grid-cols-2">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-indigo-100 bg-white px-3 py-1.5 text-xs font-semibold text-indigo-600 shadow-sm">
                <Gem className="h-3.5 w-3.5" />
                Premium Learning Store
              </span>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight tracking-tight text-slate-900 sm:text-4xl">
                Welcome to{" "}
                <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                  Eduvora
                </span>
              </h1>
              <p className="mt-3 max-w-md text-sm text-slate-500 sm:text-base">
                Learn, buy and access premium notes, courses and digital
                resources for Class 10th & beyond.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:opacity-90">
                  <ShoppingBag className="h-4 w-4" />
                  Explore Products
                </button>
                <button className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">
                  <FileText className="h-4 w-4" />
                  My Purchases
                </button>
              </div>
            </div>
            <div className="relative mx-auto hidden w-full max-w-xs sm:block">
              <img
                src="/images/hero-illustration.png"
                alt="Online learning illustration"
                className="w-full rounded-2xl"
              />
            </div>
          </div>
        </section>

        {/* Search */}
        <div className="mt-6 flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
          <Search className="h-5 w-5 shrink-0 text-slate-400" />
          <input
            type="text"
            placeholder="Search notes, courses, resources..."
            className="w-full bg-transparent text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none"
          />
          <button
            aria-label="Filters"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-50 hover:text-indigo-600"
          >
            <SlidersHorizontal className="h-4 w-4" />
          </button>
        </div>

        {/* Quick links */}
        <div className="mt-4 flex gap-3 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {quickLinks.map(({ label, icon: Icon }) => (
            <button
              key={label}
              className="flex shrink-0 items-center gap-2 whitespace-nowrap rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 shadow-sm transition hover:border-indigo-200 hover:text-indigo-600"
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>

        {/* Continue Learning */}
        <section className="mt-8">
          <SectionHeader
            title="Continue Learning"
            subtitle="Access your purchased products instantly."
          />
          <div className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center">
            <div className="relative h-32 w-full shrink-0 sm:h-28 sm:w-40">
              <Thumbnail
                gradient={continueLearning.gradient}
                lines={continueLearning.lines}
                Icon={continueLearning.Icon}
                pattern={continueLearning.pattern}
              />
            </div>
            <div className="flex-1">
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-600">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Purchased
              </span>
              <h3 className="mt-2 text-base font-bold text-slate-900">
                {continueLearning.title}
              </h3>
              <p className="mt-1 text-sm text-slate-400">
                {continueLearning.description}
              </p>
              <div className="mt-3 flex items-center gap-3">
                <div className="h-1.5 w-full max-w-[180px] overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-violet-600 to-indigo-600"
                    style={{ width: `${continueLearning.progress}%` }}
                  />
                </div>
                <span className="text-xs font-medium text-emerald-600">
                  {continueLearning.progress}% Completed
                </span>
              </div>
            </div>
            <button className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-200 transition hover:opacity-90">
              <FolderOpen className="h-4 w-4" />
              Access Files
            </button>
          </div>
        </section>

        {/* Top Rated Products */}
        <section className="mt-8">
          <SectionHeader title="Top Rated Products" />
          <div className="grid grid-cols-2 gap-4">
            {topRated.map((product) => (
              <ProductCardGrid key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* All Products */}
        <section className="mt-8">
          <SectionHeader
            title="All Products"
            subtitle="Browse all premium learning products."
          />
          <div className="flex flex-col gap-4">
            {allProducts.map((product) => (
              <ProductCardList key={product.id} product={product} />
            ))}
          </div>
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
