// One-off demo data seeder. Run with: node scripts/seed.mjs
import pg from "pg";
import { config } from "dotenv";

config();

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  const client = await pool.connect();
  try {
    // Products
    await client.query(`
      insert into products (id, title, short_description, long_description, instructor, category, product_type, class_level, subject, sku, tags, features, estimated_duration, language, visibility, available_for_sale, images, regular_price, sale_price, coin_price, coin_purchase_enabled, is_free, modules, paid_updates, rating, review_count, status)
      values
      ('prod_algebra101', 'Algebra Foundations', 'Master the basics of algebra with guided video lessons.', 'A complete algebra course for grades 8-10 covering equations, functions and graphs.', 'Meera Nair', 'Mathematics', 'course', 'Grade 9', 'Algebra', 'SKU-ALG-101', '["algebra","math","grade9"]', '["40 video lessons","Downloadable worksheets","Certificate of completion"]', '12 hours', 'English', 'visible', true,
      '[{"id":"img1","url":"https://images.example.com/algebra-cover.jpg","provider":"public","sortOrder":0,"isPrimary":true}]',
      999.00, 699.00, 500, true, false,
      '[{"id":"mod1","title":"Linear Equations","description":"Solving single and multi-step linear equations","sortOrder":0,"visibility":"visible","active":true,"accessLevel":"included","individuallyPurchasable":true,"cashPrice":199,"salePrice":149,"coinPrice":100,"includeInBundle":true,"previewAvailable":true,"requiredPreviousModuleIds":[],"entitlementId":"ent_mod1","badge":null,"parentModuleId":null,"resources":[{"id":"res1","name":"Intro video","type":"youtube","url":"https://www.youtube.com/watch?v=example","provider":"YouTube","sortOrder":0,"visibility":"visible","accessLevel":"included","paidUpdateId":null,"cashPrice":null,"coinPrice":null}]}]',
      '[]', 4.6, 128, 'published')
      on conflict (id) do nothing;
    `);

    await client.query(`
      insert into products (id, title, short_description, category, product_type, class_level, subject, visibility, available_for_sale, images, regular_price, sale_price, coin_price, coin_purchase_enabled, is_free, rating, review_count, status)
      values ('prod_physics_motion', 'Physics: Laws of Motion', 'Newtons laws explained with real-world examples.', 'Science', 'course', 'Grade 11', 'Physics', 'visible', true,
      '[{"id":"img2","url":"https://images.example.com/physics-cover.jpg","provider":"public","sortOrder":0,"isPrimary":true}]',
      1299.00, null, 700, false, false, 4.2, 54, 'published')
      on conflict (id) do nothing;
    `);

    await client.query(`
      insert into products (id, title, short_description, category, product_type, visibility, available_for_sale, regular_price, is_free, status)
      values ('prod_draft_chem', 'Organic Chemistry Basics', 'Draft course pending final review.', 'Science', 'course', 'hidden', false, 0, false, 'draft')
      on conflict (id) do nothing;
    `);

    // Customers
    await client.query(`
      insert into customers (uid, name, email, mobile, provider, role, status, coin_balance, purchase_count, joined_at, last_login_at)
      values
      ('uid_001', 'Aarav Sharma', 'aarav.sharma@example.com', '9876500001', 'password', 'user', 'active', 480, 3, now() - interval '60 days', now() - interval '1 day'),
      ('uid_002', 'Priya Verma', 'priya.verma@example.com', '9876500002', 'google', 'user', 'active', 120, 1, now() - interval '30 days', now() - interval '5 hours'),
      ('uid_003', 'Rohit Iyer', 'rohit.iyer@example.com', '9876500003', 'password', 'user', 'blocked', 0, 0, now() - interval '90 days', now() - interval '20 days')
      on conflict (uid) do nothing;
    `);

    // Orders
    await client.query(`
      insert into orders (id, customer_id, customer_name, customer_email, purchase_kind, items, coins_used, cash_paid, final_amount, payment_status, entitlement_status, gateway_order_id, gateway_payment_id, created_at, verified_at)
      values
      ('ord_1001', 'uid_001', 'Aarav Sharma', 'aarav.sharma@example.com', 'product', '[{"id":"i1","kind":"product","refId":"prod_algebra101","title":"Algebra Foundations","price":699}]', 0, 699, 699, 'verified', 'granted', 'order_rzp_1001', 'pay_rzp_1001', now() - interval '2 days', now() - interval '2 days'),
      ('ord_1002', 'uid_002', 'Priya Verma', 'priya.verma@example.com', 'module', '[{"id":"i2","kind":"module","refId":"mod1","title":"Linear Equations","price":149}]', 50, 99, 149, 'captured', 'granted', 'order_rzp_1002', 'pay_rzp_1002', now() - interval '1 day', now() - interval '1 day'),
      ('ord_1003', 'uid_003', 'Rohit Iyer', 'rohit.iyer@example.com', 'product', '[{"id":"i3","kind":"product","refId":"prod_physics_motion","title":"Physics: Laws of Motion","price":1299}]', 0, 0, 1299, 'failed', 'pending', 'order_rzp_1003', null, now() - interval '5 hours', null)
      on conflict (id) do nothing;
    `);
    await client.query(`update orders set failure_reason = 'Card declined by issuing bank' where id = 'ord_1003';`);

    // Coin transactions
    await client.query(`
      insert into coin_transactions (customer_id, type, amount, balance_before, balance_after, source, reason, reference_id, created_at)
      values
      ('uid_001', 'earn', 500, 0, 500, 'video_watch', 'Watched 10 module videos', 'ref_video_1', now() - interval '10 days'),
      ('uid_001', 'spend', -20, 500, 480, 'checkout', 'Applied to order ord_1002', 'ord_1002', now() - interval '2 days'),
      ('uid_002', 'earn', 170, 0, 170, 'purchase_bonus', 'Bonus coins for first purchase', 'ord_1002', now() - interval '3 days'),
      ('uid_002', 'spend', -50, 170, 120, 'checkout', 'Applied to order ord_1002', 'ord_1002', now() - interval '1 day')
      on conflict do nothing;
    `);

    // Rewards
    await client.query(`
      insert into badges (id, title, icon, description, category, rarity, trigger_metric, requirement, coin_reward, sort_order, status, claimed_count)
      values ('badge_first_purchase', 'First Purchase', '🎉', 'Awarded on completing your first purchase.', 'milestone', 'common', 'purchase_count', '>=1', 50, 0, 'active', 12)
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into streaks (id, title, icon, category, metric, goal, unit, frequency, consecutive_requirement, coin_reward, status)
      values ('streak_daily_learning', 'Daily Learner', '🔥', 'engagement', 'lessons_watched', 1, 'days', 'daily', 7, 100, 'active')
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into challenges (id, title, icon, description, category, metric, requirement, start_date, end_date, repeatable, coin_reward, status)
      values ('challenge_weekend_quiz', 'Weekend Quiz Sprint', '🏆', 'Complete 5 quizzes over the weekend.', 'engagement', 'quiz_count', '>=5', now(), now() + interval '30 days', true, 150, 'active')
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into redeem_items (id, title, description, icon, coin_cost, reward_type, discount, sort_order, status)
      values ('redeem_10off', '10% Off Coupon', 'Redeem coins for a 10% discount coupon.', '🎟️', 200, 'coupon', '10%', 0, 'active')
      on conflict (id) do nothing;
    `);
    await client.query(`insert into coin_economy_settings (id) values (1) on conflict (id) do nothing;`);

    // Subscriptions
    await client.query(`
      insert into subscription_plans (id, name, description, billing_cycles, access_tier, featured, active, included_feature_ids)
      values ('plan_pro', 'Pro Learner', 'Full access to AI tutor and premium community features.', '[{"cycle":"monthly","label":"Monthly","price":299},{"cycle":"yearly","label":"Yearly","price":2499}]', 'pro', true, true, '["feat_ai_tutor"]')
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into subscription_features (id, key, name, description, individual_price, active)
      values ('feat_ai_tutor', 'ai_tutor', 'AI Course Tutor', 'Unlimited AI Q&A on course content.', 149, true)
      on conflict (id) do nothing;
    `);

    // Coupons
    await client.query(`
      insert into coupons (id, code, discount_type, value, active, global_usage_limit, per_user_usage_limit, min_order)
      values ('coupon_welcome10', 'WELCOME10', 'percentage', 10, true, 1000, 1, 199)
      on conflict (id) do nothing;
    `);

    // Reviews
    await client.query(`
      insert into reviews (id, product_id, product_title, customer_id, customer_name, rating, comment, verified_purchase, status)
      values
      ('rev_1', 'prod_algebra101', 'Algebra Foundations', 'uid_001', 'Aarav Sharma', 5, 'Excellent explanations, very easy to follow!', true, 'published'),
      ('rev_2', 'prod_physics_motion', 'Physics: Laws of Motion', 'uid_002', 'Priya Verma', 4, 'Good course but needs more practice problems.', true, 'pending')
      on conflict (id) do nothing;
    `);

    // Community moderation
    await client.query(`
      insert into community_posts (id, type, author_id, author_name, content, report_count, hidden)
      values ('post_1', 'post', 'uid_002', 'Priya Verma', 'Anyone else struggling with quadratic equations?', 1, false)
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into community_comments (id, post_id, author_id, author_name, content, report_count, hidden)
      values ('comment_1', 'post_1', 'uid_003', 'Rohit Iyer', 'This is spam content example', 2, false)
      on conflict (id) do nothing;
    `);
    await client.query(`
      insert into community_reports (id, content_type, target_id, reporter_id, reason, status)
      values ('report_1', 'comment', 'comment_1', 'uid_001', 'Spam / irrelevant content', 'open')
      on conflict (id) do nothing;
    `);

    await client.query(`insert into ai_settings (id) values (1) on conflict (id) do nothing;`);
    await client.query(`insert into app_content_settings (id) values (1) on conflict (id) do nothing;`);

    console.log("Seed complete.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
