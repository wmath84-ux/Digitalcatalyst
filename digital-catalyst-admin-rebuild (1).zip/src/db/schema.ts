import {
  bigserial,
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import type {
  PaidUpdate,
  ProductImage,
  ProductModule,
  OrderItem,
} from "@/lib/admin/types";

/* ------------------------------------------------------------------ */
/* Admin identity & sessions                                          */
/* ------------------------------------------------------------------ */

export const adminUsers = pgTable("admin_users", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 32 }).notNull().default("admin"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const adminSessions = pgTable("admin_sessions", {
  token: varchar("token", { length: 128 }).primaryKey(),
  adminId: bigserial("admin_id", { mode: "number" }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  lastVerifiedAt: timestamp("last_verified_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  adminId: varchar("admin_id", { length: 64 }).notNull(),
  adminEmail: varchar("admin_email", { length: 255 }).notNull(),
  action: varchar("action", { length: 128 }).notNull(),
  targetType: varchar("target_type", { length: 64 }).notNull(),
  targetId: varchar("target_id", { length: 128 }).notNull(),
  previousValue: jsonb("previous_value"),
  newValue: jsonb("new_value"),
  reason: text("reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Products & course content                                          */
/* ------------------------------------------------------------------ */

export const products = pgTable("products", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  shortDescription: text("short_description").notNull(),
  longDescription: text("long_description").default(""),
  instructor: varchar("instructor", { length: 255 }).default(""),
  category: varchar("category", { length: 128 }).default(""),
  productType: varchar("product_type", { length: 64 }).default("course"),
  classLevel: varchar("class_level", { length: 64 }).default(""),
  subject: varchar("subject", { length: 128 }).default(""),
  sku: varchar("sku", { length: 128 }).default(""),
  tags: jsonb("tags").$type<string[]>().default([]),
  searchKeywords: jsonb("search_keywords").$type<string[]>().default([]),
  features: jsonb("features").$type<string[]>().default([]),
  estimatedDuration: varchar("estimated_duration", { length: 64 }).default(""),
  language: varchar("language", { length: 64 }).default("English"),
  manualRating: numeric("manual_rating", { precision: 2, scale: 1 }),
  visibility: varchar("visibility", { length: 16 }).notNull().default("hidden"),
  availableForSale: boolean("available_for_sale").notNull().default(false),

  images: jsonb("images").$type<ProductImage[]>().default([]),

  regularPrice: numeric("regular_price", { precision: 10, scale: 2 }).notNull().default("0"),
  salePrice: numeric("sale_price", { precision: 10, scale: 2 }),
  coinPrice: integer("coin_price").default(0),
  coinPurchaseEnabled: boolean("coin_purchase_enabled").notNull().default(false),
  isFree: boolean("is_free").notNull().default(false),
  eligibleCouponIds: jsonb("eligible_coupon_ids").$type<string[]>().default([]),
  minPayableAmount: numeric("min_payable_amount", { precision: 10, scale: 2 }).default("0"),
  availabilityDate: timestamp("availability_date", { withTimezone: true }),
  saleStart: timestamp("sale_start", { withTimezone: true }),
  saleEnd: timestamp("sale_end", { withTimezone: true }),

  modules: jsonb("modules").$type<ProductModule[]>().default([]),
  paidUpdates: jsonb("paid_updates").$type<PaidUpdate[]>().default([]),

  rating: numeric("rating", { precision: 2, scale: 1 }).default("0"),
  reviewCount: integer("review_count").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("draft"),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Orders                                                              */
/* ------------------------------------------------------------------ */

export const orders = pgTable("orders", {
  id: varchar("id", { length: 64 }).primaryKey(),
  customerId: varchar("customer_id", { length: 64 }).notNull(),
  customerName: varchar("customer_name", { length: 255 }).default(""),
  customerEmail: varchar("customer_email", { length: 255 }).default(""),
  purchaseKind: varchar("purchase_kind", { length: 32 }).notNull().default("product"),
  items: jsonb("items").$type<OrderItem[]>().default([]),
  couponCode: varchar("coupon_code", { length: 64 }),
  coinsUsed: integer("coins_used").notNull().default(0),
  discountAmount: numeric("discount_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  cashPaid: numeric("cash_paid", { precision: 10, scale: 2 }).notNull().default("0"),
  finalAmount: numeric("final_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  paymentStatus: varchar("payment_status", { length: 32 }).notNull().default("created"),
  entitlementStatus: varchar("entitlement_status", { length: 32 }).notNull().default("pending"),
  gatewayOrderId: varchar("gateway_order_id", { length: 128 }),
  gatewayPaymentId: varchar("gateway_payment_id", { length: 128 }),
  grantedEntitlementIds: jsonb("granted_entitlement_ids").$type<string[]>().default([]),
  failureReason: text("failure_reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
});

/* ------------------------------------------------------------------ */
/* Customers                                                           */
/* ------------------------------------------------------------------ */

export const customers = pgTable("customers", {
  uid: varchar("uid", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).default(""),
  email: varchar("email", { length: 255 }).notNull(),
  mobile: varchar("mobile", { length: 32 }).default(""),
  provider: varchar("provider", { length: 32 }).default("password"),
  role: varchar("role", { length: 32 }).notNull().default("user"),
  status: varchar("status", { length: 16 }).notNull().default("active"),
  coinBalance: integer("coin_balance").notNull().default(0),
  subscriptionId: varchar("subscription_id", { length: 64 }),
  purchaseCount: integer("purchase_count").notNull().default(0),
  wishlist: jsonb("wishlist").$type<string[]>().default([]),
  cart: jsonb("cart").$type<string[]>().default([]),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }).notNull().defaultNow(),
});

export const coinTransactions = pgTable("coin_transactions", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  customerId: varchar("customer_id", { length: 64 }).notNull(),
  type: varchar("type", { length: 16 }).notNull(),
  amount: integer("amount").notNull(),
  balanceBefore: integer("balance_before").notNull(),
  balanceAfter: integer("balance_after").notNull(),
  source: varchar("source", { length: 64 }).notNull().default("manual"),
  reason: text("reason"),
  referenceId: varchar("reference_id", { length: 128 }),
  adminId: varchar("admin_id", { length: 64 }),
  flagged: boolean("flagged").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Rewards & gamification                                              */
/* ------------------------------------------------------------------ */

export const badges = pgTable("badges", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  icon: text("icon").default(""),
  description: text("description").default(""),
  category: varchar("category", { length: 64 }).default(""),
  rarity: varchar("rarity", { length: 32 }).default("common"),
  triggerMetric: varchar("trigger_metric", { length: 64 }).default(""),
  requirement: varchar("requirement", { length: 128 }).default(""),
  coinReward: integer("coin_reward").notNull().default(0),
  unlockProductId: varchar("unlock_product_id", { length: 64 }),
  subscriptionReward: varchar("subscription_reward", { length: 64 }),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  claimLimit: integer("claim_limit").default(0),
  sortOrder: integer("sort_order").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  claimedCount: integer("claimed_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const streaks = pgTable("streaks", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  icon: text("icon").default(""),
  category: varchar("category", { length: 64 }).default(""),
  metric: varchar("metric", { length: 64 }).default(""),
  goal: integer("goal").notNull().default(1),
  unit: varchar("unit", { length: 32 }).default("days"),
  frequency: varchar("frequency", { length: 32 }).default("daily"),
  consecutiveRequirement: integer("consecutive_requirement").notNull().default(1),
  resetRule: varchar("reset_rule", { length: 64 }).default("midnight"),
  gracePeriodHours: integer("grace_period_hours").notNull().default(0),
  coinReward: integer("coin_reward").notNull().default(0),
  badgeReward: varchar("badge_reward", { length: 64 }),
  unlockProductId: varchar("unlock_product_id", { length: 64 }),
  motivationNote: text("motivation_note").default(""),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const challenges = pgTable("challenges", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  icon: text("icon").default(""),
  description: text("description").default(""),
  category: varchar("category", { length: 64 }).default(""),
  metric: varchar("metric", { length: 64 }).default(""),
  requirement: varchar("requirement", { length: 128 }).default(""),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  repeatable: boolean("repeatable").notNull().default(false),
  perUserClaimLimit: integer("per_user_claim_limit").notNull().default(1),
  coinReward: integer("coin_reward").notNull().default(0),
  badgeReward: varchar("badge_reward", { length: 64 }),
  couponReward: varchar("coupon_reward", { length: 64 }),
  unlockProductId: varchar("unlock_product_id", { length: 64 }),
  ctaLabel: varchar("cta_label", { length: 64 }).default("Join challenge"),
  sortOrder: integer("sort_order").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const redeemItems = pgTable("redeem_items", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").default(""),
  icon: text("icon").default(""),
  coinCost: integer("coin_cost").notNull().default(0),
  rewardType: varchar("reward_type", { length: 32 }).notNull().default("coupon"),
  couponId: varchar("coupon_id", { length: 64 }),
  discount: varchar("discount", { length: 64 }),
  productUnlockId: varchar("product_unlock_id", { length: 64 }),
  moduleUnlockId: varchar("module_unlock_id", { length: 64 }),
  updateUnlockId: varchar("update_unlock_id", { length: 64 }),
  subscriptionAccess: varchar("subscription_access", { length: 64 }),
  badgeReward: varchar("badge_reward", { length: 64 }),
  stockLimit: integer("stock_limit").default(0),
  perUserLimit: integer("per_user_limit").notNull().default(1),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  confirmationMessage: text("confirmation_message").default(""),
  terms: text("terms").default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const coinEconomySettings = pgTable("coin_economy_settings", {
  id: integer("id").primaryKey().default(1),
  coinsPerVideoMinute: integer("coins_per_video_minute").notNull().default(1),
  coinsPerPurchase: integer("coins_per_purchase").notNull().default(5),
  coinsToInrRatio: numeric("coins_to_inr_ratio", { precision: 10, scale: 2 }).notNull().default("1.00"),
  maxCheckoutDiscountPercent: integer("max_checkout_discount_percent").notNull().default(20),
  productOverrides: jsonb("product_overrides").$type<Record<string, number>>().default({}),
  subscriptionOverrides: jsonb("subscription_overrides").$type<Record<string, number>>().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Subscriptions                                                      */
/* ------------------------------------------------------------------ */

export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").default(""),
  billingCycles: jsonb("billing_cycles").$type<{ cycle: string; label: string; price: number }[]>().default([]),
  accessTier: varchar("access_tier", { length: 32 }).default("basic"),
  badge: varchar("badge", { length: 64 }),
  cta: varchar("cta", { length: 64 }).default("Subscribe"),
  featured: boolean("featured").notNull().default(false),
  active: boolean("active").notNull().default(false),
  includedFeatureIds: jsonb("included_feature_ids").$type<string[]>().default([]),
  includedProductIds: jsonb("included_product_ids").$type<string[]>().default([]),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const subscriptionFeatures = pgTable("subscription_features", {
  id: varchar("id", { length: 64 }).primaryKey(),
  key: varchar("key", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").default(""),
  icon: text("icon").default(""),
  individualPrice: numeric("individual_price", { precision: 10, scale: 2 }).default("0"),
  includedInPlanIds: jsonb("included_in_plan_ids").$type<string[]>().default([]),
  badge: varchar("badge", { length: 64 }),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Coupons                                                             */
/* ------------------------------------------------------------------ */

export const coupons = pgTable("coupons", {
  id: varchar("id", { length: 64 }).primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  discountType: varchar("discount_type", { length: 16 }).notNull().default("percentage"),
  value: numeric("value", { precision: 10, scale: 2 }).notNull().default("0"),
  startDate: timestamp("start_date", { withTimezone: true }),
  expiryDate: timestamp("expiry_date", { withTimezone: true }),
  active: boolean("active").notNull().default(true),
  globalUsageLimit: integer("global_usage_limit").default(0),
  perUserUsageLimit: integer("per_user_usage_limit").default(1),
  minOrder: numeric("min_order", { precision: 10, scale: 2 }).default("0"),
  maxDiscount: numeric("max_discount", { precision: 10, scale: 2 }).default("0"),
  eligibleProducts: jsonb("eligible_products").$type<string[]>().default([]),
  eligibleModules: jsonb("eligible_modules").$type<string[]>().default([]),
  eligibleSubscriptions: jsonb("eligible_subscriptions").$type<string[]>().default([]),
  eligibleCategories: jsonb("eligible_categories").$type<string[]>().default([]),
  firstPurchaseOnly: boolean("first_purchase_only").notNull().default(false),
  usedCount: integer("used_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Reviews                                                             */
/* ------------------------------------------------------------------ */

export const reviews = pgTable("reviews", {
  id: varchar("id", { length: 64 }).primaryKey(),
  productId: varchar("product_id", { length: 64 }).notNull(),
  productTitle: varchar("product_title", { length: 255 }).default(""),
  customerId: varchar("customer_id", { length: 64 }).default(""),
  customerName: varchar("customer_name", { length: 255 }).default(""),
  rating: integer("rating").notNull().default(5),
  comment: text("comment").default(""),
  verifiedPurchase: boolean("verified_purchase").notNull().default(false),
  status: varchar("status", { length: 16 }).notNull().default("pending"),
  reportReason: text("report_reason"),
  adminReply: text("admin_reply"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Community moderation                                                */
/* ------------------------------------------------------------------ */

export const communityPosts = pgTable("community_posts", {
  id: varchar("id", { length: 64 }).primaryKey(),
  type: varchar("type", { length: 16 }).notNull().default("post"),
  authorId: varchar("author_id", { length: 64 }).default(""),
  authorName: varchar("author_name", { length: 255 }).default(""),
  content: text("content").default(""),
  media: jsonb("media").$type<string[]>().default([]),
  pollOptions: jsonb("poll_options").$type<{ label: string; votes: number }[]>().default([]),
  pollClosed: boolean("poll_closed").notNull().default(false),
  commentCount: integer("comment_count").notNull().default(0),
  reportCount: integer("report_count").notNull().default(0),
  hidden: boolean("hidden").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const communityComments = pgTable("community_comments", {
  id: varchar("id", { length: 64 }).primaryKey(),
  postId: varchar("post_id", { length: 64 }).notNull(),
  authorId: varchar("author_id", { length: 64 }).default(""),
  authorName: varchar("author_name", { length: 255 }).default(""),
  content: text("content").default(""),
  reportCount: integer("report_count").notNull().default(0),
  hidden: boolean("hidden").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const communityReports = pgTable("community_reports", {
  id: varchar("id", { length: 64 }).primaryKey(),
  contentType: varchar("content_type", { length: 16 }).notNull(),
  targetId: varchar("target_id", { length: 64 }).notNull(),
  reporterId: varchar("reporter_id", { length: 64 }).default(""),
  reason: text("reason").default(""),
  status: varchar("status", { length: 16 }).notNull().default("open"),
  moderationReason: text("moderation_reason"),
  resolvedBy: varchar("resolved_by", { length: 255 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

/* ------------------------------------------------------------------ */
/* AI workspace                                                        */
/* ------------------------------------------------------------------ */

export const aiSettings = pgTable("ai_settings", {
  id: integer("id").primaryKey().default(1),
  enabledModels: jsonb("enabled_models").$type<string[]>().default(["gemini-1.5-flash"]),
  defaultModel: varchar("default_model", { length: 64 }).default("gemini-1.5-flash"),
  communityAiAccess: boolean("community_ai_access").notNull().default(true),
  courseAiAccess: boolean("course_ai_access").notNull().default(true),
  systemInstructions: text("system_instructions").default(""),
  courseContextEnabled: boolean("course_context_enabled").notNull().default(true),
  userContextEnabled: boolean("user_context_enabled").notNull().default(false),
  contextTokenLimit: integer("context_token_limit").notNull().default(4000),
  dailyRequestLimit: integer("daily_request_limit").notNull().default(50),
  rateLimitPerMinute: integer("rate_limit_per_minute").notNull().default(6),
  promptTemplates: jsonb("prompt_templates").$type<{ name: string; template: string }[]>().default([]),
  safetyInstructions: text("safety_instructions").default(""),
  clearHistoryPolicyDays: integer("clear_history_policy_days").notNull().default(30),
  providerStatus: jsonb("provider_status").$type<Record<string, string>>().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* App content & feature controls                                     */
/* ------------------------------------------------------------------ */

export const appContentSettings = pgTable("app_content_settings", {
  id: integer("id").primaryKey().default(1),
  siteName: varchar("site_name", { length: 128 }).notNull().default("Digital Catalyst"),
  banners: jsonb("banners").$type<
    { id: string; title: string; subtitle: string; image: string; cta: string; destination: string; sortOrder: number; active: boolean }[]
  >().default([]),
  categories: jsonb("categories").$type<{ id: string; label: string; icon: string; sortOrder: number }[]>().default([]),
  testimonials: jsonb("testimonials").$type<{ id: string; name: string; quote: string; active: boolean }[]>().default([]),
  storeTitle: varchar("store_title", { length: 128 }).default("Store"),
  storeSubtitle: varchar("store_subtitle", { length: 255 }).default(""),
  showWishlist: boolean("show_wishlist").notNull().default(true),
  showRatings: boolean("show_ratings").notNull().default(true),
  showSaleBadges: boolean("show_sale_badges").notNull().default(true),
  emptyStateMessages: jsonb("empty_state_messages").$type<Record<string, string>>().default({}),
  pdpHelperTexts: jsonb("pdp_helper_texts").$type<Record<string, string>>().default({}),
  coursePlayerMessages: jsonb("course_player_messages").$type<Record<string, string>>().default({}),
  authLabels: jsonb("auth_labels").$type<Record<string, string>>().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
