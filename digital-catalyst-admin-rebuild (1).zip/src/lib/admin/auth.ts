import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminSessions, adminUsers } from "@/db/schema";

export const ADMIN_SESSION_COOKIE = "dc_admin_session";
export const APPROVED_ADMIN_EMAIL = "wmath84@gmail.com";
// Session lifetime is a safety ceiling; the cookie itself has no persistent
// max-age so it is discarded whenever the browser/PWA session ends.
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const derived = scryptSync(password, salt, 64);
  const keyBuffer = Buffer.from(key, "hex");
  if (derived.length !== keyBuffer.length) return false;
  return timingSafeEqual(derived, keyBuffer);
}

export async function ensureSeedAdmin() {
  const rows = await db.select().from(adminUsers).limit(1);
  if (rows.length > 0) return;
  const defaultPassword = process.env.ADMIN_SEED_PASSWORD || "ChangeMe123!";
  await db.insert(adminUsers).values({
    email: APPROVED_ADMIN_EMAIL,
    passwordHash: hashPassword(defaultPassword),
    role: "admin",
  });
}

export type AdminSessionInfo = {
  token: string;
  adminId: number;
  email: string;
  role: string;
  createdAt: Date;
  lastVerifiedAt: Date;
};

export async function createAdminSession(adminId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_TTL_MS);
  await db.insert(adminSessions).values({
    token,
    adminId,
    createdAt: now,
    expiresAt,
    lastVerifiedAt: now,
  });
  return token;
}

export async function getAdminSession(): Promise<AdminSessionInfo | null> {
  const store = await cookies();
  const token = store.get(ADMIN_SESSION_COOKIE)?.value;
  if (!token) return null;

  const rows = await db
    .select({
      token: adminSessions.token,
      adminId: adminSessions.adminId,
      createdAt: adminSessions.createdAt,
      expiresAt: adminSessions.expiresAt,
      lastVerifiedAt: adminSessions.lastVerifiedAt,
      email: adminUsers.email,
      role: adminUsers.role,
    })
    .from(adminSessions)
    .innerJoin(adminUsers, eq(adminSessions.adminId, adminUsers.id))
    .where(eq(adminSessions.token, token))
    .limit(1);

  const session = rows[0];
  if (!session) return null;
  if (session.expiresAt.getTime() < Date.now()) {
    await destroyAdminSession(token);
    return null;
  }
  if (session.email !== APPROVED_ADMIN_EMAIL || session.role !== "admin") {
    await destroyAdminSession(token);
    return null;
  }

  await db
    .update(adminSessions)
    .set({ lastVerifiedAt: new Date() })
    .where(eq(adminSessions.token, token));

  return {
    token: session.token,
    adminId: session.adminId,
    email: session.email,
    role: session.role,
    createdAt: session.createdAt,
    lastVerifiedAt: session.lastVerifiedAt,
  };
}

export async function destroyAdminSession(token: string) {
  await db.delete(adminSessions).where(eq(adminSessions.token, token));
}

export async function requireAdminSession(): Promise<AdminSessionInfo> {
  const session = await getAdminSession();
  if (!session) {
    throw new AdminAuthError("Admin session required");
  }
  return session;
}

export class AdminAuthError extends Error {}
