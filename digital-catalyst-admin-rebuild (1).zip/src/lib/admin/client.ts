export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export async function adminFetch<T = unknown>(input: string, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    ...init,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });

  if (res.status === 401) {
    if (typeof window !== "undefined") {
      window.sessionStorage.removeItem("dc_admin_marker");
      window.location.hash = "#/admin-login";
      window.location.href = "/admin-login";
    }
    throw new ApiError("Admin session expired.", 401);
  }

  const contentType = res.headers.get("content-type") || "";
  const body = contentType.includes("application/json") ? await res.json().catch(() => ({})) : null;

  if (!res.ok) {
    const message = (body && typeof body === "object" && "error" in body && String(body.error)) || "Request failed.";
    throw new ApiError(message, res.status);
  }

  return body as T;
}
