import { NextResponse } from "next/server";
import { getAdminSession, type AdminSessionInfo } from "@/lib/admin/auth";

export async function withAdminSession<T>(
  handler: (session: AdminSessionInfo) => Promise<T>
): Promise<T | NextResponse> {
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: "Admin session expired. Please log in again." }, { status: 401 });
  }
  return handler(session);
}

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function genId(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
