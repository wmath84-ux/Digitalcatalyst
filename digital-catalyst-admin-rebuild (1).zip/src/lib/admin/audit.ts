import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import type { AdminSessionInfo } from "@/lib/admin/auth";

export async function writeAuditLog(params: {
  session: AdminSessionInfo;
  action: string;
  targetType: string;
  targetId: string;
  previousValue?: unknown;
  newValue?: unknown;
  reason?: string;
}) {
  await db.insert(auditLogs).values({
    adminId: String(params.session.adminId),
    adminEmail: params.session.email,
    action: params.action,
    targetType: params.targetType,
    targetId: params.targetId,
    previousValue: params.previousValue ?? null,
    newValue: params.newValue ?? null,
    reason: params.reason ?? null,
  });
}
