import Link from "next/link";

export const dynamic = "force-dynamic";

export default function LandingPage() {
  return (
    <main className="flex min-h-screen flex-col bg-slate-50">
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col px-5 py-10">
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Digital Catalyst</p>
        <h1 className="mt-3 text-3xl font-bold leading-tight text-slate-900">Learn faster with guided digital courses</h1>
        <p className="mt-3 text-sm text-slate-600">
          Video lessons, practice modules and a rewards program that keeps you motivated — all in one place.
        </p>

        <div className="mt-8 flex flex-col gap-3">
          <Link
            href="/auth"
            className="flex h-12 items-center justify-center rounded-xl bg-slate-900 text-sm font-semibold text-white active:bg-slate-800"
          >
            Get started
          </Link>
          <Link
            href="/auth"
            className="flex h-12 items-center justify-center rounded-xl border border-slate-300 text-sm font-medium text-slate-700 active:bg-slate-100"
          >
            I already have an account
          </Link>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-3">
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <p className="text-sm font-semibold text-slate-900">Course modules you can buy individually</p>
            <p className="mt-1 text-xs text-slate-500">Pick only the modules you need, or unlock the full course bundle.</p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <p className="text-sm font-semibold text-slate-900">EduCoins &amp; rewards</p>
            <p className="mt-1 text-xs text-slate-500">Earn coins for learning activity and redeem them at checkout.</p>
          </div>
        </div>

        <div className="flex-1" />

        <footer className="mt-10 text-center">
          <Link href="/admin-login" className="text-xs text-slate-400 underline underline-offset-2">
            Open dashboard
          </Link>
        </footer>
      </div>
    </main>
  );
}
