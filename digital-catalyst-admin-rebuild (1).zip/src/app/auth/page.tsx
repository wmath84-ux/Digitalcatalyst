"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";

export default function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    setMessage(
      mode === "login"
        ? "User authentication is handled by the main application service."
        : "Account creation is handled by the main application service."
    );
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4 py-10">
      <div className="w-full max-w-[380px] rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Digital Catalyst</p>
        <h1 className="mt-1 text-xl font-semibold text-slate-900">{mode === "login" ? "Welcome back" : "Create your account"}</h1>

        <div className="mt-4 flex rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`h-9 flex-1 rounded-md text-sm font-medium ${mode === "login" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}
          >
            Log in
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={`h-9 flex-1 rounded-md text-sm font-medium ${mode === "signup" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}
          >
            Sign up
          </button>
        </div>

        <form className="mt-5 space-y-4" onSubmit={onSubmit}>
          <label className="block">
            <span className="text-xs font-medium text-slate-700">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 h-11 w-full rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-slate-500"
              placeholder="you@example.com"
            />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-700">Password</span>
            <div className="mt-1 flex items-center rounded-lg border border-slate-300 focus-within:border-slate-500">
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11 w-full flex-1 rounded-lg px-3 text-sm outline-none"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="mr-1 flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md text-xs font-medium text-slate-500 active:bg-slate-100"
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </label>

          {mode === "login" && (
            <div className="text-right">
              <button type="button" className="text-xs text-slate-500 underline underline-offset-2" onClick={() => setMessage("Password reset link would be emailed to you.")}>
                Forgot password?
              </button>
            </div>
          )}

          {message && <p className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">{message}</p>}

          <button type="submit" className="flex h-11 w-full items-center justify-center rounded-lg bg-slate-900 text-sm font-semibold text-white active:bg-slate-800">
            {mode === "login" ? "Log in" : "Create account"}
          </button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-slate-400">
          <span className="h-px flex-1 bg-slate-200" /> or <span className="h-px flex-1 bg-slate-200" />
        </div>

        <button
          type="button"
          onClick={() => setMessage("Google sign-in would open the Google account picker.")}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 active:bg-slate-100"
        >
          Continue with Google
        </button>

        <Link href="/" className="mt-6 block text-center text-sm text-slate-500 underline underline-offset-2">
          Back to landing
        </Link>
      </div>
    </main>
  );
}
