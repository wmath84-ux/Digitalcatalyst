"use client";

import { use } from "react";
import { ProductEditor } from "@/components/admin/products/ProductEditor";

export default function ProductDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return <ProductEditor productId={id} />;
}
