import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getAdminSession } from "@/lib/admin/auth";
import { AdminProviders } from "@/components/admin/AdminProviders";
import { AdminShell } from "@/components/admin/AdminShell";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await getAdminSession();
  if (!session) {
    redirect("/admin-login");
  }

  return (
    <AdminProviders>
      <AdminShell email={session.email} role={session.role}>
        {children}
      </AdminShell>
    </AdminProviders>
  );
}
