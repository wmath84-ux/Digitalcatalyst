import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { communityPosts } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type");
    const reported = searchParams.get("reported");

    const conditions = [];
    if (type) conditions.push(eq(communityPosts.type, type));
    if (reported === "true") conditions.push(eq(communityPosts.hidden, false));

    const rows = await db
      .select()
      .from(communityPosts)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(communityPosts.createdAt));
    return NextResponse.json({ posts: rows });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Post id is required.");
    const existingRows = await db.select().from(communityPosts).where(eq(communityPosts.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Post not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      if (!body.reason) return jsonError("A moderation reason is required to delete content.");
      await db.delete(communityPosts).where(eq(communityPosts.id, body.id));
      await writeAuditLog({ session, action: "post.delete", targetType: "community_post", targetId: body.id, previousValue: existing, reason: body.reason });
      return NextResponse.json({ ok: true });
    }

    const updates: Record<string, unknown> = {};
    if (body.hidden !== undefined) updates.hidden = body.hidden;
    if (body.pollClosed !== undefined) updates.pollClosed = body.pollClosed;

    const [updated] = await db.update(communityPosts).set(updates).where(eq(communityPosts.id, body.id)).returning();
    await writeAuditLog({ session, action: "post.moderate", targetType: "community_post", targetId: body.id, previousValue: existing, newValue: updated, reason: body.reason });
    return NextResponse.json({ post: updated });
  });
}
