import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { communityComments } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(communityComments).orderBy(desc(communityComments.createdAt));
    return NextResponse.json({ comments: rows });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Comment id is required.");
    const existingRows = await db.select().from(communityComments).where(eq(communityComments.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Comment not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      if (!body.reason) return jsonError("A moderation reason is required to remove a comment.");
      await db.delete(communityComments).where(eq(communityComments.id, body.id));
      await writeAuditLog({ session, action: "comment.delete", targetType: "community_comment", targetId: body.id, previousValue: existing, reason: body.reason });
      return NextResponse.json({ ok: true });
    }

    const [updated] = await db
      .update(communityComments)
      .set({ hidden: body.hidden ?? existing.hidden })
      .where(eq(communityComments.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "comment.moderate", targetType: "community_comment", targetId: body.id, previousValue: existing, newValue: updated, reason: body.reason });
    return NextResponse.json({ comment: updated });
  });
}
