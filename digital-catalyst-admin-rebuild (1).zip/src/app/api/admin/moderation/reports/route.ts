import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { communityReports } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const rows = await db
      .select()
      .from(communityReports)
      .where(status ? eq(communityReports.status, status) : undefined)
      .orderBy(desc(communityReports.createdAt));
    return NextResponse.json({ reports: rows });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Report id is required.");
    const existingRows = await db.select().from(communityReports).where(eq(communityReports.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Report not found.", 404);
    const existing = existingRows[0];
    if (!body.moderationReason) return jsonError("A moderation reason is required to resolve a report.");

    const [updated] = await db
      .update(communityReports)
      .set({
        status: body.status ?? "resolved",
        moderationReason: body.moderationReason,
        resolvedBy: session.email,
        resolvedAt: new Date(),
      })
      .where(eq(communityReports.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "report.resolve", targetType: "community_report", targetId: body.id, previousValue: existing, newValue: updated, reason: body.moderationReason });
    return NextResponse.json({ report: updated });
  });
}
