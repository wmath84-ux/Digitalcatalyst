import { NextRequest, NextResponse } from "next/server";
import { and, gte, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { coinTransactions, customers, orders, products, reviews, subscriptionPlans } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";

function resolveRange(range: string | null, from: string | null, to: string | null) {
  const now = new Date();
  if (range === "today") {
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);
    return { start, end: now };
  }
  if (range === "7d") {
    return { start: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000), end: now };
  }
  if (range === "30d") {
    return { start: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000), end: now };
  }
  if (range === "custom" && from && to) {
    return { start: new Date(from), end: new Date(to) };
  }
  return { start: new Date(0), end: now };
}

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const range = searchParams.get("range") || "30d";
    const { start, end } = resolveRange(range, searchParams.get("from"), searchParams.get("to"));
    const dateFilter = and(gte(orders.createdAt, start), lte(orders.createdAt, end));

    const [revenueRow] = await db
      .select({
        revenue: sql<string>`coalesce(sum(${orders.finalAmount}) filter (where ${orders.paymentStatus} in ('verified','captured')), 0)`,
        orderCount: sql<number>`count(*)`,
        successCount: sql<number>`count(*) filter (where ${orders.paymentStatus} in ('verified','captured'))`,
        failedCount: sql<number>`count(*) filter (where ${orders.paymentStatus} = 'failed')`,
        uniqueBuyers: sql<number>`count(distinct ${orders.customerId})`,
      })
      .from(orders)
      .where(dateFilter);

    const [newUsersRow] = await db
      .select({ count: sql<number>`count(*)` })
      .from(customers)
      .where(and(gte(customers.joinedAt, start), lte(customers.joinedAt, end)));

    const topProducts = await db
      .select({ id: products.id, title: products.title, reviewCount: products.reviewCount, rating: products.rating })
      .from(products)
      .orderBy(sql`${products.reviewCount} desc`)
      .limit(5);

    const [coinRow] = await db
      .select({
        issued: sql<string>`coalesce(sum(${coinTransactions.amount}) filter (where ${coinTransactions.type} = 'earn'), 0)`,
        redeemed: sql<string>`coalesce(abs(sum(${coinTransactions.amount})) filter (where ${coinTransactions.type} = 'spend'), 0)`,
      })
      .from(coinTransactions)
      .where(and(gte(coinTransactions.createdAt, start), lte(coinTransactions.createdAt, end)));

    const [mrrRow] = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscriptionPlans)
      .where(sql`${subscriptionPlans.active} = true`);

    const [reviewRow] = await db
      .select({ avg: sql<string>`coalesce(avg(${reviews.rating}), 0)`, count: sql<number>`count(*)` })
      .from(reviews)
      .where(and(gte(reviews.createdAt, start), lte(reviews.createdAt, end)));

    const orderCount = Number(revenueRow?.orderCount ?? 0);
    const revenue = Number(revenueRow?.revenue ?? 0);

    return NextResponse.json({
      range: { start, end },
      revenue,
      orders: orderCount,
      averageOrderValue: orderCount > 0 ? Number((revenue / orderCount).toFixed(2)) : 0,
      uniqueBuyers: Number(revenueRow?.uniqueBuyers ?? 0),
      newUsers: Number(newUsersRow?.count ?? 0),
      paymentSuccessRate: orderCount > 0 ? Number(((Number(revenueRow?.successCount ?? 0) / orderCount) * 100).toFixed(1)) : 0,
      failedPayments: Number(revenueRow?.failedCount ?? 0),
      topProducts,
      coinsIssued: Number(coinRow?.issued ?? 0),
      coinsRedeemed: Number(coinRow?.redeemed ?? 0),
      activeSubscriptionPlans: Number(mrrRow?.count ?? 0),
      averageReviewRating: Number(reviewRow?.avg ?? 0),
      reviewsInRange: Number(reviewRow?.count ?? 0),
    });
  });
}
