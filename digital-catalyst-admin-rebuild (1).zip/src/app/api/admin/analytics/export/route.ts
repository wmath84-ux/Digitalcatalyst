import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { coinTransactions, coupons, customers, orders, subscriptionPlans } from "@/db/schema";
import { getAdminSession } from "@/lib/admin/auth";

function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const escape = (val: unknown) => {
    const str = val === null || val === undefined ? "" : typeof val === "object" ? JSON.stringify(val) : String(val);
    return `"${str.replace(/"/g, '""')}"`;
  };
  const lines = [headers.join(","), ...rows.map((row) => headers.map((h) => escape(row[h])).join(","))];
  return lines.join("\n");
}

export async function GET(req: NextRequest) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Admin session expired." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type") || "orders";

  let rows: Record<string, unknown>[] = [];
  if (type === "orders") rows = await db.select().from(orders);
  else if (type === "customers") rows = await db.select().from(customers);
  else if (type === "rewards") rows = await db.select().from(coinTransactions);
  else if (type === "subscriptions") rows = await db.select().from(subscriptionPlans);
  else if (type === "payments")
    rows = (await db.select().from(orders)).map((o) => ({
      id: o.id,
      paymentStatus: o.paymentStatus,
      gatewayOrderId: o.gatewayOrderId,
      gatewayPaymentId: o.gatewayPaymentId,
      finalAmount: o.finalAmount,
      createdAt: o.createdAt,
    }));

  const csv = toCsv(rows);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="${type}-export.csv"`,
    },
  });
}
