import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import {
  APPROVED_ADMIN_EMAIL,
  ADMIN_SESSION_COOKIE,
  createAdminSession,
  ensureSeedAdmin,
  verifyPassword,
} from "@/lib/admin/auth";

export async function POST(req: NextRequest) {
  try {
    await ensureSeedAdmin();

    const body = await req.json().catch(() => null);
    const rawEmail = typeof body?.email === "string" ? body.email : "";
    const password = typeof body?.password === "string" ? body.password : "";

    // 1. Normalize submitted email.
    const email = rawEmail.trim().toLowerCase();

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
    }

    // 2. Require exact approved admin email match.
    if (email !== APPROVED_ADMIN_EMAIL) {
      return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
    }

    const rows = await db.select().from(adminUsers).where(eq(adminUsers.email, email)).limit(1);
    const admin = rows[0];

    // 3. Authenticate credentials.
    if (!admin || !verifyPassword(password, admin.passwordHash)) {
      return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
    }

    // 4. Require exact role match.
    if (admin.role !== "admin") {
      return NextResponse.json({ error: "This account is not authorized for admin access." }, { status: 403 });
    }

    // 5. Create session marker (server-side, session cookie only — no maxAge).
    const token = await createAdminSession(admin.id);

    const res = NextResponse.json({
      email: admin.email,
      role: admin.role,
      adminId: admin.id,
    });

    res.cookies.set({
      name: ADMIN_SESSION_COOKIE,
      value: token,
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      // Intentionally no maxAge/expires: dies with the browser/PWA session.
    });

    return res;
  } catch {
    return NextResponse.json({ error: "Login failed. Please try again." }, { status: 500 });
  }
}
