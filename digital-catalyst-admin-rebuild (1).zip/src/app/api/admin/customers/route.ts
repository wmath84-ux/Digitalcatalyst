import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const status = searchParams.get("status");
    const provider = searchParams.get("provider");

    const conditions = [];
    if (q) {
      conditions.push(or(ilike(customers.name, `%${q}%`), ilike(customers.email, `%${q}%`), ilike(customers.uid, `%${q}%`)));
    }
    if (status) conditions.push(eq(customers.status, status));
    if (provider) conditions.push(eq(customers.provider, provider));

    const rows = await db
      .select()
      .from(customers)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(customers.joinedAt));

    return NextResponse.json({ customers: rows });
  });
}
