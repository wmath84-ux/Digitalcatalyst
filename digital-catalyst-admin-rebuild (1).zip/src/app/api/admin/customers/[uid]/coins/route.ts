import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { coinTransactions, customers } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

type Params = { params: Promise<{ uid: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  return withAdminSession(async (session) => {
    const { uid } = await params;
    const rows = await db.select().from(customers).where(eq(customers.uid, uid)).limit(1);
    if (!rows.length) return jsonError("Customer not found.", 404);
    const customer = rows[0];

    const body = await req.json().catch(() => null);
    const amount = Number(body?.amount);
    const type = body?.type === "spend" ? "spend" : "earn";
    const reason = typeof body?.reason === "string" ? body.reason.trim() : "";

    if (!Number.isFinite(amount) || amount <= 0) return jsonError("Amount must be a positive number.");
    if (!reason) return jsonError("A reason is mandatory for manual coin adjustments.");

    const balanceBefore = customer.coinBalance;
    const signedAmount = type === "earn" ? amount : -amount;
    const balanceAfter = balanceBefore + signedAmount;
    if (balanceAfter < 0) return jsonError("Adjustment would result in a negative balance.");

    const [updatedCustomer] = await db
      .update(customers)
      .set({ coinBalance: balanceAfter })
      .where(eq(customers.uid, uid))
      .returning();

    const [transaction] = await db
      .insert(coinTransactions)
      .values({
        customerId: uid,
        type,
        amount: signedAmount,
        balanceBefore,
        balanceAfter,
        source: "admin_adjustment",
        reason,
        adminId: String(session.adminId),
      })
      .returning();

    await writeAuditLog({
      session,
      action: "customer.coin_adjustment",
      targetType: "customer",
      targetId: uid,
      previousValue: { balance: balanceBefore },
      newValue: { balance: balanceAfter },
      reason,
    });

    return NextResponse.json({ customer: updatedCustomer, transaction });
  });
}
