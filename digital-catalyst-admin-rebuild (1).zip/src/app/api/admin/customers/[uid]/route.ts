import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders, reviews } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

type Params = { params: Promise<{ uid: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  return withAdminSession(async () => {
    const { uid } = await params;
    const rows = await db.select().from(customers).where(eq(customers.uid, uid)).limit(1);
    if (!rows.length) return jsonError("Customer not found.", 404);
    const [customerOrders, customerReviews] = await Promise.all([
      db.select().from(orders).where(eq(orders.customerId, uid)),
      db.select().from(reviews).where(eq(reviews.customerId, uid)),
    ]);
    return NextResponse.json({ customer: rows[0], orders: customerOrders, reviews: customerReviews });
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return withAdminSession(async (session) => {
    const { uid } = await params;
    const rows = await db.select().from(customers).where(eq(customers.uid, uid)).limit(1);
    if (!rows.length) return jsonError("Customer not found.", 404);
    const existing = rows[0];

    const body = await req.json().catch(() => ({}));
    const allowed: Partial<typeof existing> = {};
    if (body.status) allowed.status = body.status;
    if (body.role) allowed.role = body.role;

    const [updated] = await db.update(customers).set(allowed).where(eq(customers.uid, uid)).returning();

    await writeAuditLog({
      session,
      action: body.status ? "customer.status_change" : "customer.update",
      targetType: "customer",
      targetId: uid,
      previousValue: { status: existing.status, role: existing.role },
      newValue: { status: updated.status, role: updated.role },
      reason: body.reason,
    });

    return NextResponse.json({ customer: updated });
  });
}
