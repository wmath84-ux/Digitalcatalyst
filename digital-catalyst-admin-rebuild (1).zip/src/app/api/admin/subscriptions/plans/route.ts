import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptionPlans } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(subscriptionPlans).orderBy(desc(subscriptionPlans.updatedAt));
    return NextResponse.json({ plans: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.name) return jsonError("Plan name is required.");
    const id = body.id?.trim() || genId("plan");
    const [created] = await db
      .insert(subscriptionPlans)
      .values({
        id,
        name: body.name,
        description: body.description ?? "",
        billingCycles: body.billingCycles ?? [],
        accessTier: body.accessTier ?? "basic",
        badge: body.badge || null,
        cta: body.cta ?? "Subscribe",
        featured: body.featured ?? false,
        active: body.active ?? false,
        includedFeatureIds: body.includedFeatureIds ?? [],
        includedProductIds: body.includedProductIds ?? [],
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
      })
      .returning();
    await writeAuditLog({ session, action: "subscription_plan.create", targetType: "subscription_plan", targetId: id, newValue: created });
    return NextResponse.json({ plan: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Plan id is required.");
    const existingRows = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Plan not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, body.id));
      await writeAuditLog({ session, action: "subscription_plan.delete", targetType: "subscription_plan", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(subscriptionPlans)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        endDate: updates.endDate !== undefined ? (updates.endDate ? new Date(updates.endDate) : null) : existing.endDate,
        updatedAt: new Date(),
      })
      .where(eq(subscriptionPlans.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "subscription_plan.update", targetType: "subscription_plan", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ plan: updated });
  });
}
