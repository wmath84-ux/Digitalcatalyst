import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptionFeatures } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(subscriptionFeatures).orderBy(desc(subscriptionFeatures.createdAt));
    return NextResponse.json({ features: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.name || !body?.key) return jsonError("Feature key and name are required.");
    const id = body.id?.trim() || genId("feat");
    const [created] = await db
      .insert(subscriptionFeatures)
      .values({
        id,
        key: body.key,
        name: body.name,
        description: body.description ?? "",
        icon: body.icon ?? "",
        individualPrice: String(body.individualPrice ?? 0),
        includedInPlanIds: body.includedInPlanIds ?? [],
        badge: body.badge || null,
        active: body.active ?? true,
      })
      .returning();
    await writeAuditLog({ session, action: "subscription_feature.create", targetType: "subscription_feature", targetId: id, newValue: created });
    return NextResponse.json({ feature: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Feature id is required.");
    const existingRows = await db.select().from(subscriptionFeatures).where(eq(subscriptionFeatures.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Feature not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(subscriptionFeatures).where(eq(subscriptionFeatures.id, body.id));
      await writeAuditLog({ session, action: "subscription_feature.delete", targetType: "subscription_feature", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(subscriptionFeatures)
      .set(updates)
      .where(eq(subscriptionFeatures.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "subscription_feature.update", targetType: "subscription_feature", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ feature: updated });
  });
}
