import { NextResponse } from "next/server";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  badges,
  challenges,
  communityReports,
  coinTransactions,
  customers,
  orders,
  products,
  reviews,
  streaks,
  subscriptionPlans,
} from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";

export async function GET() {
  return withAdminSession(async () => {
    const [
      productStats,
      userStats,
      orderStats,
      revenueStats,
      subscriptionCount,
      coinStats,
      badgeCount,
      streakCount,
      challengeCount,
      pendingReviews,
      reportedContent,
      recentOrders,
    ] = await Promise.all([
      db
        .select({
          total: sql<number>`count(*)`,
          hidden: sql<number>`count(*) filter (where ${products.visibility} = 'hidden')`,
          unavailable: sql<number>`count(*) filter (where ${products.availableForSale} = false)`,
        })
        .from(products),
      db
        .select({
          total: sql<number>`count(*)`,
          active: sql<number>`count(*) filter (where ${customers.status} = 'active')`,
          blocked: sql<number>`count(*) filter (where ${customers.status} = 'blocked')`,
        })
        .from(customers),
      db
        .select({
          verified: sql<number>`count(*) filter (where ${orders.paymentStatus} = 'verified' or ${orders.paymentStatus} = 'captured')`,
          pending: sql<number>`count(*) filter (where ${orders.paymentStatus} in ('created','payment_pending','authorized'))`,
          failed: sql<number>`count(*) filter (where ${orders.paymentStatus} = 'failed')`,
        })
        .from(orders),
      db
        .select({
          revenue: sql<string>`coalesce(sum(${orders.finalAmount}) filter (where ${orders.paymentStatus} in ('verified','captured')), 0)`,
        })
        .from(orders),
      db
        .select({
          active: sql<number>`count(*) filter (where ${subscriptionPlans.active} = true)`,
        })
        .from(subscriptionPlans),
      db
        .select({
          issued: sql<string>`coalesce(sum(${coinTransactions.amount}) filter (where ${coinTransactions.type} = 'earn'), 0)`,
          redeemed: sql<string>`coalesce(abs(sum(${coinTransactions.amount})) filter (where ${coinTransactions.type} = 'spend'), 0)`,
        })
        .from(coinTransactions),
      db.select({ count: sql<number>`count(*)` }).from(badges).where(eq(badges.status, "active")),
      db.select({ count: sql<number>`count(*)` }).from(streaks).where(eq(streaks.status, "active")),
      db.select({ count: sql<number>`count(*)` }).from(challenges).where(eq(challenges.status, "active")),
      db.select({ count: sql<number>`count(*)` }).from(reviews).where(eq(reviews.status, "pending")),
      db.select({ count: sql<number>`count(*)` }).from(communityReports).where(eq(communityReports.status, "open")),
      db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
    ]);

    const expiringSoon = 0; // subscription cycle expiry tracked at customer/plan level; placeholder until real cycle data exists

    const attentionQueue: { id: string; label: string; type: string }[] = [];
    if (Number(orderStats[0]?.failed ?? 0) > 0) {
      attentionQueue.push({ id: "payments", label: `${orderStats[0].failed} payment(s) require review`, type: "payment" });
    }
    const blockedCount = Number(userStats[0]?.blocked ?? 0);
    if (blockedCount > 0) {
      attentionQueue.push({ id: "users", label: `${blockedCount} blocked/suspicious user(s)`, type: "user" });
    }
    const invalidProducts = await db
      .select({ count: sql<number>`count(*)` })
      .from(products)
      .where(and(eq(products.availableForSale, true), sql`${products.regularPrice} <= 0`));
    if (Number(invalidProducts[0]?.count ?? 0) > 0) {
      attentionQueue.push({ id: "products", label: `${invalidProducts[0].count} product(s) with invalid pricing`, type: "product" });
    }
    const reportedCount = Number(reportedContent[0]?.count ?? 0);
    if (reportedCount > 0) {
      attentionQueue.push({ id: "reports", label: `${reportedCount} reported community item(s)`, type: "moderation" });
    }
    const pendingReviewCount = Number(pendingReviews[0]?.count ?? 0);
    if (pendingReviewCount > 0) {
      attentionQueue.push({ id: "reviews", label: `${pendingReviewCount} review(s) awaiting moderation`, type: "review" });
    }

    return NextResponse.json({
      products: {
        total: Number(productStats[0]?.total ?? 0),
        hidden: Number(productStats[0]?.hidden ?? 0),
        unavailable: Number(productStats[0]?.unavailable ?? 0),
      },
      users: {
        total: Number(userStats[0]?.total ?? 0),
        active: Number(userStats[0]?.active ?? 0),
        blocked: Number(userStats[0]?.blocked ?? 0),
      },
      orders: {
        verified: Number(orderStats[0]?.verified ?? 0),
        pending: Number(orderStats[0]?.pending ?? 0),
        failed: Number(orderStats[0]?.failed ?? 0),
      },
      revenue: {
        total: Number(revenueStats[0]?.revenue ?? 0),
      },
      subscriptions: {
        active: Number(subscriptionCount[0]?.active ?? 0),
        expiring: expiringSoon,
      },
      coins: {
        issued: Number(coinStats[0]?.issued ?? 0),
        redeemed: Number(coinStats[0]?.redeemed ?? 0),
      },
      badges: { active: Number(badgeCount[0]?.count ?? 0) },
      streaks: { active: Number(streakCount[0]?.count ?? 0) },
      challenges: { active: Number(challengeCount[0]?.count ?? 0) },
      reviews: { pending: pendingReviewCount },
      moderation: { reported: reportedCount },
      recentOrders,
      attentionQueue,
    });
  });
}
