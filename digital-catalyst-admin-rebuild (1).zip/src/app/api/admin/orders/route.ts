import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte, ilike, lte, or } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const status = searchParams.get("status");
    const kind = searchParams.get("kind");
    const from = searchParams.get("from");
    const to = searchParams.get("to");

    const conditions = [];
    if (q) {
      conditions.push(
        or(ilike(orders.id, `%${q}%`), ilike(orders.customerName, `%${q}%`), ilike(orders.customerEmail, `%${q}%`))
      );
    }
    if (status) conditions.push(eq(orders.paymentStatus, status));
    if (kind) conditions.push(eq(orders.purchaseKind, kind));
    if (from) conditions.push(gte(orders.createdAt, new Date(from)));
    if (to) conditions.push(lte(orders.createdAt, new Date(to)));

    const rows = await db
      .select()
      .from(orders)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(orders.createdAt));

    return NextResponse.json({ orders: rows });
  });
}
