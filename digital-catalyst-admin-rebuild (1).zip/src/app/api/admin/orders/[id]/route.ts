import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  return withAdminSession(async () => {
    const { id } = await params;
    const rows = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    if (!rows.length) return jsonError("Order not found.", 404);
    return NextResponse.json({ order: rows[0] });
  });
}
