import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { aiSettings } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

async function ensureRow() {
  const rows = await db.select().from(aiSettings).where(eq(aiSettings.id, 1)).limit(1);
  if (rows.length) return rows[0];
  const providerStatus: Record<string, string> = {
    gemini: process.env.GEMINI_API_KEY ? "configured" : "not_configured",
    openai: process.env.OPENAI_API_KEY ? "configured" : "not_configured",
  };
  const [created] = await db.insert(aiSettings).values({ id: 1, providerStatus }).returning();
  return created;
}

export async function GET() {
  return withAdminSession(async () => {
    const settings = await ensureRow();
    // Never expose provider API keys — only configuration status.
    const providerStatus: Record<string, string> = {
      gemini: process.env.GEMINI_API_KEY ? "configured" : "not_configured",
      openai: process.env.OPENAI_API_KEY ? "configured" : "not_configured",
    };
    return NextResponse.json({ settings: { ...settings, providerStatus } });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const existing = await ensureRow();
    const body = await req.json().catch(() => ({}));
    delete body.providerStatus;
    const [updated] = await db
      .update(aiSettings)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(aiSettings.id, 1))
      .returning();
    await writeAuditLog({ session, action: "ai_settings.update", targetType: "ai_settings", targetId: "1", previousValue: existing, newValue: updated });
    return NextResponse.json({ settings: updated });
  });
}
