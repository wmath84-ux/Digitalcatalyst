import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appContentSettings } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

async function ensureRow() {
  const rows = await db.select().from(appContentSettings).where(eq(appContentSettings.id, 1)).limit(1);
  if (rows.length) return rows[0];
  const [created] = await db.insert(appContentSettings).values({ id: 1 }).returning();
  return created;
}

export async function GET() {
  return withAdminSession(async () => {
    const settings = await ensureRow();
    return NextResponse.json({ settings });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const existing = await ensureRow();
    const body = await req.json().catch(() => ({}));
    const [updated] = await db
      .update(appContentSettings)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(appContentSettings.id, 1))
      .returning();
    await writeAuditLog({ session, action: "app_content.update", targetType: "app_content_settings", targetId: "1", previousValue: existing, newValue: updated });
    return NextResponse.json({ settings: updated });
  });
}
