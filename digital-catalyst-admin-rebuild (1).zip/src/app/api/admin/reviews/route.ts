import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const status = searchParams.get("status");
    const rating = searchParams.get("rating");
    const productId = searchParams.get("productId");

    const conditions = [];
    if (q) conditions.push(ilike(reviews.comment, `%${q}%`));
    if (status) conditions.push(eq(reviews.status, status));
    if (rating) conditions.push(eq(reviews.rating, Number(rating)));
    if (productId) conditions.push(eq(reviews.productId, productId));

    const rows = await db
      .select()
      .from(reviews)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(reviews.createdAt));
    return NextResponse.json({ reviews: rows });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Review id is required.");
    const existingRows = await db.select().from(reviews).where(eq(reviews.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Review not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(reviews).where(eq(reviews.id, body.id));
      await writeAuditLog({ session, action: "review.delete", targetType: "review", targetId: body.id, previousValue: existing, reason: body.reason });
      return NextResponse.json({ ok: true });
    }

    if (body.status === "rejected" && !body.reportReason && !existing.reportReason) {
      return jsonError("A reason is required to reject a review.");
    }

    const updates: Record<string, unknown> = {};
    if (body.status) updates.status = body.status;
    if (body.reportReason !== undefined) updates.reportReason = body.reportReason;
    if (body.adminReply !== undefined) updates.adminReply = body.adminReply;

    const [updated] = await db.update(reviews).set(updates).where(eq(reviews.id, body.id)).returning();
    await writeAuditLog({
      session,
      action: "review.moderate",
      targetType: "review",
      targetId: body.id,
      previousValue: existing,
      newValue: updated,
      reason: body.reportReason,
    });
    return NextResponse.json({ review: updated });
  });
}
