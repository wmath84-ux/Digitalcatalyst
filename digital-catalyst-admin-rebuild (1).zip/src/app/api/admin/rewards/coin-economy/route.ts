import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { coinEconomySettings } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

async function ensureRow() {
  const rows = await db.select().from(coinEconomySettings).where(eq(coinEconomySettings.id, 1)).limit(1);
  if (rows.length) return rows[0];
  const [created] = await db.insert(coinEconomySettings).values({ id: 1 }).returning();
  return created;
}

export async function GET() {
  return withAdminSession(async () => {
    const settings = await ensureRow();
    return NextResponse.json({ settings });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const existing = await ensureRow();
    const body = await req.json().catch(() => ({}));
    const [updated] = await db
      .update(coinEconomySettings)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(coinEconomySettings.id, 1))
      .returning();
    await writeAuditLog({
      session,
      action: "coin_economy.update",
      targetType: "coin_economy_settings",
      targetId: "1",
      previousValue: existing,
      newValue: updated,
    });
    return NextResponse.json({ settings: updated });
  });
}
