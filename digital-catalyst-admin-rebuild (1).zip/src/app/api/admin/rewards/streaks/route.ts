import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { streaks } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(streaks).orderBy(desc(streaks.updatedAt));
    return NextResponse.json({ streaks: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.title) return jsonError("Title is required.");
    const id = body.id?.trim() || genId("streak");
    const [created] = await db
      .insert(streaks)
      .values({
        id,
        title: body.title,
        icon: body.icon ?? "",
        category: body.category ?? "",
        metric: body.metric ?? "",
        goal: body.goal ?? 1,
        unit: body.unit ?? "days",
        frequency: body.frequency ?? "daily",
        consecutiveRequirement: body.consecutiveRequirement ?? 1,
        resetRule: body.resetRule ?? "midnight",
        gracePeriodHours: body.gracePeriodHours ?? 0,
        coinReward: body.coinReward ?? 0,
        badgeReward: body.badgeReward || null,
        unlockProductId: body.unlockProductId || null,
        motivationNote: body.motivationNote ?? "",
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        status: body.status ?? "draft",
      })
      .returning();
    await writeAuditLog({ session, action: "streak.create", targetType: "streak", targetId: id, newValue: created });
    return NextResponse.json({ streak: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Streak id is required.");
    const existingRows = await db.select().from(streaks).where(eq(streaks.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Streak not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(streaks).where(eq(streaks.id, body.id));
      await writeAuditLog({ session, action: "streak.delete", targetType: "streak", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(streaks)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        endDate: updates.endDate !== undefined ? (updates.endDate ? new Date(updates.endDate) : null) : existing.endDate,
        updatedAt: new Date(),
      })
      .where(eq(streaks.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "streak.update", targetType: "streak", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ streak: updated });
  });
}
