import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { challenges } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(challenges).orderBy(desc(challenges.updatedAt));
    return NextResponse.json({ challenges: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.title) return jsonError("Title is required.");
    const id = body.id?.trim() || genId("chal");
    const [created] = await db
      .insert(challenges)
      .values({
        id,
        title: body.title,
        icon: body.icon ?? "",
        description: body.description ?? "",
        category: body.category ?? "",
        metric: body.metric ?? "",
        requirement: body.requirement ?? "",
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        repeatable: body.repeatable ?? false,
        perUserClaimLimit: body.perUserClaimLimit ?? 1,
        coinReward: body.coinReward ?? 0,
        badgeReward: body.badgeReward || null,
        couponReward: body.couponReward || null,
        unlockProductId: body.unlockProductId || null,
        ctaLabel: body.ctaLabel ?? "Join challenge",
        sortOrder: body.sortOrder ?? 0,
        status: body.status ?? "draft",
      })
      .returning();
    await writeAuditLog({ session, action: "challenge.create", targetType: "challenge", targetId: id, newValue: created });
    return NextResponse.json({ challenge: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Challenge id is required.");
    const existingRows = await db.select().from(challenges).where(eq(challenges.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Challenge not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(challenges).where(eq(challenges.id, body.id));
      await writeAuditLog({ session, action: "challenge.delete", targetType: "challenge", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(challenges)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        endDate: updates.endDate !== undefined ? (updates.endDate ? new Date(updates.endDate) : null) : existing.endDate,
        updatedAt: new Date(),
      })
      .where(eq(challenges.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "challenge.update", targetType: "challenge", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ challenge: updated });
  });
}
