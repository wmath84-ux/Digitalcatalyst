import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { coinTransactions } from "@/db/schema";
import { withAdminSession } from "@/lib/admin/api-helpers";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const type = searchParams.get("type");
    const source = searchParams.get("source");

    const conditions = [];
    if (q) conditions.push(ilike(coinTransactions.customerId, `%${q}%`));
    if (type) conditions.push(eq(coinTransactions.type, type));
    if (source) conditions.push(eq(coinTransactions.source, source));

    const rows = await db
      .select()
      .from(coinTransactions)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(coinTransactions.createdAt))
      .limit(500);

    return NextResponse.json({ transactions: rows });
  });
}
