import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { badges } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(badges).orderBy(desc(badges.updatedAt));
    return NextResponse.json({ badges: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.title) return jsonError("Title is required.");
    const id = body.id?.trim() || genId("badge");

    const [created] = await db
      .insert(badges)
      .values({
        id,
        title: body.title,
        icon: body.icon ?? "",
        description: body.description ?? "",
        category: body.category ?? "",
        rarity: body.rarity ?? "common",
        triggerMetric: body.triggerMetric ?? "",
        requirement: body.requirement ?? "",
        coinReward: body.coinReward ?? 0,
        unlockProductId: body.unlockProductId || null,
        subscriptionReward: body.subscriptionReward || null,
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        claimLimit: body.claimLimit ?? 0,
        sortOrder: body.sortOrder ?? 0,
        status: body.status ?? "draft",
      })
      .returning();

    await writeAuditLog({ session, action: "badge.create", targetType: "badge", targetId: id, newValue: created });
    return NextResponse.json({ badge: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Badge id is required.");
    const existingRows = await db.select().from(badges).where(eq(badges.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Badge not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      if (existing.claimedCount > 0) {
        return jsonError("Cannot delete a badge that has already been claimed. Archive it instead.");
      }
      await db.delete(badges).where(eq(badges.id, body.id));
      await writeAuditLog({ session, action: "badge.delete", targetType: "badge", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(badges)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        endDate: updates.endDate !== undefined ? (updates.endDate ? new Date(updates.endDate) : null) : existing.endDate,
        updatedAt: new Date(),
      })
      .where(eq(badges.id, body.id))
      .returning();

    await writeAuditLog({
      session,
      action: "badge.update",
      targetType: "badge",
      targetId: body.id,
      previousValue: existing,
      newValue: updated,
    });
    return NextResponse.json({ badge: updated });
  });
}
