import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { redeemItems } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET() {
  return withAdminSession(async () => {
    const rows = await db.select().from(redeemItems).orderBy(desc(redeemItems.updatedAt));
    return NextResponse.json({ redeemItems: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.title) return jsonError("Title is required.");
    const id = body.id?.trim() || genId("redeem");
    const [created] = await db
      .insert(redeemItems)
      .values({
        id,
        title: body.title,
        description: body.description ?? "",
        icon: body.icon ?? "",
        coinCost: body.coinCost ?? 0,
        rewardType: body.rewardType ?? "coupon",
        couponId: body.couponId || null,
        discount: body.discount || null,
        productUnlockId: body.productUnlockId || null,
        moduleUnlockId: body.moduleUnlockId || null,
        updateUnlockId: body.updateUnlockId || null,
        subscriptionAccess: body.subscriptionAccess || null,
        badgeReward: body.badgeReward || null,
        stockLimit: body.stockLimit ?? 0,
        perUserLimit: body.perUserLimit ?? 1,
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        confirmationMessage: body.confirmationMessage ?? "",
        terms: body.terms ?? "",
        sortOrder: body.sortOrder ?? 0,
        status: body.status ?? "draft",
      })
      .returning();
    await writeAuditLog({ session, action: "redeem_item.create", targetType: "redeem_item", targetId: id, newValue: created });
    return NextResponse.json({ redeemItem: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Redeem item id is required.");
    const existingRows = await db.select().from(redeemItems).where(eq(redeemItems.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Redeem item not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(redeemItems).where(eq(redeemItems.id, body.id));
      await writeAuditLog({ session, action: "redeem_item.delete", targetType: "redeem_item", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    const [updated] = await db
      .update(redeemItems)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        endDate: updates.endDate !== undefined ? (updates.endDate ? new Date(updates.endDate) : null) : existing.endDate,
        updatedAt: new Date(),
      })
      .where(eq(redeemItems.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "redeem_item.update", targetType: "redeem_item", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ redeemItem: updated });
  });
}
