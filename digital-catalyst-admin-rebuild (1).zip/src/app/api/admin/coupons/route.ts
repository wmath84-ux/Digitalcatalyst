import { NextRequest, NextResponse } from "next/server";
import { desc, eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const rows = await db
      .select()
      .from(coupons)
      .where(q ? ilike(coupons.code, `%${q}%`) : undefined)
      .orderBy(desc(coupons.updatedAt));
    return NextResponse.json({ coupons: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.code) return jsonError("Coupon code is required.");
    const id = body.id?.trim() || genId("coupon");
    const code = String(body.code).toUpperCase().trim();

    const existing = await db.select().from(coupons).where(eq(coupons.code, code)).limit(1);
    if (existing.length) return jsonError("A coupon with this code already exists.", 409);

    const [created] = await db
      .insert(coupons)
      .values({
        id,
        code,
        discountType: body.discountType ?? "percentage",
        value: String(body.value ?? 0),
        startDate: body.startDate ? new Date(body.startDate) : null,
        expiryDate: body.expiryDate ? new Date(body.expiryDate) : null,
        active: body.active ?? true,
        globalUsageLimit: body.globalUsageLimit ?? 0,
        perUserUsageLimit: body.perUserUsageLimit ?? 1,
        minOrder: String(body.minOrder ?? 0),
        maxDiscount: String(body.maxDiscount ?? 0),
        eligibleProducts: body.eligibleProducts ?? [],
        eligibleModules: body.eligibleModules ?? [],
        eligibleSubscriptions: body.eligibleSubscriptions ?? [],
        eligibleCategories: body.eligibleCategories ?? [],
        firstPurchaseOnly: body.firstPurchaseOnly ?? false,
      })
      .returning();
    await writeAuditLog({ session, action: "coupon.create", targetType: "coupon", targetId: id, newValue: created });
    return NextResponse.json({ coupon: created }, { status: 201 });
  });
}

export async function PATCH(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.id) return jsonError("Coupon id is required.");
    const existingRows = await db.select().from(coupons).where(eq(coupons.id, body.id)).limit(1);
    if (!existingRows.length) return jsonError("Coupon not found.", 404);
    const existing = existingRows[0];

    if (body.delete) {
      await db.delete(coupons).where(eq(coupons.id, body.id));
      await writeAuditLog({ session, action: "coupon.delete", targetType: "coupon", targetId: body.id, previousValue: existing });
      return NextResponse.json({ ok: true });
    }

    const { id: _ignored, delete: _d, ...updates } = body;
    void _ignored;
    void _d;
    if (updates.code) updates.code = String(updates.code).toUpperCase().trim();

    const [updated] = await db
      .update(coupons)
      .set({
        ...updates,
        startDate: updates.startDate !== undefined ? (updates.startDate ? new Date(updates.startDate) : null) : existing.startDate,
        expiryDate: updates.expiryDate !== undefined ? (updates.expiryDate ? new Date(updates.expiryDate) : null) : existing.expiryDate,
        updatedAt: new Date(),
      })
      .where(eq(coupons.id, body.id))
      .returning();
    await writeAuditLog({ session, action: "coupon.update", targetType: "coupon", targetId: body.id, previousValue: existing, newValue: updated });
    return NextResponse.json({ coupon: updated });
  });
}
