import { NextRequest, NextResponse } from "next/server";
import { and, asc, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { genId, jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

export async function GET(req: NextRequest) {
  return withAdminSession(async () => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const visibility = searchParams.get("visibility");
    const availability = searchParams.get("availability");
    const pricing = searchParams.get("pricing"); // free | paid
    const sort = searchParams.get("sort") || "newest";

    const conditions = [];
    if (q) {
      conditions.push(
        or(ilike(products.title, `%${q}%`), ilike(products.id, `%${q}%`), ilike(products.category, `%${q}%`))
      );
    }
    if (visibility === "visible" || visibility === "hidden") {
      conditions.push(eq(products.visibility, visibility));
    }
    if (availability === "available") {
      conditions.push(eq(products.availableForSale, true));
    } else if (availability === "unavailable") {
      conditions.push(eq(products.availableForSale, false));
    }
    if (pricing === "free") {
      conditions.push(eq(products.isFree, true));
    } else if (pricing === "paid") {
      conditions.push(eq(products.isFree, false));
    }

    const orderBy =
      sort === "title"
        ? asc(products.title)
        : sort === "price"
          ? desc(products.regularPrice)
          : sort === "rating"
            ? desc(products.rating)
            : desc(products.updatedAt);

    const rows = await db
      .select()
      .from(products)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(orderBy);

    return NextResponse.json({ products: rows });
  });
}

export async function POST(req: NextRequest) {
  return withAdminSession(async (session) => {
    const body = await req.json().catch(() => null);
    if (!body?.title || !body?.shortDescription) {
      return jsonError("Title and short description are required.");
    }
    const id = body.id?.trim() || genId("prod");
    const existing = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (existing.length) {
      return jsonError("A product with this ID already exists.", 409);
    }
    if (body.salePrice && Number(body.salePrice) > Number(body.regularPrice ?? 0)) {
      return jsonError("Sale price cannot exceed regular price.");
    }

    const [created] = await db
      .insert(products)
      .values({
        id,
        title: body.title,
        shortDescription: body.shortDescription,
        longDescription: body.longDescription ?? "",
        instructor: body.instructor ?? "",
        category: body.category ?? "",
        productType: body.productType ?? "course",
        classLevel: body.classLevel ?? "",
        subject: body.subject ?? "",
        sku: body.sku ?? "",
        tags: body.tags ?? [],
        searchKeywords: body.searchKeywords ?? [],
        features: body.features ?? [],
        estimatedDuration: body.estimatedDuration ?? "",
        language: body.language ?? "English",
        manualRating: body.manualRating ?? null,
        visibility: body.visibility ?? "hidden",
        availableForSale: body.availableForSale ?? false,
        images: body.images ?? [],
        regularPrice: String(body.regularPrice ?? 0),
        salePrice: body.salePrice != null ? String(body.salePrice) : null,
        coinPrice: body.coinPrice ?? 0,
        coinPurchaseEnabled: body.coinPurchaseEnabled ?? false,
        isFree: body.isFree ?? false,
        eligibleCouponIds: body.eligibleCouponIds ?? [],
        minPayableAmount: body.minPayableAmount != null ? String(body.minPayableAmount) : "0",
        availabilityDate: body.availabilityDate ? new Date(body.availabilityDate) : null,
        saleStart: body.saleStart ? new Date(body.saleStart) : null,
        saleEnd: body.saleEnd ? new Date(body.saleEnd) : null,
        modules: body.modules ?? [],
        paidUpdates: body.paidUpdates ?? [],
        status: body.status ?? "draft",
      })
      .returning();

    await writeAuditLog({
      session,
      action: "product.create",
      targetType: "product",
      targetId: id,
      newValue: created,
    });

    return NextResponse.json({ product: created }, { status: 201 });
  });
}

export const dynamic = "force-dynamic";
