import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { jsonError, withAdminSession } from "@/lib/admin/api-helpers";
import { writeAuditLog } from "@/lib/admin/audit";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  return withAdminSession(async () => {
    const { id } = await params;
    const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (!rows.length) return jsonError("Product not found.", 404);
    return NextResponse.json({ product: rows[0] });
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  return withAdminSession(async (session) => {
    const { id } = await params;
    const existingRows = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (!existingRows.length) return jsonError("Product not found.", 404);
    const existing = existingRows[0];

    const body = await req.json().catch(() => null);
    if (!body) return jsonError("Invalid request body.");

    if (body.salePrice != null && Number(body.salePrice) > Number(body.regularPrice ?? existing.regularPrice)) {
      return jsonError("Sale price cannot exceed regular price.");
    }

    const nextValues = {
      title: body.title ?? existing.title,
      shortDescription: body.shortDescription ?? existing.shortDescription,
      longDescription: body.longDescription ?? existing.longDescription,
      instructor: body.instructor ?? existing.instructor,
      category: body.category ?? existing.category,
      productType: body.productType ?? existing.productType,
      classLevel: body.classLevel ?? existing.classLevel,
      subject: body.subject ?? existing.subject,
      sku: body.sku ?? existing.sku,
      tags: body.tags ?? existing.tags,
      searchKeywords: body.searchKeywords ?? existing.searchKeywords,
      features: body.features ?? existing.features,
      estimatedDuration: body.estimatedDuration ?? existing.estimatedDuration,
      language: body.language ?? existing.language,
      manualRating: body.manualRating !== undefined ? body.manualRating : existing.manualRating,
      visibility: body.visibility ?? existing.visibility,
      availableForSale: body.availableForSale ?? existing.availableForSale,
      images: body.images ?? existing.images,
      regularPrice: body.regularPrice != null ? String(body.regularPrice) : existing.regularPrice,
      salePrice: body.salePrice !== undefined ? (body.salePrice != null ? String(body.salePrice) : null) : existing.salePrice,
      coinPrice: body.coinPrice ?? existing.coinPrice,
      coinPurchaseEnabled: body.coinPurchaseEnabled ?? existing.coinPurchaseEnabled,
      isFree: body.isFree ?? existing.isFree,
      eligibleCouponIds: body.eligibleCouponIds ?? existing.eligibleCouponIds,
      minPayableAmount:
        body.minPayableAmount !== undefined ? String(body.minPayableAmount) : existing.minPayableAmount,
      availabilityDate: body.availabilityDate !== undefined
        ? (body.availabilityDate ? new Date(body.availabilityDate) : null)
        : existing.availabilityDate,
      saleStart: body.saleStart !== undefined ? (body.saleStart ? new Date(body.saleStart) : null) : existing.saleStart,
      saleEnd: body.saleEnd !== undefined ? (body.saleEnd ? new Date(body.saleEnd) : null) : existing.saleEnd,
      modules: body.modules ?? existing.modules,
      paidUpdates: body.paidUpdates ?? existing.paidUpdates,
      status: body.status ?? existing.status,
      updatedAt: new Date(),
    };

    const [updated] = await db.update(products).set(nextValues).where(eq(products.id, id)).returning();

    await writeAuditLog({
      session,
      action: "product.update",
      targetType: "product",
      targetId: id,
      previousValue: existing,
      newValue: updated,
      reason: body.reason,
    });

    return NextResponse.json({ product: updated });
  });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  return withAdminSession(async (session) => {
    const { id } = await params;
    const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (!rows.length) return jsonError("Product not found.", 404);

    const body = await req.json().catch(() => ({}));

    await db.delete(products).where(eq(products.id, id));

    await writeAuditLog({
      session,
      action: "product.delete",
      targetType: "product",
      targetId: id,
      previousValue: rows[0],
      reason: body?.reason ?? "Admin deletion",
    });

    return NextResponse.json({ ok: true });
  });
}
