import { useRef } from "react";
import { motion } from "framer-motion";
import { Plus } from "lucide-react";

interface UniversalCreatePillProps {
  onOpen: (rect: DOMRect) => void;
}

export function UniversalCreatePill({ onOpen }: UniversalCreatePillProps) {
  const ref = useRef<HTMLButtonElement>(null);

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 flex justify-center pb-[max(1rem,env(safe-area-inset-bottom))] sm:pb-6">
      <motion.button
        ref={ref}
        type="button"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        whileHover={{ scale: 1.035, y: -2 }}
        whileTap={{ scale: 0.97 }}
        onClick={() => ref.current && onOpen(ref.current.getBoundingClientRect())}
        className="glass-panel-strong pointer-events-auto relative flex items-center gap-2 overflow-hidden rounded-full px-7 py-3.5 text-sm font-semibold tracking-wide text-fp-text sm:px-9 sm:py-4"
        style={{
          boxShadow:
            "0 0 0 1px var(--fp-border) inset, 0 0 40px -6px rgba(139,123,255,0.55), 0 25px 60px -20px rgba(0,0,0,0.9)",
        }}
      >
        <span className="fp-shimmer pointer-events-none absolute inset-0" />
        <span className="relative grid h-5 w-5 place-items-center rounded-full bg-fp-text-15">
          <Plus className="h-3.5 w-3.5" strokeWidth={2.6} />
        </span>
        <span className="relative font-display">CREATE</span>
      </motion.button>
    </div>
  );
}
