import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence } from "framer-motion";
import type { ActivityType } from "../../types/flowpath";
import { useFlowPath } from "../../hooks/useFlowPath";
import { useTheme } from "../../hooks/useTheme";
import { buildRows, buildSmoothPath, chunkRows, getLayoutConfig, type FlowRow } from "../../lib/layout";
import { animateScrollTo } from "../../lib/scroll";
import type { CurveOverride } from "../../types/curve";
import { DEFAULT_CURVE_OVERRIDE } from "../../types/curve";
import { CurveSettingsModal } from "./CurveSettingsModal";
import { Ribbon } from "./Ribbon";
import { ActivityNode } from "./ActivityNode";
import { ActivityCard } from "./ActivityCard";
import { PlusNode } from "./PlusNode";
import { RadialMenu } from "./RadialMenu";
import { CreateModal } from "./CreateModal";
import { EmptyState } from "./EmptyState";
import { UniversalCreatePill } from "./UniversalCreatePill";
import { FlowPathHeader } from "./Header";

const SCROLL_BUFFER = 900;
const CHUNK_SIZE = 8;

interface PendingMenu {
  afterId: string | null;
  rect: DOMRect;
}

function PulseLight({ d, onDone }: { d: string; onDone: () => void }) {
  const [go, setGo] = useState(false);

  useEffect(() => {
    const raf1 = requestAnimationFrame(() => {
      requestAnimationFrame(() => setGo(true));
    });
    const t = setTimeout(onDone, 1350);
    return () => {
      cancelAnimationFrame(raf1);
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const style = {
    offsetPath: `path("${d}")`,
    offsetDistance: go ? "100%" : "0%",
    offsetRotate: "0deg",
    opacity: go ? 0 : 1,
    transition:
      "offset-distance 1.15s cubic-bezier(0.22,1,0.36,1), opacity 1.15s cubic-bezier(0.22,1,0.36,1)",
  } as unknown as React.CSSProperties;

  return (
    <div
      className="pointer-events-none absolute left-0 top-0 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full"
      style={{
        ...style,
        background: "radial-gradient(circle, #ffffff, #8b7bff 55%, transparent 75%)",
        boxShadow: "0 0 22px 8px rgba(139,123,255,0.75)",
      }}
    />
  );
}

export function FlowPathView() {
  const { items, currentId, createActivity, completeActivity, pulseToken, justCreatedId, clearJustCreated } =
    useFlowPath();
  const { mode: themeMode, resolved: resolvedTheme, toggle: toggleTheme } = useTheme();

  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const [visible, setVisible] = useState({ top: -10000, bottom: 10000 });
  const [menu, setMenu] = useState<PendingMenu | null>(null);
  const [createType, setCreateType] = useState<{ type: ActivityType; afterId: string | null } | null>(
    null
  );
  const [completingIds, setCompletingIds] = useState<Set<string>>(new Set());
  const [pulseSegment, setPulseSegment] = useState<{ key: number; d: string } | null>(null);
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [curveOpen, setCurveOpen] = useState(false);
  const [curve, setCurve] = useState<CurveOverride>(DEFAULT_CURVE_OVERRIDE);

  const hasAutoScrolled = useRef(false);
  const isEmpty = items.length === 0;

  // measure container width responsively
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setWidth(entry.contentRect.width);
      }
    });
    ro.observe(el);
    setWidth(el.getBoundingClientRect().width);
    return () => ro.disconnect();
  }, []);

  const config = useMemo(() => getLayoutConfig(width, curve), [width, curve]);
  const { rows, totalHeight } = useMemo(() => buildRows(items, config), [items, config]);

  const chunks = useMemo(() => chunkRows(rows, CHUNK_SIZE), [rows]);

  // scroll-driven virtualization window
  useEffect(() => {
    let raf = 0;
    let ticking = false;

    function measure() {
      ticking = false;
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      setVisible({
        top: -rect.top - SCROLL_BUFFER,
        bottom: -rect.top + window.innerHeight + SCROLL_BUFFER,
      });
    }

    function onScroll() {
      if (ticking) return;
      ticking = true;
      raf = requestAnimationFrame(measure);
    }

    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, [totalHeight]);

  const visibleChunkPoints = useMemo(() => {
    return chunks
      .filter((chunk) => {
        if (!chunk.length) return false;
        const first = chunk[0];
        const last = chunk[chunk.length - 1];
        return !(last.y + last.height < visible.top || first.y > visible.bottom);
      })
      .map((chunk) => chunk.map((r) => ({ x: r.x, y: r.y })));
  }, [chunks, visible]);

  const visibleRows = useMemo(
    () => rows.filter((r) => r.y + r.height >= visible.top && r.y <= visible.bottom),
    [rows, visible]
  );

  // cinematic auto-focus on the current activity, once per session
  useEffect(() => {
    if (hasAutoScrolled.current) return;
    if (!rows.length || !currentId || width <= 0) return;
    const row = rows.find((r) => r.activity?.activity.id === currentId);
    if (!row) return;
    hasAutoScrolled.current = true;

    let cancelled = false;
    const cancel = () => {
      cancelled = true;
    };
    const opts = { once: true, passive: true } as AddEventListenerOptions;
    window.addEventListener("wheel", cancel, opts);
    window.addEventListener("touchstart", cancel, opts);
    window.addEventListener("keydown", cancel, opts);

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        if (cancelled || !containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const targetAbsolute = rect.top + window.scrollY + row.y + row.height / 2;
        const targetScroll = Math.max(0, targetAbsolute - window.innerHeight / 2);
        if (reduced) {
          window.scrollTo(0, targetScroll);
        } else {
          animateScrollTo(targetScroll, 950, () => cancelled);
        }
      })
    );

    return () => {
      window.removeEventListener("wheel", cancel);
      window.removeEventListener("touchstart", cancel);
      window.removeEventListener("keydown", cancel);
    };
  }, [rows, currentId, width]);

  // focus newly created nodes
  useEffect(() => {
    if (!justCreatedId) return;
    const row = rows.find((r) => r.id === justCreatedId);
    setHighlightId(justCreatedId);
    if (row && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const targetAbsolute = rect.top + window.scrollY + row.y + row.height / 2;
      const targetScroll = Math.max(0, targetAbsolute - window.innerHeight / 2);
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reduced) window.scrollTo(0, targetScroll);
      else animateScrollTo(targetScroll, 800, () => false);
    }
    const t1 = setTimeout(() => clearJustCreated(), 400);
    const t2 = setTimeout(() => setHighlightId(null), 2200);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [justCreatedId]);

  // completion pulse along the path
  useEffect(() => {
    if (!pulseToken) return;
    const idx = rows.findIndex((r) => r.id === pulseToken.id);
    if (idx === -1) return;
    const start = Math.max(0, idx - 1);
    const end = Math.min(rows.length - 1, idx + 2);
    const pts = rows.slice(start, end + 1).map((r) => ({ x: r.x, y: r.y }));
    if (pts.length < 2) return;
    setPulseSegment({ key: pulseToken.key, d: buildSmoothPath(pts) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pulseToken]);

  const handleOpenMenu = useCallback((afterId: string | null, rect: DOMRect) => {
    setMenu({ afterId, rect });
  }, []);

  const handleSelectType = useCallback(
    (type: ActivityType) => {
      const afterId = menu?.afterId ?? null;
      setMenu(null);
      setCreateType({ type, afterId });
    },
    [menu]
  );

  const handleCreate = useCallback(
    (data: { title: string; description?: string; datetime: string; extra?: Record<string, unknown> }) => {
      if (!createType) return;
      createActivity({
        type: createType.type,
        title: data.title,
        description: data.description,
        datetime: data.datetime,
        extra: data.extra,
        afterId: createType.afterId,
      });
      setCreateType(null);
    },
    [createType, createActivity]
  );

  const handleComplete = useCallback(
    (id: string) => {
      setCompletingIds((prev) => new Set(prev).add(id));
      setTimeout(() => {
        completeActivity(id);
        setCompletingIds((prev) => {
          const next = new Set(prev);
          next.delete(id);
          return next;
        });
      }, 480);
    },
    [completeActivity]
  );

  return (
    <div className="relative">
      <FlowPathHeader
        themeMode={themeMode}
        resolvedTheme={resolvedTheme}
        onToggleTheme={toggleTheme}
        onOpenCurve={() => setCurveOpen(true)}
      />

      <main
        ref={containerRef}
        className="relative mx-auto w-full max-w-3xl px-4 pt-28 pb-40 sm:px-8 sm:pt-32"
        style={{ minHeight: totalHeight }}
      >
        <Ribbon width={width} height={totalHeight} visibleChunks={visibleChunkPoints} theme={resolvedTheme} />

        {isEmpty && <EmptyState />}

        <AnimatePresence>
          {pulseSegment && (
            <PulseLight
              key={pulseSegment.key}
              d={pulseSegment.d}
              onDone={() => setPulseSegment(null)}
            />
          )}
        </AnimatePresence>

        <CurveSettingsModal open={curveOpen} onClose={() => setCurveOpen(false)} value={curve} onChange={setCurve} />

        {visibleRows.map((row) =>
          row.kind === "plus" ? (
            <PlusRowItem
              key={row.id}
              row={row}
              active={menu?.afterId === row.afterId}
              onOpen={(rect) => handleOpenMenu(row.afterId, rect)}
            />
          ) : (
            <ActivityRowItem
              key={row.id}
              row={row}
              config={config}
              width={width}
              onComplete={() => handleComplete(row.activity!.activity.id)}
              completing={completingIds.has(row.activity!.activity.id)}
              highlighted={highlightId === row.id}
            />
          )
        )}
      </main>

      <RadialMenu anchor={menu?.rect ?? null} onClose={() => setMenu(null)} onSelect={handleSelectType} />

      <CreateModal
        type={createType?.type ?? null}
        onClose={() => setCreateType(null)}
        onCreate={handleCreate}
      />

      <CurveSettingsModal open={curveOpen} onClose={() => setCurveOpen(false)} value={curve} onChange={setCurve} />

      <UniversalCreatePill onOpen={(rect) => handleOpenMenu(currentId, rect)} />
    </div>
  );
}

function PlusRowItem({
  row,
  active,
  onOpen,
}: {
  row: FlowRow;
  active: boolean;
  onOpen: (rect: DOMRect) => void;
}) {
  return (
    <div
      className="absolute left-0 flex w-full items-center justify-center"
      style={{ top: row.y, height: row.height }}
    >
      <div style={{ position: "absolute", left: row.x, top: "50%", transform: "translate(-50%, -50%)" }}>
        <PlusNode active={active} onOpen={onOpen} />
      </div>
    </div>
  );
}

function ActivityRowItem({
  row,
  config,
  width,
  onComplete,
  completing,
  highlighted,
}: {
  row: FlowRow;
  config: ReturnType<typeof getLayoutConfig>;
  width: number;
  onComplete: () => void;
  completing: boolean;
  highlighted: boolean;
}) {
  if (!row.activity) return null;
  const { activity, status } = row.activity;

  const rightLeft = Math.min(
    config.centerX + config.amplitude + config.cardGap,
    Math.max(0, width - config.cardWidth - 8)
  );
  const leftLeft = Math.max(8, config.centerX - config.amplitude - config.cardGap - config.cardWidth);

  const cardLeft = row.side === "right" ? rightLeft : leftLeft;
  const connectorFrom = row.side === "right" ? row.x : cardLeft + config.cardWidth;
  const connectorTo = row.side === "right" ? cardLeft : row.x;

  return (
    <div className="absolute left-0 w-full" style={{ top: row.y, height: row.height }}>
      {/* connector line */}
      <div
        className="pointer-events-none absolute h-px opacity-30"
        style={{
          top: "50%",
          left: Math.min(connectorFrom, connectorTo),
          width: Math.max(0, Math.abs(connectorTo - connectorFrom)),
          background: "linear-gradient(90deg, rgba(255,255,255,0.5), rgba(255,255,255,0))",
        }}
      />

      <div
        style={{ position: "absolute", left: row.x, top: "50%", transform: "translate(-50%, -50%)", zIndex: 2 }}
      >
        <div className={highlighted ? "fp-pulse relative rounded-full" : "relative"}>
          <ActivityNode type={activity.type} status={status} />
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          left: cardLeft,
          top: "50%",
          transform: "translateY(-50%)",
          width: config.cardWidth,
          zIndex: 1,
        }}
      >
        <ActivityCard
          activity={activity}
          status={status}
          side={row.side}
          onComplete={onComplete}
          completing={completing}
        />
      </div>
    </div>
  );
}
