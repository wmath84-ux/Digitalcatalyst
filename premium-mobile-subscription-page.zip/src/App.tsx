import SubscriptionPage from "./components/SubscriptionPage";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-200 sm:py-4">
      <SubscriptionPage />
    </div>
  );
}
