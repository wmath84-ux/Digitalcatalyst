import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "./utils/cn";

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------

type Note = {
  id: string;
  title: string;
  path: string;
  content: string;
  tags?: string[];
  source?: string;
};

type FileNode = {
  id: string;
  name: string;
  type: "folder" | "note";
  children?: FileNode[];
};

// ------------------------------------------------------------------
// Sample data
// ------------------------------------------------------------------

const NOTES: Note[] = [
  {
    id: "n1",
    title: "Project ideas",
    path: "Inbox/Project ideas.md",
    tags: ["planning", "work"],
    source: "https://obsidian.md",
    content: `# Project ideas

A running list of concepts worth exploring. Some are small experiments, others could become full products.

## Productivity tools

- A focused writing mode that hides everything except the current sentence.
- A weekly review template that pulls from habit trackers, calendar, and notes.
- A plugin that surfaces related notes based on shared links and tags.

## Learning projects

> "The best way to learn is to build something you actually want to use."

- Recreate a classic [Tetris](https://tetris.com) clone using a modern web stack.
- Build a tiny interpreter for a Lisp-like language.
- Design a consistent icon set and publish it as an SVG library.

## Long-term goals

1. Ship one side project every quarter.
2. Write a public essay for every major lesson learned.
3. Keep the knowledge graph connected and reviewed monthly.

Happy building!`,
  },
  {
    id: "n2",
    title: "Meeting notes — design sync",
    path: "Work/Meetings/Meeting notes — design sync.md",
    tags: ["design", "meeting"],
    content: `# Meeting notes — design sync

**Attendees:** Alex, Bailey, Casey
**Date:** Today

## Agenda

- Review the new navigation rail icons.
- Confirm typography scale for note titles.
- Decide on default light vs. dark mode behavior.

## Decisions

> The workspace should default to light mode for new users. Dark mode remains a first-class citizen.

1. Keep tab height at 36 px.
2. Use a 7 px left indent for nested folders.
3. Purple accent should be visible but never aggressive.

## Action items

- [ ] Update color tokens for both themes.
- [ ] Export updated icons as SVG components.
- [ ] Schedule follow-up for split-view responsive behavior.`,
  },
  {
    id: "n3",
    title: "Obsidian design reference",
    path: "References/Obsidian design reference.md",
    tags: ["reference", "ui"],
    content: `# Obsidian design reference

Obsidian is a powerful knowledge base that works on top of a local folder of plain text Markdown files.

## Key principles

- **Local-first:** Your data lives on your device.
- **Plain text:** Notes are Markdown files you can read anywhere.
- **Extensible:** Plugins can customize almost every part of the interface.

## Visual style

The interface favors dense information, thin borders, and restrained color. Purple accents indicate interactive elements such as links, active icons, and selected items.

> A clean reading surface is more important than decoration.

## Useful links

- [Obsidian Help](https://help.obsidian.md)
- [Markdown Guide](https://www.markdownguide.org)
- [Community Plugins](https://obsidian.md/plugins)`,
  },
  {
    id: "n4",
    title: "Weekly review template",
    path: "Templates/Weekly review template.md",
    content: `# Weekly review template

## Wins

- What went well this week?
- What did you finish?

## Friction

- Where did you get stuck?
- What felt repetitive?

## Learnings

> Capture lessons before they fade.

- Insight 1
- Insight 2

## Next week

1. Priority one
2. Priority two
3. Priority three`,
  },
];

const FILE_TREE: FileNode[] = [
  {
    id: "f-inbox",
    name: "Inbox",
    type: "folder",
    children: [{ id: "n1", name: "Project ideas", type: "note" }],
  },
  {
    id: "f-work",
    name: "Work",
    type: "folder",
    children: [
      {
        id: "f-meetings",
        name: "Meetings",
        type: "folder",
        children: [{ id: "n2", name: "Meeting notes — design sync", type: "note" }],
      },
    ],
  },
  {
    id: "f-references",
    name: "References",
    type: "folder",
    children: [{ id: "n3", name: "Obsidian design reference", type: "note" }],
  },
  {
    id: "f-templates",
    name: "Templates",
    type: "folder",
    children: [{ id: "n4", name: "Weekly review template", type: "note" }],
  },
];

const SETTINGS_CATEGORIES = [
  { id: "general", label: "General", icon: "settings" },
  { id: "editor", label: "Editor", icon: "type" },
  { id: "files", label: "Files and links", icon: "folder" },
  { id: "appearance", label: "Appearance", icon: "palette" },
  { id: "hotkeys", label: "Hotkeys", icon: "keyboard" },
  { id: "about", label: "About", icon: "info" },
];

const FONTS = [
  { id: "default", label: "Default" },
  { id: "inter", label: "Inter" },
  { id: "geist", label: "Geist" },
  { id: "system", label: "System" },
];

const THEMES = [
  { id: "default", label: "Default" },
  { id: "minimal", label: "Minimal" },
  { id: "things", label: "Things" },
];

const ACCENT_COLORS: Record<string, string> = {
  violet: "#7c3aed",
  blue: "#2563eb",
  green: "#16a34a",
  rose: "#e11d48",
  orange: "#ea580c",
};

// ------------------------------------------------------------------
// Hooks
// ------------------------------------------------------------------

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);
  return isMobile;
}

// ------------------------------------------------------------------
// Icons
// ------------------------------------------------------------------

const Icon = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={cn("h-4 w-4 shrink-0", className)}
  >
    {children}
  </svg>
);

const SidebarLeftIcon = () => (
  <Icon>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M9 3v18" />
  </Icon>
);

const SidebarRightIcon = () => (
  <Icon>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M15 3v18" />
  </Icon>
);

const PlusIcon = () => (
  <Icon>
    <path d="M12 5v14" />
    <path d="M5 12h14" />
  </Icon>
);

const ChevronDownIcon = ({ className }: { className?: string }) => (
  <Icon className={className}>
    <path d="m6 9 6 6 6-6" />
  </Icon>
);

const ChevronRightIcon = ({ className }: { className?: string }) => (
  <Icon className={className}>
    <path d="m9 18 6-6-6-6" />
  </Icon>
);

const ArrowLeftIcon = () => (
  <Icon>
    <path d="m15 18-6-6 6-6" />
  </Icon>
);

const ArrowRightIcon = () => (
  <Icon>
    <path d="m9 18 6-6-6-6" />
  </Icon>
);

const BookOpenIcon = () => (
  <Icon>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
  </Icon>
);

const PencilIcon = () => (
  <Icon>
    <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
  </Icon>
);

const MoreHorizontalIcon = () => (
  <Icon>
    <circle cx="12" cy="12" r="1" />
    <circle cx="19" cy="12" r="1" />
    <circle cx="5" cy="12" r="1" />
  </Icon>
);

const XIcon = ({ className }: { className?: string }) => (
  <Icon className={className}>
    <path d="M18 6 6 18" />
    <path d="m6 6 12 12" />
  </Icon>
);

const SearchIcon = () => (
  <Icon>
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </Icon>
);

const FolderIcon = ({ className }: { className?: string }) => (
  <Icon className={className}>
    <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
  </Icon>
);

const FileTextIcon = ({ className }: { className?: string }) => (
  <Icon className={className}>
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="16" y1="13" x2="8" y2="13" />
    <line x1="16" y1="17" x2="8" y2="17" />
    <line x1="10" y1="9" x2="8" y2="9" />
  </Icon>
);

const LayoutSplitIcon = () => (
  <Icon>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M12 3v18" />
  </Icon>
);

const PinIcon = () => (
  <Icon>
    <line x1="12" y1="17" x2="12" y2="22" />
    <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6H9v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z" />
  </Icon>
);

const SettingsIcon = () => (
  <Icon>
    <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
    <circle cx="12" cy="12" r="3" />
  </Icon>
);

const MoonIcon = () => (
  <Icon>
    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
  </Icon>
);

const SunIcon = () => (
  <Icon>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2" />
    <path d="M12 20v2" />
    <path d="m4.93 4.93 1.41 1.41" />
    <path d="m17.66 17.66 1.41 1.41" />
    <path d="M2 12h2" />
    <path d="M20 12h2" />
    <path d="m6.34 17.66-1.41 1.41" />
    <path d="m19.07 4.93-1.41 1.41" />
  </Icon>
);

const VaultIcon = () => (
  <Icon>
    <circle cx="12" cy="12" r="10" />
    <path d="M8 12h8" />
    <path d="M12 8v8" />
  </Icon>
);

const TypeIcon = () => (
  <Icon>
    <polyline points="4 7 4 4 20 4 20 7" />
    <line x1="9" y1="20" x2="15" y2="20" />
    <line x1="12" y1="4" x2="12" y2="20" />
  </Icon>
);

const HashIcon = () => (
  <Icon>
    <line x1="4" y1="9" x2="20" y2="9" />
    <line x1="4" y1="15" x2="20" y2="15" />
    <line x1="10" y1="3" x2="8" y2="21" />
    <line x1="16" y1="3" x2="14" y2="21" />
  </Icon>
);

// Mobile-only icons
const MenuIcon = () => (
  <Icon>
    <line x1="4" y1="6" x2="20" y2="6" />
    <line x1="4" y1="12" x2="20" y2="12" />
    <line x1="4" y1="18" x2="20" y2="18" />
  </Icon>
);

const UndoIcon = () => (
  <Icon>
    <path d="M3 7v6h6" />
    <path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13" />
  </Icon>
);

const RedoIcon = () => (
  <Icon>
    <path d="M21 7v6h-6" />
    <path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13" />
  </Icon>
);

const BoldIcon = () => (
  <Icon>
    <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
    <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
  </Icon>
);

const ItalicIcon = () => (
  <Icon>
    <line x1="19" y1="4" x2="10" y2="4" />
    <line x1="14" y1="20" x2="5" y2="20" />
    <line x1="15" y1="4" x2="9" y2="20" />
  </Icon>
);

const StrikethroughIcon = () => (
  <Icon>
    <path d="M16 4a4 4 0 0 1 0 8H8a4 4 0 0 0 0 8h8" />
    <line x1="4" y1="12" x2="20" y2="12" />
  </Icon>
);

const HighlightIcon = () => (
  <Icon>
    <path d="m9 11-6 6v3h9l3-3" />
    <path d="m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4" />
    <path d="M15 5h6v6" />
  </Icon>
);

const CodeIcon = () => (
  <Icon>
    <polyline points="16 18 22 12 16 6" />
    <polyline points="8 6 2 12 8 18" />
  </Icon>
);

const QuoteIcon = () => (
  <Icon>
    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V21M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1Z" />
  </Icon>
);

const LinkIcon = () => (
  <Icon>
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
  </Icon>
);

const ListIcon = () => (
  <Icon>
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </Icon>
);

const ListOrderedIcon = () => (
  <Icon>
    <line x1="10" y1="6" x2="21" y2="6" />
    <line x1="10" y1="12" x2="21" y2="12" />
    <line x1="10" y1="18" x2="21" y2="18" />
    <path d="M4 6h1v4" />
    <path d="M4 10h2" />
    <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
  </Icon>
);

const CheckSquareIcon = () => (
  <Icon>
    <polyline points="9 11 12 14 22 4" />
    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
  </Icon>
);

const IndentIcon = () => (
  <Icon>
    <polyline points="3 8 7 12 3 16" />
    <line x1="21" y1="12" x2="11" y2="12" />
    <line x1="21" y1="6" x2="11" y2="6" />
    <line x1="21" y1="18" x2="11" y2="18" />
  </Icon>
);

const OutdentIcon = () => (
  <Icon>
    <polyline points="7 8 3 12 7 16" />
    <line x1="21" y1="12" x2="11" y2="12" />
    <line x1="21" y1="6" x2="11" y2="6" />
    <line x1="21" y1="18" x2="11" y2="18" />
  </Icon>
);

const HeadingIcon = () => (
  <Icon>
    <path d="M6 12h12" />
    <path d="M6 20V4" />
    <path d="M18 20V4" />
  </Icon>
);

const PanelsTopLeftIcon = () => (
  <Icon>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M3 9h18" />
    <path d="M9 21V9" />
  </Icon>
);

const PaletteIcon = () => (
  <Icon>
    <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
    <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
    <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
    <circle cx="6.5" cy="12.5" r=".5" fill="currentColor" />
    <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" />
  </Icon>
);

const KeyboardIcon = () => (
  <Icon>
    <rect x="2" y="4" width="20" height="16" rx="2" />
    <path d="M6 8h.001" />
    <path d="M10 8h.001" />
    <path d="M14 8h.001" />
    <path d="M18 8h.001" />
    <path d="M8 12h.001" />
    <path d="M12 12h.001" />
    <path d="M16 12h.001" />
    <path d="M7 16h10" />
  </Icon>
);

const InfoIcon = () => (
  <Icon>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 16v-4" />
    <path d="M12 8h.01" />
  </Icon>
);

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

function findNoteById(id: string): Note | undefined {
  return NOTES.find((n) => n.id === id);
}

function countNodes(nodes: FileNode[]): { folders: number; notes: number } {
  let folders = 0;
  let notes = 0;
  for (const node of nodes) {
    if (node.type === "folder") {
      folders++;
      if (node.children) {
        const childCounts = countNodes(node.children);
        folders += childCounts.folders;
        notes += childCounts.notes;
      }
    } else {
      notes++;
    }
  }
  return { folders, notes };
}

function notePreview(content: string, maxLength = 90): string {
  const plain = content
    .replace(/^#+\s+/gm, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/>\s+/g, "")
    .replace(/[-*]\s+/g, "")
    .replace(/\d+\.\s+/g, "")
    .replace(/\n+/g, " ")
    .trim();
  return plain.length > maxLength ? `${plain.slice(0, maxLength)}…` : plain;
}

function parseContent(content: string) {
  const lines = content.split("\n");
  const blocks: React.ReactNode[] = [];
  let key = 0;
  let listItems: { content: string; level: number }[] = [];

  const flushList = () => {
    if (listItems.length === 0) return;
    blocks.push(
      <ul key={`list-${key++}`} className="my-5 list-disc space-y-1.5 pl-6 marker:text-text-tertiary">
        {listItems.map((item, idx) => (
          <li
            key={idx}
            className="pl-1 leading-relaxed"
            style={{ marginLeft: `${(item.level - 1) * 20}px` }}
          >
            {renderInline(item.content.replace(/^[-*]\s+/, ""))}
          </li>
        ))}
      </ul>
    );
    listItems = [];
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();

    if (line.startsWith("# ")) {
      flushList();
      blocks.push(
        <h1 key={`h1-${key++}`} className="mb-5 mt-2 text-[28px] font-bold leading-tight tracking-tight text-text-primary md:text-[34px]">
          {renderInline(line.slice(2))}
        </h1>
      );
      continue;
    }

    if (line.startsWith("## ")) {
      flushList();
      blocks.push(
        <h2 key={`h2-${key++}`} className="mb-3 mt-8 text-[21px] font-semibold leading-snug text-text-primary md:text-[24px]">
          {renderInline(line.slice(3))}
        </h2>
      );
      continue;
    }

    if (line.startsWith("> ")) {
      flushList();
      blocks.push(
        <blockquote
          key={`bq-${key++}`}
          className="my-5 border-l-2 border-accent pl-4 text-text-secondary"
        >
          <p className="leading-relaxed">{renderInline(line.slice(2))}</p>
        </blockquote>
      );
      continue;
    }

    if (/^[-*]\s+/.test(line)) {
      const level = Math.floor((rawLine.length - rawLine.trimStart().length) / 2) + 1;
      listItems.push({ content: line, level });
      continue;
    }

    if (/^\d+\.\s+/.test(line)) {
      flushList();
      blocks.push(
        <ol key={`ol-${key++}`} className="my-5 list-decimal space-y-1.5 pl-6 marker:text-text-secondary">
          <li className="pl-1 leading-relaxed">{renderInline(line.replace(/^\d+\.\s+/, ""))}</li>
        </ol>
      );
      continue;
    }

    if (line.trim() === "") {
      flushList();
      continue;
    }

    flushList();
    blocks.push(
      <p key={`p-${key++}`} className="my-4 text-base leading-[1.75] text-text-primary md:text-[17px]">
        {renderInline(line)}
      </p>
    );
  }

  flushList();
  return blocks;
}

function renderInline(text: string): React.ReactNode {
  const parts: React.ReactNode[] = [];
  const regex = /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;
  let lastIndex = 0;
  let key = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(<span key={`plain-${key++}`}>{text.slice(lastIndex, match.index)}</span>);
    }

    const piece = match[0];
    if (piece.startsWith("**") && piece.endsWith("**")) {
      parts.push(
        <strong key={`bold-${key++}`} className="font-semibold text-text-primary">
          {piece.slice(2, -2)}
        </strong>
      );
    } else if (piece.startsWith("[") && piece.includes("](")) {
      const labelEnd = piece.indexOf("](");
      const label = piece.slice(1, labelEnd);
      const href = piece.slice(labelEnd + 2, -1);
      parts.push(
        <a
          key={`link-${key++}`}
          href={href}
          target="_blank"
          rel="noreferrer"
          className="text-accent hover:text-accent-hover underline decoration-accent/30 underline-offset-2 transition-colors"
        >
          {label}
        </a>
      );
    }

    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(<span key={`plain-${key++}`}>{text.slice(lastIndex)}</span>);
  }

  return parts.length === 0 ? text : parts;
}

// ------------------------------------------------------------------
// Components
// ------------------------------------------------------------------

function NoteToolbar({
  note,
  isEditing,
  onToggleEdit,
}: {
  note: Note;
  isEditing?: boolean;
  onToggleEdit?: () => void;
}) {
  return (
    <div className="hidden h-9 items-center justify-between border-b border-border px-3 md:flex">
      <div className="flex items-center gap-0.5">
        <button className="flex h-7 w-7 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
          <ArrowLeftIcon />
        </button>
        <button className="flex h-7 w-7 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
          <ArrowRightIcon />
        </button>
      </div>

      <div className="flex items-center gap-1 text-[14px] text-text-secondary">
        <span className="hover:text-text-primary cursor-pointer">{note.path.split("/")[0]}</span>
        <ChevronRightIcon className="h-3.5 w-3.5 text-text-tertiary" />
        <span className="text-text-primary">{note.title}</span>
      </div>

      <div className="flex items-center gap-0.5">
        <button
          onClick={() => onToggleEdit?.()}
          className={cn(
            "flex h-7 w-7 items-center justify-center rounded transition-colors",
            isEditing
              ? "text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
              : "text-accent hover:bg-hover-bg"
          )}
        >
          <BookOpenIcon />
        </button>
        <button
          onClick={() => onToggleEdit?.()}
          className={cn(
            "flex h-7 w-7 items-center justify-center rounded transition-colors",
            isEditing
              ? "text-accent hover:bg-hover-bg"
              : "text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          )}
        >
          <PencilIcon />
        </button>
        <button className="flex h-7 w-7 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
          <MoreHorizontalIcon />
        </button>
      </div>
    </div>
  );
}

function NoteBody({ note }: { note: Note }) {
  return (
    <div className="mx-auto max-w-[720px] px-4 pb-28 pt-6 md:px-8 md:pb-24 md:pt-10">
      {note.tags && note.tags.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          {note.tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 rounded-full bg-accent-bg px-2.5 py-0.5 text-[13px] font-medium text-accent"
            >
              <HashIcon />
              {tag}
            </span>
          ))}
        </div>
      )}

      {note.source && (
        <div className="mb-8 text-[14px] text-text-secondary">
          Source:{" "}
          <a
            href={note.source}
            target="_blank"
            rel="noreferrer"
            className="text-accent hover:text-accent-hover underline decoration-accent/30 underline-offset-2"
          >
            {note.source}
          </a>
        </div>
      )}

      <div>{parseContent(note.content)}</div>
    </div>
  );
}

function NoteEditor({ note }: { note: Note }) {
  const [value, setValue] = useState(note.content);

  useEffect(() => {
    setValue(note.content);
  }, [note.id, note.content]);

  return (
    <div className="mx-auto flex h-full max-w-[720px] flex-col px-4 pb-28 pt-6 md:px-8 md:pb-24 md:pt-10">
      <textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="h-full w-full resize-none bg-transparent text-base leading-relaxed text-text-primary outline-none placeholder:text-text-tertiary md:text-[17px]"
        placeholder="Start writing..."
        spellCheck={false}
      />
    </div>
  );
}

function NotePane({
  note,
  isEditing,
  onToggleEdit,
}: {
  note: Note;
  isEditing?: boolean;
  onToggleEdit?: () => void;
}) {
  return (
    <div className="flex h-full flex-col bg-surface-bg">
      <NoteToolbar note={note} isEditing={isEditing} onToggleEdit={onToggleEdit} />
      <div className="flex-1 overflow-y-auto">
        {isEditing ? <NoteEditor note={note} /> : <NoteBody note={note} />}
      </div>
    </div>
  );
}

function FileTreeNode({
  node,
  expanded,
  toggle,
  activeNoteId,
  onSelect,
  depth = 0,
}: {
  node: FileNode;
  expanded: Set<string>;
  toggle: (id: string) => void;
  activeNoteId: string;
  onSelect: (id: string) => void;
  depth?: number;
}) {
  const isExpanded = expanded.has(node.id);
  const isFolder = node.type === "folder";

  return (
    <div>
      <button
        onClick={() => {
          if (isFolder) {
            toggle(node.id);
          } else {
            onSelect(node.id);
          }
        }}
        className={cn(
          "flex w-full items-center gap-1.5 rounded-md py-1.5 pr-2 text-left text-[14px] transition-colors md:py-1 md:text-[13px]",
          node.type === "note" && activeNoteId === node.id
            ? "bg-active-bg text-accent"
            : "text-text-secondary hover:bg-hover-bg hover:text-text-primary"
        )}
        style={{ paddingLeft: `${8 + depth * 14}px` }}
      >
        {isFolder && (
          <span className="text-text-tertiary">
            {isExpanded ? (
              <ChevronDownIcon className="h-3.5 w-3.5" />
            ) : (
              <ChevronRightIcon className="h-3.5 w-3.5" />
            )}
          </span>
        )}
        {!isFolder && <span className="w-3.5" />}
        <span className="shrink-0 text-text-tertiary">
          {isFolder ? <FolderIcon className="h-3.5 w-3.5" /> : <FileTextIcon className="h-3.5 w-3.5" />}
        </span>
        <span className="truncate">{node.name}</span>
      </button>

      {isFolder && isExpanded && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeNode
              key={child.id}
              node={child}
              expanded={expanded}
              toggle={toggle}
              activeNoteId={activeNoteId}
              onSelect={onSelect}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function MobileTopBar({
  note,
  onMenu,
  isEditing,
  onToggleEdit,
  onOverflow,
}: {
  note: Note;
  onMenu: () => void;
  isEditing: boolean;
  onToggleEdit: () => void;
  onOverflow: () => void;
}) {
  return (
    <div className="flex h-12 shrink-0 items-center justify-between border-b border-border bg-surface-bg px-3 md:hidden">
      <button
        onClick={onMenu}
        className="flex h-9 w-9 items-center justify-center rounded-md text-text-primary hover:bg-hover-bg"
      >
        <MenuIcon />
      </button>

      <div className="min-w-0 flex-1 px-2 text-center">
        <div className="truncate text-[15px] font-semibold text-text-primary">{note.title}</div>
      </div>

      <div className="flex items-center gap-0.5">
        <button
          onClick={onToggleEdit}
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-md transition-colors",
            isEditing ? "text-accent" : "text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          )}
        >
          {isEditing ? <BookOpenIcon /> : <PencilIcon />}
        </button>
        <button
          onClick={onOverflow}
          className="flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
        >
          <MoreHorizontalIcon />
        </button>
      </div>
    </div>
  );
}

function MobileBottomToolbar({
  tabsCount,
  onTabSwitcher,
  onNewTab,
  onOverflow,
  isEditing,
}: {
  tabsCount: number;
  onTabSwitcher: () => void;
  onNewTab: () => void;
  onOverflow: () => void;
  isEditing: boolean;
}) {
  if (isEditing) {
    return (
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex justify-start px-2 pb-[max(8px,env(safe-area-inset-bottom))] md:hidden" data-no-swipe>
        <div className="pointer-events-auto flex max-w-full items-center gap-0.5 overflow-x-auto rounded-full border border-border bg-surface-bg/95 px-2 py-1.5 shadow-lg backdrop-blur">
          <ToolbarButton icon={<UndoIcon />} label="Undo" />
          <ToolbarButton icon={<RedoIcon />} label="Redo" />
          <ToolbarDivider />
          <ToolbarButton icon={<HeadingIcon />} label="Heading" />
          <ToolbarButton icon={<BoldIcon />} label="Bold" />
          <ToolbarButton icon={<ItalicIcon />} label="Italic" />
          <ToolbarButton icon={<StrikethroughIcon />} label="Strikethrough" />
          <ToolbarButton icon={<HighlightIcon />} label="Highlight" />
          <ToolbarDivider />
          <ToolbarButton icon={<CodeIcon />} label="Code" />
          <ToolbarButton icon={<QuoteIcon />} label="Quote" />
          <ToolbarButton icon={<LinkIcon />} label="Link" />
          <ToolbarDivider />
          <ToolbarButton icon={<ListIcon />} label="Bulleted list" />
          <ToolbarButton icon={<ListOrderedIcon />} label="Numbered list" />
          <ToolbarButton icon={<CheckSquareIcon />} label="Checklist" />
          <ToolbarButton icon={<IndentIcon />} label="Indent" />
          <ToolbarButton icon={<OutdentIcon />} label="Outdent" />
        </div>
      </div>
    );
  }

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex justify-center px-4 pb-[max(12px,env(safe-area-inset-bottom))] md:hidden">
      <div className="pointer-events-auto flex items-center gap-0.5 rounded-full border border-border bg-surface-bg/95 px-2 py-1.5 shadow-lg backdrop-blur">
        <ToolbarButton icon={<ArrowLeftIcon />} label="Back" />
        <ToolbarButton icon={<ArrowRightIcon />} label="Forward" />
        <ToolbarDivider />
        <ToolbarButton icon={<SearchIcon />} label="Search" />
        <ToolbarButton icon={<PlusIcon />} label="New tab" onClick={onNewTab} />
        <ToolbarButton icon={<PanelsTopLeftIcon />} label="Tabs" onClick={onTabSwitcher} badge={tabsCount} />
        <ToolbarButton icon={<MoreHorizontalIcon />} label="More" onClick={onOverflow} />
      </div>
    </div>
  );
}

function ToolbarButton({
  icon,
  label,
  onClick,
  badge,
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-text-secondary transition-colors hover:bg-hover-bg hover:text-text-primary active:bg-hover-bg"
      aria-label={label}
    >
      {icon}
      {badge !== undefined && (
        <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-accent px-1 text-[10px] font-medium text-white">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </button>
  );
}

function ToolbarDivider() {
  return <div className="mx-1 h-5 w-px bg-border" />;
}

function TabSwitcher({
  tabs,
  activeTabId,
  onSelect,
  onClose,
  onCloseTab,
  onNewTab,
}: {
  tabs: Note[];
  activeTabId: string;
  onSelect: (id: string) => void;
  onClose: () => void;
  onCloseTab: (id: string) => void;
  onNewTab: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-40 flex flex-col bg-black/40 md:hidden"
      onClick={onClose}
    >
      <div
        className="flex flex-1 flex-col bg-surface-bg px-4 pt-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <span className="text-[17px] font-semibold text-text-primary">
            Tabs ({tabs.length})
          </span>
          <button
            onClick={onClose}
            className="flex h-8 items-center rounded-md px-3 text-[14px] font-medium text-accent hover:bg-active-bg"
          >
            Done
          </button>
        </div>

        <div className="grid flex-1 content-start grid-cols-2 gap-3 overflow-y-auto pb-28">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  onSelect(tab.id);
                  onClose();
                }}
                className={cn(
                  "relative flex flex-col overflow-hidden rounded-2xl border p-3 text-left transition-all active:scale-[0.98]",
                  isActive
                    ? "border-accent bg-active-bg shadow-sm"
                    : "border-border bg-surface-bg shadow-sm hover:border-text-tertiary"
                )}
              >
                {/* Chrome-style tab curved top edge */}
                <div
                  className={cn(
                    "absolute left-1/2 top-0 h-1.5 w-16 -translate-x-1/2 rounded-b-full",
                    isActive ? "bg-accent" : "bg-border"
                  )}
                />

                <div className="mb-2 mt-1 flex items-start justify-between gap-2">
                  <FileTextIcon className="h-4 w-4 shrink-0 text-text-tertiary" />
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseTab(tab.id);
                    }}
                    className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
                  >
                    <XIcon className="h-3 w-3" />
                  </span>
                </div>
                <div className="mb-1 line-clamp-2 text-[13px] font-semibold leading-snug text-text-primary">
                  {tab.title}
                </div>
                <div className="line-clamp-3 text-[11px] leading-relaxed text-text-secondary">
                  {notePreview(tab.content)}
                </div>
              </button>
            );
          })}

          <button
            onClick={() => {
              onNewTab();
              onClose();
            }}
            className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-border bg-surface-bg p-3 text-text-secondary shadow-sm transition-colors hover:border-text-tertiary hover:text-text-primary"
          >
            <PlusIcon />
            <span className="text-[12px] font-medium">New tab</span>
          </button>
        </div>

        {/* Centered floating + button */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex justify-center pb-[max(16px,env(safe-area-inset-bottom))]">
          <button
            onClick={() => {
              onNewTab();
              onClose();
            }}
            className="pointer-events-auto flex h-12 w-12 items-center justify-center rounded-full bg-accent text-white shadow-lg shadow-accent/30 transition-transform active:scale-95"
            aria-label="New tab"
          >
            <PlusIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

function OverflowMenu({
  onClose,
  onSettings,
  onToggleTheme,
  onCloseTab,
  onSplitView,
  isEditing,
  onToggleEdit,
  canCloseTab,
}: {
  onClose: () => void;
  onSettings: () => void;
  onToggleTheme: () => void;
  onCloseTab: () => void;
  onSplitView: () => void;
  isEditing: boolean;
  onToggleEdit: () => void;
  canCloseTab: boolean;
}) {
  const Action = ({
    icon,
    label,
    onClick,
    destructive,
  }: {
    icon: React.ReactNode;
    label: string;
    onClick?: () => void;
    destructive?: boolean;
  }) => (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-[15px] transition-colors",
        destructive
          ? "text-red-500 hover:bg-red-500/10"
          : "text-text-primary hover:bg-hover-bg"
      )}
    >
      <span className={cn("text-text-tertiary", destructive && "text-red-500")}>{icon}</span>
      {label}
    </button>
  );

  return (
    <div
      className="fixed inset-0 z-50 bg-black/40 md:hidden"
      onClick={onClose}
    >
      <div
        className="absolute bottom-0 left-0 right-0 rounded-t-2xl bg-surface-bg p-4 pb-[max(16px,env(safe-area-inset-bottom))] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-border" />

        <div className="mb-3 text-center text-[13px] font-semibold uppercase tracking-wide text-text-tertiary">
          Note actions
        </div>

        <div className="space-y-1">
          <Action
            icon={isEditing ? <BookOpenIcon /> : <PencilIcon />}
            label={isEditing ? "Switch to reading" : "Edit note"}
            onClick={() => {
              onToggleEdit();
              onClose();
            }}
          />
          <Action icon={<LayoutSplitIcon />} label="Toggle split view" onClick={onSplitView} />
          <Action icon={<SettingsIcon />} label="Appearance settings" onClick={onSettings} />
          <Action icon={<MoonIcon />} label="Toggle theme" onClick={onToggleTheme} />
        </div>

        <div className="my-2 h-px bg-border" />

        <div className="space-y-1">
          <Action
            icon={<XIcon />}
            label="Close current tab"
            onClick={canCloseTab ? onCloseTab : undefined}
            destructive
          />
        </div>
      </div>
    </div>
  );
}

function NewTabScreen({
  onClose,
  onNewNote,
  onGoToFile,
}: {
  onClose: () => void;
  onNewNote: () => void;
  onGoToFile: () => void;
}) {
  const ActionButton = ({
    icon,
    label,
    onClick,
  }: {
    icon: React.ReactNode;
    label: string;
    onClick?: () => void;
  }) => (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl border border-border bg-surface-bg px-4 py-4 text-left text-text-primary transition-colors hover:border-text-tertiary hover:bg-hover-bg active:bg-hover-bg"
    >
      <span className="text-text-secondary">{icon}</span>
      <span className="text-[15px] font-medium">{label}</span>
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-surface-bg md:hidden">
      <div className="flex h-12 items-center justify-between border-b border-border px-3">
        <span className="text-[17px] font-semibold text-text-primary">New</span>
        <button
          onClick={onClose}
          className="flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
        >
          <XIcon />
        </button>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center px-6">
        <div className="w-full max-w-sm space-y-3">
          <ActionButton icon={<FileTextIcon />} label="New note" onClick={onNewNote} />
          <ActionButton icon={<LayoutSplitIcon />} label="New canvas" />
          <ActionButton icon={<SearchIcon />} label="Go to file" onClick={onGoToFile} />
        </div>
      </div>
    </div>
  );
}

function MobileSidebarDrawer({
  open,
  onClose,
  onOpenSettings,
  activeNoteId,
  onSelect,
  expanded,
  toggle,
  folders,
  notes,
}: {
  open: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
  activeNoteId: string;
  onSelect: (id: string) => void;
  expanded: Set<string>;
  toggle: (id: string) => void;
  folders: number;
  notes: number;
}) {
  return (
    <div className="pointer-events-none fixed inset-0 z-40 md:hidden" aria-hidden={!open}>
      <div
        className={cn(
          "absolute inset-0 bg-black/40 transition-opacity duration-300",
          open ? "pointer-events-auto opacity-100" : "opacity-0"
        )}
        onClick={onClose}
      />
      <div
        className={cn(
          "pointer-events-auto absolute bottom-0 left-0 top-0 flex w-[280px] flex-col border-r border-border bg-sidebar-bg shadow-xl transition-transform duration-300 ease-out will-change-transform",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-12 items-center justify-between border-b border-border px-4">
          <span className="truncate text-[15px] font-semibold text-text-primary">My vault</span>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          >
            <XIcon />
          </button>
        </div>

        <div className="flex h-9 items-center justify-between border-b border-border px-4 text-[13px] text-text-secondary">
          <span>
            {folders} folders, {notes} notes
          </span>
        </div>

        <div className="flex-1 overflow-y-auto p-3">
          {FILE_TREE.map((node) => (
            <FileTreeNode
              key={node.id}
              node={node}
              expanded={expanded}
              toggle={toggle}
              activeNoteId={activeNoteId}
              onSelect={(id) => {
                onSelect(id);
                onClose();
              }}
            />
          ))}
        </div>

        <div className="flex h-12 items-center justify-between border-t border-border px-3">
          <button className="flex h-9 items-center gap-2 rounded-lg px-3 text-[14px] text-text-secondary hover:bg-hover-bg hover:text-text-primary">
            <PlusIcon /> New note
          </button>
          <button
            onClick={() => {
              onClose();
              onOpenSettings();
            }}
            className="flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          >
            <SettingsIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

function SettingsModal({
  open,
  onClose,
  theme,
  setTheme,
  accent,
  setAccent,
}: {
  open: boolean;
  onClose: () => void;
  theme: "light" | "dark";
  setTheme: (t: "light" | "dark") => void;
  accent: string;
  setAccent: (a: string) => void;
}) {
  const [category, setCategory] = useState("appearance");
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (contentRef.current) {
      contentRef.current.scrollTop = 0;
    }
  }, [category]);

  if (!open) return null;

  const categoryIcon = (id: string) => {
    switch (id) {
      case "appearance":
        return <PaletteIcon />;
      case "editor":
        return <TypeIcon />;
      case "files":
        return <FolderIcon />;
      case "hotkeys":
        return <KeyboardIcon />;
      case "about":
        return <InfoIcon />;
      default:
        return <SettingsIcon />;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 md:items-center md:p-4"
      onClick={onClose}
    >
      <div
        className="flex h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl border border-border bg-surface-bg shadow-2xl md:h-[560px] md:max-w-[760px] md:flex-row md:rounded-lg"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left nav */}
        <div className="flex h-auto w-full flex-col border-b border-border bg-sidebar-bg md:h-full md:w-44 md:border-b-0 md:border-r">
          <div className="flex h-12 shrink-0 items-center justify-between border-b border-border px-4 md:h-11 md:px-3">
            <span className="text-[15px] font-semibold text-text-primary md:text-[13px] md:font-semibold md:uppercase md:tracking-wider md:text-text-tertiary">
              Settings
            </span>
            <button
              onClick={onClose}
              className="flex h-7 w-7 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
            >
              <XIcon />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            <div className="mb-2 hidden px-2 text-[11px] font-semibold uppercase tracking-wider text-text-tertiary md:block">
              Options
            </div>
            <div className="grid grid-cols-2 gap-1 md:block md:space-y-0.5">
              {SETTINGS_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2 py-2 text-left text-[14px] transition-colors md:py-1.5 md:text-[13px]",
                    category === cat.id
                      ? "bg-active-bg font-medium text-accent"
                      : "text-text-secondary hover:bg-hover-bg hover:text-text-primary"
                  )}
                >
                  <span className="text-text-tertiary">{categoryIcon(cat.id)}</span>
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right content */}
        <div className="flex flex-1 flex-col bg-surface-bg md:h-full">
          <div className="flex h-12 shrink-0 items-center border-b border-border px-4 md:h-11 md:px-4">
            <span className="text-[16px] font-semibold text-text-primary md:text-[15px]">
              {SETTINGS_CATEGORIES.find((c) => c.id === category)?.label}
            </span>
          </div>

          <div ref={contentRef} className="flex-1 overflow-y-auto p-4 md:p-6">
            {category === "appearance" && (
              <div className="space-y-5 md:space-y-6">
                {/* Base color scheme */}
                <section>
                  <h3 className="mb-3 text-[15px] font-semibold text-text-primary md:text-[16px]">Base color scheme</h3>
                  <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                    <button
                      onClick={() => setTheme("light")}
                      className={cn(
                        "flex items-center gap-3 rounded-lg border p-3 transition-colors",
                        theme === "light"
                          ? "border-accent bg-active-bg"
                          : "border-border bg-input-bg hover:border-text-tertiary"
                      )}
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-amber-500 shadow-sm ring-1 ring-border">
                        <SunIcon />
                      </div>
                      <div className="text-left">
                        <div className="text-[14px] font-medium text-text-primary">Light</div>
                        <div className="text-[12px] text-text-secondary">Light background</div>
                      </div>
                    </button>
                    <button
                      onClick={() => setTheme("dark")}
                      className={cn(
                        "flex items-center gap-3 rounded-lg border p-3 transition-colors",
                        theme === "dark"
                          ? "border-accent bg-active-bg"
                          : "border-border bg-input-bg hover:border-text-tertiary"
                      )}
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-zinc-900 text-indigo-300 shadow-sm ring-1 ring-border">
                        <MoonIcon />
                      </div>
                      <div className="text-left">
                        <div className="text-[14px] font-medium text-text-primary">Dark</div>
                        <div className="text-[12px] text-text-secondary">Dark background</div>
                      </div>
                    </button>
                  </div>
                </section>

                <hr className="border-border" />

                {/* Accent color */}
                <section>
                  <h3 className="mb-3 text-[15px] font-semibold text-text-primary md:text-[16px]">Accent color</h3>
                  <div className="flex flex-wrap gap-3">
                    {[
                      { id: "violet", color: "#7c3aed" },
                      { id: "blue", color: "#2563eb" },
                      { id: "green", color: "#16a34a" },
                      { id: "rose", color: "#e11d48" },
                      { id: "orange", color: "#ea580c" },
                    ].map((c) => (
                      <button
                        key={c.id}
                        onClick={() => setAccent(c.id)}
                        className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-surface-bg transition-all",
                          accent === c.id ? "ring-accent" : "ring-transparent hover:ring-text-tertiary"
                        )}
                        style={{ backgroundColor: c.color }}
                        aria-label={c.id}
                      >
                        {accent === c.id && <div className="h-3.5 w-3.5 rounded-full bg-white/90" />}
                      </button>
                    ))}
                  </div>
                </section>

                <hr className="border-border" />

                {/* Theme */}
                <section>
                  <h3 className="mb-3 text-[15px] font-semibold text-text-primary md:text-[16px]">Theme</h3>
                  <div className="space-y-2">
                    {THEMES.map((t) => (
                      <label
                        key={t.id}
                        className="flex cursor-pointer items-center justify-between rounded-md border border-border bg-input-bg p-3 hover:border-text-tertiary"
                      >
                        <span className="text-[14px] text-text-primary">{t.label}</span>
                        <input
                          type="radio"
                          name="theme"
                          defaultChecked={t.id === "default"}
                          className="h-4 w-4 accent-accent"
                        />
                      </label>
                    ))}
                  </div>
                </section>

                <hr className="border-border" />

                {/* Fonts */}
                <section>
                  <h3 className="mb-3 text-[15px] font-semibold text-text-primary md:text-[16px]">Fonts</h3>
                  <div className="space-y-4">
                    {[
                      { label: "Interface font", value: "Default" },
                      { label: "Text font", value: "Default" },
                      { label: "Monospace font", value: "Default" },
                    ].map((font) => (
                      <div key={font.label}>
                        <label className="mb-1.5 block text-[13px] text-text-secondary">{font.label}</label>
                        <div className="relative">
                          <select className="w-full appearance-none rounded-md border border-border bg-input-bg px-3 py-2 text-[14px] text-text-primary outline-none focus:border-accent">
                            {FONTS.map((f) => (
                              <option key={f.id} value={f.id}>
                                {f.label}
                              </option>
                            ))}
                          </select>
                          <ChevronDownIcon className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-text-tertiary" />
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                <hr className="border-border" />

                {/* Font size */}
                <section>
                  <h3 className="mb-3 text-[15px] font-semibold text-text-primary md:text-[16px]">Font size</h3>
                  <div className="flex items-center gap-4">
                    <TypeIcon />
                    <input
                      type="range"
                      min="12"
                      max="24"
                      defaultValue="16"
                      className="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-border accent-accent"
                    />
                    <span className="w-8 text-right text-[14px] text-text-secondary">16</span>
                  </div>
                </section>
              </div>
            )}

            {category !== "appearance" && (
              <div className="text-[14px] text-text-secondary">
                Settings for {SETTINGS_CATEGORIES.find((c) => c.id === category)?.label} would appear here.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// App
// ------------------------------------------------------------------

export default function App() {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window !== "undefined") {
      const saved = window.localStorage.getItem("notes-theme") as "light" | "dark" | null;
      return saved ?? "light";
    }
    return "light";
  });
  const [sidebarOpen, setSidebarOpen] = useState(() =>
    typeof window !== "undefined" ? window.innerWidth >= 768 : true
  );
  const [tabs, setTabs] = useState<Note[]>([NOTES[0], NOTES[1]]);
  const [activeTabId, setActiveTabId] = useState<string>(NOTES[0].id);
  const [splitView, setSplitView] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [accent, setAccent] = useState("violet");
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(
    () => new Set(["f-inbox", "f-work", "f-meetings", "f-references", "f-templates"])
  );
  const [tabSwitcherOpen, setTabSwitcherOpen] = useState(false);
  const [overflowOpen, setOverflowOpen] = useState(false);
  const [newTabOpen, setNewTabOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const isMobile = useIsMobile();

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem("notes-theme", theme);
    const color = ACCENT_COLORS[accent] ?? ACCENT_COLORS.violet;
    document.documentElement.style.setProperty("--accent-color", color);
    document.documentElement.style.setProperty("--accent-hover", color);
    document.documentElement.style.setProperty("--accent-muted", color);
    document.documentElement.style.setProperty("--accent-bg", theme === "dark" ? `${color}33` : `${color}1a`);
  }, [theme, accent]);

  // Mobile swipe gestures:
  // - Swipe RIGHT opens the sidebar drawer (edge swipe ke liye chhota threshold)
  // - Swipe LEFT closes the drawer (ya open overlays ko close karta hai)
  useEffect(() => {
    if (!isMobile) return;

    let startX = 0;
    let startY = 0;
    let tracking = false;

    const onTouchStart = (e: TouchEvent) => {
      const target = e.target as HTMLElement | null;
      // horizontally-scrollable elements (jaise editing toolbar) ke andar swipe ignore karo
      if (target && target.closest("[data-no-swipe]")) {
        tracking = false;
        return;
      }
      const t = e.touches[0];
      startX = t.clientX;
      startY = t.clientY;
      tracking = true;
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (!tracking) return;
      tracking = false;
      const t = e.changedTouches[0];
      const dx = t.clientX - startX;
      const dy = t.clientY - startY;

      // vertical scroll ko ignore karo
      if (Math.abs(dy) > 60) return;

      const fromLeftEdge = startX < 28;
      const threshold = fromLeftEdge ? 40 : 72;

      if (dx > threshold) {
        // Swipe right → sidebar open
        setSidebarOpen(true);
        setTabSwitcherOpen(false);
        setOverflowOpen(false);
      } else if (dx < -threshold) {
        // Swipe left → pehle overlay close, warna sidebar close
        if (overflowOpen) {
          setOverflowOpen(false);
        } else if (tabSwitcherOpen) {
          setTabSwitcherOpen(false);
        } else {
          setSidebarOpen(false);
        }
      }
    };

    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
    };
  }, [isMobile, overflowOpen, tabSwitcherOpen]);

  const activeNote = useMemo(() => findNoteById(activeTabId) ?? NOTES[0], [activeTabId]);
  const secondaryNote = useMemo(() => {
    if (splitView) {
      return tabs.find((t) => t.id !== activeTabId) ?? NOTES[1];
    }
    return null;
  }, [splitView, tabs, activeTabId]);

  const { folders, notes } = useMemo(() => countNodes(FILE_TREE), []);

  const openNote = (id: string) => {
    const note = findNoteById(id);
    if (!note) return;
    if (!tabs.find((t) => t.id === id)) {
      setTabs((prev) => [...prev, note]);
    }
    setActiveTabId(id);
  };

  const closeTab = (id: string) => {
    setTabs((prev) => {
      const next = prev.filter((t) => t.id !== id);
      if (activeTabId === id && next.length > 0) {
        setActiveTabId(next[next.length - 1].id);
      }
      return next;
    });
  };

  const closeActiveTab = () => {
    closeTab(activeTabId);
  };

  const toggleFolder = (id: string) => {
    setExpandedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleNewTab = () => {
    const next = NOTES.find((n) => !tabs.find((t) => t.id === n.id));
    if (next) {
      openNote(next.id);
    } else {
      setNewTabOpen(true);
    }
  };

  return (
    <div className="flex h-[100dvh] w-screen overflow-hidden bg-workspace-bg text-text-primary">
      {/* Icon rail — desktop/tablet only */}
      <div className="hidden w-11 shrink-0 flex-col items-center border-r border-border bg-rail-bg py-2 md:flex">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-md transition-colors",
            sidebarOpen ? "bg-active-bg text-accent" : "text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          )}
          title="Toggle sidebar"
        >
          <SidebarLeftIcon />
        </button>

        <div className="my-2 h-px w-6 bg-border" />

        <button className="flex h-8 w-8 items-center justify-center rounded-md text-accent hover:bg-hover-bg">
          <VaultIcon />
        </button>

        <button className="mt-1 flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
          <SearchIcon />
        </button>

        <button
          onClick={() => setSettingsOpen(true)}
          className="mt-1 flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
        >
          <SettingsIcon />
        </button>

        <div className="flex-1" />

        <button
          onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          className="flex h-8 w-8 items-center justify-center rounded-md text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          title="Toggle theme"
        >
          {theme === "light" ? <MoonIcon /> : <SunIcon />}
        </button>
      </div>

      {/* File explorer — desktop/tablet panel */}
      {sidebarOpen && (
        <div className="hidden w-64 shrink-0 flex-col border-r border-border bg-sidebar-bg md:flex">
          <div className="flex h-9 items-center justify-between border-b border-border px-3">
            <span className="truncate text-[13px] font-semibold text-text-primary">My vault</span>
            <div className="flex items-center gap-0.5">
              <button className="flex h-6 w-6 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
                <PinIcon />
              </button>
              <button className="flex h-6 w-6 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
                <LayoutSplitIcon />
              </button>
            </div>
          </div>

          <div className="flex h-8 items-center justify-between border-b border-border px-3 text-[12px] text-text-secondary">
            <span>
              {folders} folders, {notes} notes
            </span>
            <button className="text-text-tertiary hover:text-text-primary">
              <ChevronDownIcon className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2">
            {FILE_TREE.map((node) => (
              <FileTreeNode
                key={node.id}
                node={node}
                expanded={expandedFolders}
                toggle={toggleFolder}
                activeNoteId={activeTabId}
                onSelect={openNote}
              />
            ))}
          </div>

          <div className="flex h-9 items-center justify-between border-t border-border px-2">
            <button className="flex h-7 items-center gap-1 rounded px-2 text-[12px] text-text-secondary hover:bg-hover-bg hover:text-text-primary">
              <PlusIcon /> New note
            </button>
            <button className="flex h-7 w-7 items-center justify-center rounded text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
              <MoreHorizontalIcon />
            </button>
          </div>
        </div>
      )}

      {/* Main workspace */}
      <div className="relative flex min-w-0 flex-1 flex-col bg-workspace-bg">
        {/* Desktop tab bar */}
        <div className="hidden h-9 shrink-0 items-center border-b border-border bg-workspace-bg md:flex">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="flex h-9 w-9 shrink-0 items-center justify-center border-r border-border text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
          >
            <SidebarLeftIcon />
          </button>

          <div className="flex min-w-0 flex-1 items-center overflow-hidden">
            {tabs.map((tab) => {
              const isActive = tab.id === activeTabId;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTabId(tab.id)}
                  className={cn(
                    "group relative flex h-9 max-w-[200px] shrink-0 items-center border-r border-border px-3 text-[13px] transition-colors",
                    isActive
                      ? "bg-surface-bg text-text-primary"
                      : "bg-workspace-bg text-text-secondary hover:bg-hover-bg hover:text-text-primary"
                  )}
                >
                  <FileTextIcon className="mr-1.5 h-3.5 w-3.5 shrink-0 text-text-tertiary group-hover:text-text-secondary" />
                  <span className="truncate">{tab.title}</span>
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      closeTab(tab.id);
                    }}
                    className={cn(
                      "ml-1.5 flex h-4 w-4 shrink-0 items-center justify-center rounded text-text-tertiary opacity-0 transition-opacity hover:bg-hover-bg hover:text-text-primary",
                      isActive && "opacity-100",
                      "group-hover:opacity-100"
                    )}
                  >
                    <XIcon className="h-3 w-3" />
                  </span>

                  {isActive && (
                    <>
                      <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-accent" />
                      <span className="absolute -bottom-px left-0 h-px w-full bg-surface-bg" />
                    </>
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex shrink-0 items-center">
            <button
              onClick={handleNewTab}
              className="flex h-9 w-9 items-center justify-center border-l border-border text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
              title="New tab"
            >
              <PlusIcon />
            </button>

            <button
              onClick={() => setSplitView(!splitView)}
              className={cn(
                "flex h-9 w-9 items-center justify-center border-l border-border transition-colors",
                splitView ? "bg-active-bg text-accent" : "text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
              )}
              title="Toggle split view"
            >
              <LayoutSplitIcon />
            </button>

            <button className="flex h-9 w-9 items-center justify-center border-l border-border text-text-tertiary hover:bg-hover-bg hover:text-text-primary">
              <SidebarRightIcon />
            </button>

            <button
              onClick={() => setSettingsOpen(true)}
              className="flex h-9 w-9 items-center justify-center border-l border-border text-text-tertiary hover:bg-hover-bg hover:text-text-primary"
            >
              <MoreHorizontalIcon />
            </button>
          </div>
        </div>

        {/* Mobile top bar */}
        <MobileTopBar
          note={activeNote}
          onMenu={() => setSidebarOpen(true)}
          isEditing={isEditing}
          onToggleEdit={() => setIsEditing(!isEditing)}
          onOverflow={() => setOverflowOpen(true)}
        />

        {/* Note area */}
        {splitView && secondaryNote ? (
          <div className="flex flex-1 min-h-0">
            <div className="flex-1 min-w-0">
              <NotePane note={activeNote} isEditing={isEditing} onToggleEdit={() => setIsEditing(!isEditing)} />
            </div>
            <div className="w-px shrink-0 bg-border" />
            <div className="flex-1 min-w-0">
              <NotePane note={secondaryNote} />
            </div>
          </div>
        ) : (
          <div className="flex-1 min-h-0">
            <NotePane note={activeNote} isEditing={isEditing} onToggleEdit={() => setIsEditing(!isEditing)} />
          </div>
        )}

        {/* Mobile floating bottom toolbar */}
        <MobileBottomToolbar
          tabsCount={tabs.length}
          onTabSwitcher={() => setTabSwitcherOpen(true)}
          onNewTab={handleNewTab}
          onOverflow={() => setOverflowOpen(true)}
          isEditing={isEditing}
        />
      </div>

      {/* Mobile sidebar drawer */}
      <MobileSidebarDrawer
        open={sidebarOpen && isMobile}
        onClose={() => setSidebarOpen(false)}
        onOpenSettings={() => setSettingsOpen(true)}
        activeNoteId={activeTabId}
        onSelect={openNote}
        expanded={expandedFolders}
        toggle={toggleFolder}
        folders={folders}
        notes={notes}
      />

      {/* Mobile tab switcher */}
      {tabSwitcherOpen && (
        <TabSwitcher
          tabs={tabs}
          activeTabId={activeTabId}
          onSelect={setActiveTabId}
          onClose={() => setTabSwitcherOpen(false)}
          onCloseTab={closeTab}
          onNewTab={handleNewTab}
        />
      )}

      {/* Mobile overflow menu */}
      {overflowOpen && (
        <OverflowMenu
          onClose={() => setOverflowOpen(false)}
          onSettings={() => {
            setOverflowOpen(false);
            setSettingsOpen(true);
          }}
          onToggleTheme={() => setTheme(theme === "light" ? "dark" : "light")}
          onCloseTab={closeActiveTab}
          onSplitView={() => setSplitView(!splitView)}
          isEditing={isEditing}
          onToggleEdit={() => setIsEditing(!isEditing)}
          canCloseTab={tabs.length > 1}
        />
      )}

      {/* Mobile new tab screen */}
      {newTabOpen && (
        <NewTabScreen
          onClose={() => setNewTabOpen(false)}
          onNewNote={() => {
            const next = NOTES.find((n) => !tabs.find((t) => t.id === n.id));
            if (next) openNote(next.id);
            setNewTabOpen(false);
          }}
          onGoToFile={() => setNewTabOpen(false)}
        />
      )}

      {/* Settings modal */}
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        theme={theme}
        setTheme={setTheme}
        accent={accent}
        setAccent={setAccent}
      />
    </div>
  );
}
