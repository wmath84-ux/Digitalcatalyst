import { useEffect, useRef, useState } from "react";
import { PRODUCTS } from "./data/products";
import { TabKey } from "./types";
import BottomNav from "./components/BottomNav";
import Toast from "./components/Toast";
import HomePage from "./pages/HomePage";
import FavoritesPage from "./pages/FavoritesPage";
import CartPage from "./pages/CartPage";

const INITIAL_CART = ["p1", "p3"];
const INITIAL_FAVORITES = ["p2", "p4", "p6"];
const INITIAL_COINS = 480;

export default function App() {
  const [activeTab, setActiveTab] = useState<TabKey>("home");
  const [cartIds, setCartIds] = useState<Set<string>>(new Set(INITIAL_CART));
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(
    new Set(INITIAL_FAVORITES)
  );
  const [userCoins, setUserCoins] = useState(INITIAL_COINS);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = (message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2000);
  };

  useEffect(() => {
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  const handleAddToCart = (id: string) => {
    setCartIds((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      return next;
    });
    const product = PRODUCTS.find((p) => p.id === id);
    showToast(`${product ? product.title.slice(0, 28) + "…" : "Item"} added to cart`);
  };

  const handleRemoveFromCart = (id: string) => {
    setCartIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
    showToast("Removed from cart");
  };

  const handleClearCart = () => {
    setCartIds(new Set());
    showToast("Cart cleared");
  };

  const handleToggleFavorite = (id: string) => {
    setFavoriteIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        showToast("Removed from favorites");
      } else {
        next.add(id);
        showToast("Added to favorites");
      }
      return next;
    });
  };

  const handleRemoveFromFavorites = (id: string) => {
    setFavoriteIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
    showToast("Removed from favorites");
  };

  const handleCheckoutComplete = (coinsUsed: number) => {
    setUserCoins((prev) => Math.max(0, prev - coinsUsed));
    setCartIds(new Set());
    showToast("Order placed successfully 🎉");
  };

  const cartProducts = PRODUCTS.filter((p) => cartIds.has(p.id));
  const favoriteProducts = PRODUCTS.filter((p) => favoriteIds.has(p.id));

  return (
    <div className="min-h-screen w-full bg-slate-200 font-[system-ui] sm:flex sm:items-center sm:justify-center sm:py-6">
      <div className="relative mx-auto flex h-screen w-full max-w-[430px] flex-col overflow-hidden bg-slate-50 sm:h-[900px] sm:max-h-[92vh] sm:rounded-[2.75rem] sm:shadow-2xl sm:ring-8 sm:ring-slate-900/90">
        {/* Status bar */}
        <div className="z-40 flex shrink-0 items-center justify-between bg-white px-6 pb-1 pt-3 text-[13px] font-semibold text-slate-900 sm:pt-4">
          <span>9:41</span>
          <div className="absolute left-1/2 top-1 hidden h-6 w-32 -translate-x-1/2 rounded-full bg-slate-900 sm:block" />
          <div className="flex items-center gap-1.5">
            <span className="text-[11px]">5G</span>
            <div className="h-2.5 w-4 rounded-[2px] border border-slate-900 relative">
              <span className="absolute inset-y-[1px] left-[1px] right-[3px] bg-slate-900 rounded-[1px]" />
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="relative flex flex-1 flex-col overflow-hidden bg-slate-50">
          <Toast message={toast} />
          {activeTab === "home" && (
            <HomePage
              favoriteIds={favoriteIds}
              cartIds={cartIds}
              onToggleFavorite={handleToggleFavorite}
              onAddToCart={handleAddToCart}
              userCoins={userCoins}
            />
          )}
          {activeTab === "favorites" && (
            <FavoritesPage
              favoriteProducts={favoriteProducts}
              cartIds={cartIds}
              onRemove={handleRemoveFromFavorites}
              onAddToCart={handleAddToCart}
              onNavigate={setActiveTab}
            />
          )}
          {activeTab === "cart" && (
            <CartPage
              cartProducts={cartProducts}
              onRemove={handleRemoveFromCart}
              onClearAll={handleClearCart}
              userCoins={userCoins}
              onCheckoutComplete={handleCheckoutComplete}
              onNavigate={setActiveTab}
            />
          )}
        </div>

        <BottomNav
          active={activeTab}
          onChange={setActiveTab}
          favoritesCount={favoriteIds.size}
          cartCount={cartIds.size}
        />
        <div className="flex shrink-0 justify-center bg-white pb-1.5 pt-0.5">
          <div className="h-1 w-32 rounded-full bg-slate-300" />
        </div>
      </div>
    </div>
  );
}
