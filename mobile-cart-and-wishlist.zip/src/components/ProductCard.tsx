import { Heart, Star } from "lucide-react";
import { Product } from "../types";
import { formatINR } from "../utils/format";

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  inCart: boolean;
  onToggleFavorite: (id: string) => void;
  onAddToCart: (id: string) => void;
}

export default function ProductCard({
  product,
  isFavorite,
  inCart,
  onToggleFavorite,
  onAddToCart,
}: ProductCardProps) {
  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm shadow-slate-200/70 ring-1 ring-slate-100 transition-transform active:scale-[0.98]">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
        <img
          src={product.image}
          alt={product.title}
          className="h-full w-full object-cover"
        />
        {product.bestseller && (
          <span className="absolute left-2 top-2 rounded-full bg-amber-400 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-amber-950 shadow">
            Bestseller
          </span>
        )}
        <button
          onClick={() => onToggleFavorite(product.id)}
          className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur transition active:scale-90"
          aria-label="Toggle favorite"
        >
          <Heart
            size={16}
            className={isFavorite ? "fill-rose-500 text-rose-500" : "text-slate-500"}
          />
        </button>
      </div>
      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-indigo-500">
          {product.category}
        </span>
        <h3 className="line-clamp-2 text-[13px] font-bold leading-snug text-slate-900">
          {product.title}
        </h3>
        <p className="text-[11px] text-slate-400">{product.author}</p>
        <div className="flex items-center gap-1 text-[11px] text-slate-500">
          <Star size={12} className="fill-amber-400 text-amber-400" />
          <span className="font-semibold text-slate-700">{product.rating}</span>
          <span>({product.reviewsCount.toLocaleString("en-IN")})</span>
        </div>
        <div className="mt-1 flex items-center gap-1.5">
          <span className="text-[15px] font-extrabold text-slate-900">
            {formatINR(product.price)}
          </span>
          <span className="text-[11px] text-slate-400 line-through">
            {formatINR(product.originalPrice)}
          </span>
          <span className="text-[11px] font-semibold text-emerald-600">
            {discount}% off
          </span>
        </div>
        <button
          onClick={() => !inCart && onAddToCart(product.id)}
          disabled={inCart}
          className={`mt-2 w-full rounded-xl py-2 text-xs font-bold transition active:scale-95 ${
            inCart
              ? "bg-emerald-50 text-emerald-600"
              : "bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-md shadow-indigo-200"
          }`}
        >
          {inCart ? "Added to Cart ✓" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
}
