export type MessageType = "text" | "image";

export interface ChatMessage {
  id: string;
  sender: "me" | "them";
  type: MessageType;
  text?: string;
  imageUrl?: string;
  time: string;
  status?: "sent" | "delivered" | "seen";
  reaction?: string;
}

export const receiver = {
  name: "Emma Wilson",
  username: "emma.wilson",
  avatar: "/images/avatar-receiver.jpg",
  isActive: true,
};

export const initialMessages: ChatMessage[] = [
  {
    id: "m1",
    sender: "them",
    type: "text",
    text: "Heyyy! How was your weekend? 😄",
    time: "9:12 AM",
  },
  {
    id: "m2",
    sender: "me",
    type: "text",
    text: "It was amazing! Went hiking with friends, the weather was perfect.",
    time: "9:14 AM",
    status: "seen",
  },
  {
    id: "m3",
    sender: "them",
    type: "text",
    text: "That sounds so fun! I just stayed home and binged a show 😂",
    time: "9:15 AM",
  },
  {
    id: "m4",
    sender: "me",
    type: "image",
    imageUrl: "/images/chat-photo-coffee.jpg",
    text: "Also grabbed this on the way back ☕",
    time: "9:17 AM",
    status: "seen",
  },
  {
    id: "m5",
    sender: "them",
    type: "text",
    text: "Okay that looks incredible, now I'm craving coffee ❤️",
    time: "9:18 AM",
    reaction: "❤️",
  },
  {
    id: "m6",
    sender: "me",
    type: "text",
    text: "Haha, we should catch up properly this weekend!",
    time: "9:20 AM",
    status: "delivered",
  },
];
