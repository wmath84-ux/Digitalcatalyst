export interface FeedComment {
  id: string;
  username: string;
  text: string;
}

export interface FeedPostData {
  id: string;
  username: string;
  avatar: string;
  avatarColor?: string;
  initials?: string;
  location?: string;
  images: { url?: string; gradient?: string }[];
  likes: number;
  liked: boolean;
  saved: boolean;
  caption: string;
  comments: FeedComment[];
  time: string;
  isReel?: boolean;
}

export const feedPosts: FeedPostData[] = [
  {
    id: "f1",
    username: "emma.wilson",
    avatar: "/images/avatar-receiver.jpg",
    location: "Blue Mountains",
    images: [
      { url: "/images/post-travel.jpg" },
      { gradient: "from-amber-300 via-orange-300 to-rose-400" },
    ],
    likes: 1247,
    liked: true,
    saved: false,
    caption: "Nothing beats a morning hike with fresh air and golden views. Already planning the next one! 🏔️✨",
    comments: [
      { id: "c1", username: "alex.creates", text: "This is so beautiful 😍" },
      { id: "c2", username: "sophie.travels", text: "Where is this? I need to go!" },
    ],
    time: "2 hours ago",
  },
  {
    id: "f2",
    username: "alex.creates",
    avatar: "/images/avatar-alex.jpg",
    location: "Studio HQ",
    images: [
      { gradient: "from-violet-400 via-purple-500 to-fuchsia-600" },
    ],
    likes: 856,
    liked: false,
    saved: true,
    caption: "Late nights, creative vibes. New project dropping soon — stay tuned 🎨🔥 #design #creative",
    comments: [
      { id: "c3", username: "david.codes", text: "Can't wait to see it bro!" },
      { id: "c4", username: "priya.design", text: "The colors though 🔥🔥" },
      { id: "c5", username: "marcus.fit", text: "Let's gooo" },
    ],
    time: "4 hours ago",
  },
  {
    id: "f3",
    username: "sophie.travels",
    avatar: "/images/avatar-sophie.jpg",
    location: "Santorini, Greece",
    images: [
      { url: "/images/post-coffee.jpg" },
    ],
    likes: 2103,
    liked: false,
    saved: false,
    caption: "Greek island mornings hit different. Coffee with this view? Unreal ☕🌊🇬🇷",
    comments: [
      { id: "c6", username: "emma.wilson", text: "Adding this to my bucket list immediately!" },
      { id: "c7", username: "yourprofile", text: "Bring me next time 😂" },
      { id: "c8", username: "alex.creates", text: "The aesthetic 💯" },
      { id: "c9", username: "priya.design", text: "Stunning!!" },
    ],
    time: "6 hours ago",
  },
  {
    id: "f4",
    username: "marcus.fit",
    avatar: "/images/avatar-marcus.jpg",
    location: "",
    images: [
      { gradient: "from-slate-700 via-gray-800 to-zinc-900" },
    ],
    likes: 542,
    liked: false,
    saved: false,
    caption: "5AM grind. No excuses. Every rep takes you closer to the goal 💪🏾🦵 #legday #fitness",
    comments: [
      { id: "c10", username: "yourprofile", text: "Inspirational man, let's go tomorrow 🔥" },
    ],
    time: "8 hours ago",
  },
  {
    id: "f5",
    username: "priya.design",
    avatar: "/images/avatar-priya.jpg",
    location: "Home Office",
    images: [
      { url: "/images/chat-photo-coffee.jpg" },
      { gradient: "from-rose-300 via-pink-400 to-fuchsia-500" },
    ],
    likes: 987,
    liked: true,
    saved: true,
    caption: "New brand identity work. Minimal, clean, and full of personality — just how I like it 🎨✨",
    comments: [
      { id: "c11", username: "david.codes", text: "Clean AF" },
      { id: "c12", username: "emma.wilson", text: "So talented!" },
    ],
    time: "12 hours ago",
  },
  {
    id: "f6",
    username: "david.codes",
    avatar: "/images/avatar-david.jpg",
    location: "Tech Campus",
    images: [
      { gradient: "from-cyan-400 via-blue-500 to-indigo-600" },
    ],
    likes: 729,
    liked: false,
    saved: false,
    caption: "Ship early, iterate often. V3 of the platform just went live — full rewrite in Rust + React 🦀⚡️",
    comments: [
      { id: "c13", username: "alex.creates", text: "Nerd! But I respect it 👏" },
      { id: "c14", username: "yourprofile", text: "Deployed and already sleeping like a baby 😴" },
      { id: "c15", username: "emma.wilson", text: "Congrats David! 🎉" },
    ],
    time: "16 hours ago",
  },
];
