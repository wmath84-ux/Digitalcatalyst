import { myProfile } from "./conversationsData";

export interface ProfilePost {
  id: string;
  imageUrl?: string;
  gradient?: string;
  likes: number;
  comments: number;
  hasMultiple: boolean;
  isReel: boolean;
}

export interface StoryHighlight {
  id: string;
  title: string;
  gradient: string;
  icon: string;
}

export const profileData = {
  username: myProfile.username,
  fullName: "Your Name",
  avatar: myProfile.avatar,
  bio: "✨ Living my best life\n📸 Capturing moments\n🌍 Travel • Design • Code\n👇 Latest project below",
  link: "linktr.ee/yourprofile",
  stats: {
    posts: 24,
    followers: 12847,
    following: 542,
  },
  highlights: [
    {
      id: "h1",
      title: "Moments",
      gradient: "from-rose-300 via-pink-400 to-purple-500",
      icon: "✨",
    },
    {
      id: "h2",
      title: "Travel",
      gradient: "from-cyan-300 via-blue-400 to-indigo-500",
      icon: "✈️",
    },
    {
      id: "h3",
      title: "Work",
      gradient: "from-amber-300 via-orange-400 to-rose-500",
      icon: "💻",
    },
    {
      id: "h4",
      title: "Food",
      gradient: "from-emerald-300 via-green-400 to-teal-500",
      icon: "🍕",
    },
    {
      id: "h5",
      title: "Daily",
      gradient: "from-violet-300 via-purple-400 to-fuchsia-500",
      icon: "🌅",
    },
  ] as StoryHighlight[],
  posts: [
    {
      id: "p1",
      imageUrl: "/images/post-travel.jpg",
      likes: 1247,
      comments: 48,
      hasMultiple: true,
      isReel: true,
    },
    {
      id: "p2",
      imageUrl: "/images/post-coffee.jpg",
      likes: 856,
      comments: 23,
      hasMultiple: false,
      isReel: false,
    },
    {
      id: "p3",
      gradient: "from-indigo-400 via-purple-400 to-pink-400",
      likes: 2103,
      comments: 112,
      hasMultiple: false,
      isReel: false,
    },
    {
      id: "p4",
      gradient: "from-amber-300 via-orange-300 to-rose-300",
      likes: 632,
      comments: 17,
      hasMultiple: true,
      isReel: false,
    },
    {
      id: "p5",
      gradient: "from-emerald-300 via-teal-300 to-cyan-300",
      likes: 1542,
      comments: 67,
      hasMultiple: false,
      isReel: true,
    },
    {
      id: "p6",
      gradient: "from-slate-300 via-gray-300 to-zinc-300",
      likes: 421,
      comments: 12,
      hasMultiple: false,
      isReel: false,
    },
    {
      id: "p7",
      gradient: "from-red-300 via-rose-400 to-pink-500",
      likes: 987,
      comments: 34,
      hasMultiple: true,
      isReel: false,
    },
    {
      id: "p8",
      gradient: "from-sky-300 via-blue-400 to-indigo-400",
      likes: 1847,
      comments: 89,
      hasMultiple: false,
      isReel: true,
    },
    {
      id: "p9",
      gradient: "from-lime-300 via-green-400 to-emerald-500",
      likes: 521,
      comments: 21,
      hasMultiple: false,
      isReel: false,
    },
  ] as ProfilePost[],
};
