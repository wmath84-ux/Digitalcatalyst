import type { ChatMessage } from "./chatData";

export interface Conversation {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isActive: boolean;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isMuted: boolean;
  lastSender: "me" | "them";
  hasStory: boolean;
  storyRingColor?: string;
  messages: ChatMessage[];
  autoReply: string;
}

export const myProfile = {
  name: "You",
  username: "yourprofile",
  avatar: "/images/avatar-me.jpg",
};

export const conversations: Conversation[] = [
  {
    id: "c1",
    name: "Emma Wilson",
    username: "emma.wilson",
    avatar: "/images/avatar-receiver.jpg",
    isActive: true,
    lastMessage: "Okay that looks incredible, now I'm craving coffee ❤️",
    lastMessageTime: "9:18 AM",
    unreadCount: 0,
    isMuted: false,
    lastSender: "them",
    hasStory: true,
    storyRingColor: "from-amber-400 via-pink-500 to-purple-600",
    messages: [
      { id: "m1", sender: "them", type: "text", text: "Heyyy! How was your weekend? 😄", time: "9:12 AM" },
      { id: "m2", sender: "me", type: "text", text: "It was amazing! Went hiking with friends, the weather was perfect.", time: "9:14 AM", status: "seen" },
      { id: "m3", sender: "them", type: "text", text: "That sounds so fun! I just stayed home and binged a show 😂", time: "9:15 AM" },
      { id: "m4", sender: "me", type: "image", imageUrl: "/images/chat-photo-coffee.jpg", text: "Also grabbed this on the way back ☕", time: "9:17 AM", status: "seen" },
      { id: "m5", sender: "them", type: "text", text: "Okay that looks incredible, now I'm craving coffee ❤️", time: "9:18 AM", reaction: "❤️" },
      { id: "m6", sender: "me", type: "text", text: "Haha, we should catch up properly this weekend!", time: "9:20 AM", status: "delivered" },
    ],
    autoReply: "Haha totally! Let's plan it 🙌",
  },
  {
    id: "c2",
    name: "Alex Kim",
    username: "alex.creates",
    avatar: "/images/avatar-alex.jpg",
    isActive: true,
    lastMessage: "Bro that reel was fire 🔥🔥",
    lastMessageTime: "11:45 AM",
    unreadCount: 3,
    isMuted: false,
    lastSender: "them",
    hasStory: true,
    storyRingColor: "from-cyan-400 via-blue-500 to-indigo-600",
    messages: [
      { id: "a1", sender: "them", type: "text", text: "Yo! Did you see my latest reel?", time: "11:30 AM" },
      { id: "a2", sender: "me", type: "text", text: "Not yet, just woke up lol", time: "11:32 AM", status: "seen" },
      { id: "a3", sender: "them", type: "text", text: "Go check it out rn, I spent 6 hours editing that 😤", time: "11:33 AM" },
      { id: "a4", sender: "me", type: "text", text: "Okay okay I'll check it", time: "11:35 AM", status: "seen" },
      { id: "a5", sender: "them", type: "text", text: "Bro that reel was fire 🔥🔥", time: "11:45 AM" },
    ],
    autoReply: "Told you! Thanks bro 😎",
  },
  {
    id: "c3",
    name: "Priya Patel",
    username: "priya.design",
    avatar: "/images/avatar-priya.jpg",
    isActive: false,
    lastMessage: "Can you review my portfolio?",
    lastMessageTime: "Yesterday",
    unreadCount: 1,
    isMuted: false,
    lastSender: "them",
    hasStory: false,
    messages: [
      { id: "p1", sender: "them", type: "text", text: "Hey! How are you?", time: "4:10 PM" },
      { id: "p2", sender: "me", type: "text", text: "Hey Priya! I'm good, what's up?", time: "4:15 PM", status: "seen" },
      { id: "p3", sender: "them", type: "text", text: "I finally redesigned my portfolio website! 🎨", time: "4:16 PM" },
      { id: "p4", sender: "them", type: "text", text: "Can you review my portfolio?", time: "4:17 PM" },
    ],
    autoReply: "Thanks so much! I'll send you the link 🔗",
  },
  {
    id: "c4",
    name: "Marcus Brown",
    username: "marcus.fit",
    avatar: "/images/avatar-marcus.jpg",
    isActive: true,
    lastMessage: "See you at 6 AM tomorrow 💪",
    lastMessageTime: "8:30 PM",
    unreadCount: 0,
    isMuted: false,
    lastSender: "me",
    hasStory: true,
    storyRingColor: "from-green-400 via-emerald-500 to-teal-600",
    messages: [
      { id: "ma1", sender: "them", type: "text", text: "Gym tomorrow?", time: "8:00 PM" },
      { id: "ma2", sender: "me", type: "text", text: "Absolutely! What time?", time: "8:05 PM", status: "seen" },
      { id: "ma3", sender: "them", type: "text", text: "6 AM? Let's hit legs 🦵", time: "8:10 PM" },
      { id: "ma4", sender: "me", type: "text", text: "See you at 6 AM tomorrow 💪", time: "8:30 PM", status: "delivered" },
    ],
    autoReply: "Let's go! Don't skip the warm up this time 😂",
  },
  {
    id: "c5",
    name: "Sophie Laurent",
    username: "sophie.travels",
    avatar: "/images/avatar-sophie.jpg",
    isActive: false,
    lastMessage: "The sunset in Santorini was unreal 🌅",
    lastMessageTime: "Tuesday",
    unreadCount: 0,
    isMuted: true,
    lastSender: "them",
    hasStory: true,
    storyRingColor: "from-rose-400 via-pink-500 to-fuchsia-600",
    messages: [
      { id: "s1", sender: "them", type: "text", text: "Guess where I am!! 🏖️", time: "2:00 PM" },
      { id: "s2", sender: "me", type: "text", text: "Hmm Bali?", time: "2:30 PM", status: "seen" },
      { id: "s3", sender: "them", type: "text", text: "Nope! Santorini, Greece!! 🇬🇷", time: "2:31 PM" },
      { id: "s4", sender: "them", type: "text", text: "The sunset in Santorini was unreal 🌅", time: "3:00 PM" },
    ],
    autoReply: "I know right?! You should visit sometime ✈️",
  },
  {
    id: "c6",
    name: "David Chen",
    username: "david.codes",
    avatar: "/images/avatar-david.jpg",
    isActive: false,
    lastMessage: "PR merged ✅ Let's deploy after lunch",
    lastMessageTime: "Monday",
    unreadCount: 0,
    isMuted: false,
    lastSender: "them",
    hasStory: false,
    messages: [
      { id: "d1", sender: "me", type: "text", text: "Hey, pushed the new auth changes", time: "10:00 AM", status: "seen" },
      { id: "d2", sender: "them", type: "text", text: "Nice, I'll review it in a bit", time: "10:05 AM" },
      { id: "d3", sender: "them", type: "text", text: "Looks clean! Just one small comment on line 42", time: "10:30 AM" },
      { id: "d4", sender: "me", type: "text", text: "Fixed! Check again", time: "10:45 AM", status: "seen" },
      { id: "d5", sender: "them", type: "text", text: "PR merged ✅ Let's deploy after lunch", time: "11:00 AM" },
    ],
    autoReply: "Sounds good, I'll set up the staging env 🚀",
  },
];
