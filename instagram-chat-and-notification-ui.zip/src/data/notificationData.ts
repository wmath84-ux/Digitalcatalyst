export type NotificationKind = "like" | "follow" | "comment" | "message" | "mention";

export interface NotificationItemData {
  id: string;
  name: string;
  initials: string;
  color: string;
  kind: NotificationKind;
  text: string;
  time: string;
  group: "Today" | "Earlier";
  unread: boolean;
}

export const notifications: NotificationItemData[] = [
  {
    id: "n1",
    name: "John Carter",
    initials: "JC",
    color: "bg-blue-500",
    kind: "like",
    text: "liked your post",
    time: "2m",
    group: "Today",
    unread: true,
  },
  {
    id: "n2",
    name: "Sarah Lee",
    initials: "SL",
    color: "bg-pink-500",
    kind: "follow",
    text: "started following you",
    time: "18m",
    group: "Today",
    unread: true,
  },
  {
    id: "n3",
    name: "Mike Johnson",
    initials: "MJ",
    color: "bg-emerald-500",
    kind: "comment",
    text: 'commented: "This is awesome!"',
    time: "1h",
    group: "Today",
    unread: true,
  },
  {
    id: "n4",
    name: "Priya Patel",
    initials: "PP",
    color: "bg-violet-500",
    kind: "mention",
    text: "mentioned you in a comment",
    time: "3h",
    group: "Today",
    unread: false,
  },
  {
    id: "n5",
    name: "Alex Kim",
    initials: "AK",
    color: "bg-amber-500",
    kind: "message",
    text: "sent you a message",
    time: "5h",
    group: "Today",
    unread: false,
  },
  {
    id: "n6",
    name: "Olivia Brown",
    initials: "OB",
    color: "bg-rose-500",
    kind: "like",
    text: "liked your comment",
    time: "Yesterday",
    group: "Earlier",
    unread: false,
  },
  {
    id: "n7",
    name: "David Chen",
    initials: "DC",
    color: "bg-indigo-500",
    kind: "follow",
    text: "started following you",
    time: "2d",
    group: "Earlier",
    unread: false,
  },
  {
    id: "n8",
    name: "Nina Torres",
    initials: "NT",
    color: "bg-teal-500",
    kind: "comment",
    text: 'commented: "Love this!"',
    time: "3d",
    group: "Earlier",
    unread: false,
  },
];
