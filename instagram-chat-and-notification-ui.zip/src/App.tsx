import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import ChatHeader from "./components/chat/ChatHeader";
import MessageList from "./components/chat/MessageList";
import ChatInput from "./components/chat/ChatInput";
import NotificationPanel from "./components/notifications/NotificationPanel";
import InboxPage from "./components/inbox/InboxPage";
import ProfilePage from "./components/profile/ProfilePage";
import HomePage from "./components/home/HomePage";
import { conversations as initialConversations, type Conversation } from "./data/conversationsData";
import { notifications as initialNotifications } from "./data/notificationData";
import type { NotificationItemData } from "./data/notificationData";
import type { ChatMessage } from "./data/chatData";

type Page =
  | { kind: "home" }
  | { kind: "inbox" }
  | { kind: "chat"; conversationId: string }
  | { kind: "profile" };

export default function App() {
  const [page, setPage] = useState<Page>({ kind: "home" });
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [activeMsgs, setActiveMsgs] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState<NotificationItemData[]>(initialNotifications);

  const hasUnread = notifs.some((n) => n.unread);

  const activeConvo =
    page.kind === "chat"
      ? conversations.find((c) => c.id === page.conversationId) ?? null
      : null;

  const openChat = useCallback(
    (id: string) => {
      const convo = conversations.find((c) => c.id === id);
      if (!convo) return;
      setActiveMsgs([...convo.messages]);
      setPage({ kind: "chat", conversationId: id });
      setConversations((prev) =>
        prev.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c))
      );
    },
    [conversations]
  );

  const goBack = useCallback(() => {
    if (page.kind === "chat") {
      const lastMsg = activeMsgs[activeMsgs.length - 1];
      setConversations((prev) =>
        prev.map((c) =>
          c.id === page.conversationId
            ? {
                ...c,
                messages: activeMsgs,
                lastMessage: lastMsg?.text || lastMsg?.imageUrl || c.lastMessage,
                lastSender: lastMsg?.sender || c.lastSender,
                lastMessageTime: lastMsg?.time || c.lastMessageTime,
              }
            : c
        )
      );
      setPage({ kind: "inbox" });
    } else {
      setPage({ kind: "home" });
    }
    setIsTyping(false);
  }, [page, activeMsgs]);

  const handleSend = useCallback(
    (text: string) => {
      if (!activeConvo) return;
      const newMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        sender: "me",
        type: "text",
        text,
        time: new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
        status: "delivered",
      };
      setActiveMsgs((prev) => [...prev, newMsg]);

      setIsTyping(true);
      const delay = 1200 + Math.random() * 1200;
      setTimeout(() => {
        setIsTyping(false);
        const reply: ChatMessage = {
          id: `r-${Date.now()}`,
          sender: "them",
          type: "text",
          text: activeConvo.autoReply,
          time: new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
        };
        setActiveMsgs((prev) => [...prev, reply]);
      }, delay);
    },
    [activeConvo]
  );

  const handleReact = useCallback((id: string, reaction: string) => {
    setActiveMsgs((prev) =>
      prev.map((m) =>
        m.id === id ? { ...m, reaction: m.reaction ? undefined : reaction } : m
      )
    );
  }, []);

  const handleMarkAllRead = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  const handleDismissNotif = (id: string) => {
    setNotifs((prev) => prev.filter((n) => n.id !== id));
  };

  const [chatFirstOpen, setChatFirstOpen] = useState<string | null>(null);
  useEffect(() => {
    if (page.kind === "chat" && chatFirstOpen !== page.conversationId) {
      setChatFirstOpen(page.conversationId);
      const t1 = setTimeout(() => setIsTyping(true), 2000);
      const t2 = setTimeout(() => setIsTyping(false), 3800);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    }
  }, [page, chatFirstOpen]);

  const slideInRight = {
    initial: { x: "100%", opacity: 0.4 },
    animate: { x: 0, opacity: 1 },
    exit: { x: "100%", opacity: 0.4 },
  };

  const slideInLeft = {
    initial: { x: 0, opacity: 1 },
    animate: { x: 0, opacity: 1 },
    exit: { x: "-30%", opacity: 0.4 },
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-900 p-0 sm:p-6">
      <div className="relative flex h-[100dvh] w-full max-w-md flex-col overflow-hidden bg-white shadow-2xl sm:h-[850px] sm:rounded-[2.5rem] sm:ring-8 sm:ring-black">
        <AnimatePresence mode="sync" initial={false}>
          {/* Home */}
          {page.kind === "home" && (
            <motion.div
              key="home"
              className="absolute inset-0 flex flex-col"
              initial={slideInLeft.initial}
              animate={slideInLeft.animate}
              exit={slideInLeft.exit}
              transition={{ type: "tween", duration: 0.28, ease: [0.25, 0.8, 0.25, 1] }}
            >
              <HomePage
                onBellClick={() => setNotifOpen(true)}
                onInboxClick={() => setPage({ kind: "inbox" })}
                onProfileClick={() => setPage({ kind: "profile" })}
                hasUnread={hasUnread}
                conversations={conversations}
              />
            </motion.div>
          )}

          {/* Inbox */}
          {page.kind === "inbox" && (
            <motion.div
              key="inbox"
              className="absolute inset-0 flex flex-col"
              initial={slideInRight.initial}
              animate={slideInRight.animate}
              exit={page.kind === "inbox" ? undefined : slideInLeft.exit}
              transition={{ type: "tween", duration: 0.28, ease: [0.25, 0.8, 0.25, 1] }}
            >
              <InboxPage
                conversations={conversations}
                onSelectChat={openChat}
                onBellClick={() => setNotifOpen(true)}
                onProfileClick={() => setPage({ kind: "profile" })}
                onHomeClick={() => setPage({ kind: "home" })}
                hasUnread={hasUnread}
              />
            </motion.div>
          )}

          {/* Chat */}
          {page.kind === "chat" && activeConvo && (
            <motion.div
              key={`chat-${activeConvo.id}`}
              className="absolute inset-0 flex flex-col bg-white"
              initial={slideInRight.initial}
              animate={slideInRight.animate}
              exit={slideInRight.exit}
              transition={{ type: "tween", duration: 0.3, ease: [0.25, 0.8, 0.25, 1] }}
            >
              <ChatHeader
                name={activeConvo.name}
                avatar={activeConvo.avatar}
                isActive={activeConvo.isActive}
                onBack={goBack}
                onBellClick={() => setNotifOpen(true)}
                hasUnread={hasUnread}
              />
              <MessageList messages={activeMsgs} isTyping={isTyping} onReact={handleReact} />
              <ChatInput onSend={handleSend} />
            </motion.div>
          )}

          {/* Profile */}
          {page.kind === "profile" && (
            <motion.div
              key="profile"
              className="absolute inset-0 flex flex-col bg-white"
              initial={slideInRight.initial}
              animate={slideInRight.animate}
              exit={slideInRight.exit}
              transition={{ type: "tween", duration: 0.3, ease: [0.25, 0.8, 0.25, 1] }}
            >
              <ProfilePage onBack={() => setPage({ kind: "home" })} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Notification overlay */}
        <NotificationPanel
          open={notifOpen}
          onClose={() => setNotifOpen(false)}
          items={notifs}
          onMarkAllRead={handleMarkAllRead}
          onDismiss={handleDismissNotif}
        />
      </div>
    </div>
  );
}
