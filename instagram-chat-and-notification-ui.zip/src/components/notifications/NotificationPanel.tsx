import { AnimatePresence, motion } from "framer-motion";
import { BellRing, CheckCheck, X } from "lucide-react";
import type { NotificationItemData } from "../../data/notificationData";
import NotificationItem from "./NotificationItem";

interface NotificationPanelProps {
  open: boolean;
  onClose: () => void;
  items: NotificationItemData[];
  onMarkAllRead: () => void;
  onDismiss: (id: string) => void;
}

export default function NotificationPanel({
  open,
  onClose,
  items,
  onMarkAllRead,
  onDismiss,
}: NotificationPanelProps) {
  const today = items.filter((i) => i.group === "Today");
  const earlier = items.filter((i) => i.group === "Earlier");
  const unreadCount = items.filter((i) => i.unread).length;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Dimmed / blurred backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="absolute inset-0 z-40 bg-black/40 backdrop-blur-sm"
          />

          {/* Android style notification shade */}
          <motion.div
            initial={{ y: "-100%" }}
            animate={{ y: 0 }}
            exit={{ y: "-100%" }}
            transition={{ type: "spring", stiffness: 260, damping: 28, mass: 0.9 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0.15, bottom: 0 }}
            onDragEnd={(_, info) => {
              if (info.offset.y < -60) onClose();
            }}
            className="absolute inset-x-0 top-0 z-50 flex max-h-[85%] flex-col rounded-b-3xl bg-gray-50 shadow-2xl"
          >
            {/* drag handle */}
            <div className="flex justify-center pt-2">
              <div className="h-1.5 w-10 rounded-full bg-gray-300" />
            </div>

            <div className="flex items-center justify-between px-4 pb-3 pt-2">
              <div className="flex items-center gap-2">
                <BellRing size={18} className="text-gray-900" />
                <h2 className="text-base font-semibold text-gray-900">Notifications</h2>
                {unreadCount > 0 && (
                  <span className="rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {unreadCount}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={onMarkAllRead}
                  className="flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-xs font-medium text-sky-600 shadow-sm active:bg-gray-100"
                >
                  <CheckCheck size={14} />
                  Mark all read
                </button>
                <button
                  onClick={onClose}
                  className="flex h-8 w-8 items-center justify-center rounded-full text-gray-500 active:bg-gray-200"
                  aria-label="Close"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            <div className="scrollbar-none flex-1 overflow-y-auto pb-4 [&::-webkit-scrollbar]:hidden">
              {today.length > 0 && (
                <div className="mb-2">
                  <p className="px-4 pb-1 pt-1 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    Today
                  </p>
                  <div className="divide-y divide-gray-100">
                    {today.map((n) => (
                      <NotificationItem key={n.id} item={n} onDismiss={onDismiss} />
                    ))}
                  </div>
                </div>
              )}

              {earlier.length > 0 && (
                <div>
                  <p className="px-4 pb-1 pt-1 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    Earlier
                  </p>
                  <div className="divide-y divide-gray-100">
                    {earlier.map((n) => (
                      <NotificationItem key={n.id} item={n} onDismiss={onDismiss} />
                    ))}
                  </div>
                </div>
              )}

              {items.length === 0 && (
                <div className="flex flex-col items-center justify-center gap-2 py-16 text-gray-400">
                  <BellRing size={32} />
                  <p className="text-sm">You're all caught up!</p>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
