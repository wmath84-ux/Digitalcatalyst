import { motion, useAnimation, type PanInfo } from "framer-motion";
import { Heart, UserPlus, MessageCircle, AtSign, Mail, Trash2 } from "lucide-react";
import Avatar from "../Avatar";
import type { NotificationItemData } from "../../data/notificationData";

const iconMap = {
  like: <Heart size={12} className="fill-white text-white" />,
  follow: <UserPlus size={12} className="text-white" />,
  comment: <MessageCircle size={12} className="fill-white text-white" />,
  mention: <AtSign size={12} className="text-white" />,
  message: <Mail size={12} className="text-white" />,
};

const iconBg = {
  like: "bg-red-500",
  follow: "bg-blue-500",
  comment: "bg-emerald-500",
  mention: "bg-violet-500",
  message: "bg-amber-500",
};

interface NotificationItemProps {
  item: NotificationItemData;
  onDismiss: (id: string) => void;
}

export default function NotificationItem({ item, onDismiss }: NotificationItemProps) {
  const controls = useAnimation();

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (Math.abs(info.offset.x) > 90) {
      controls
        .start({
          x: info.offset.x > 0 ? 400 : -400,
          opacity: 0,
          transition: { duration: 0.25 },
        })
        .then(() => onDismiss(item.id));
    } else {
      controls.start({ x: 0, transition: { type: "spring", stiffness: 500, damping: 30 } });
    }
  };

  return (
    <div className="relative overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-end bg-red-500 px-5">
        <Trash2 size={18} className="text-white" />
      </div>
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.7}
        animate={controls}
        onDragEnd={handleDragEnd}
        className="relative flex items-center gap-3 bg-white px-4 py-3 active:bg-gray-50"
      >
        <div className="relative shrink-0">
          <Avatar initials={item.initials} colorClass={item.color} size={44} />
          <span
            className={`absolute -bottom-0.5 -right-0.5 flex items-center justify-center rounded-full ring-2 ring-white ${iconBg[item.kind]}`}
            style={{ height: 18, width: 18 }}
          >
            {iconMap[item.kind]}
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] text-gray-900">
            <span className="font-semibold">{item.name}</span> {item.text}
          </p>
          <p className="mt-0.5 text-xs text-gray-500">{item.time} ago</p>
        </div>
        {item.unread && <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-sky-500" />}
      </motion.div>
    </div>
  );
}
