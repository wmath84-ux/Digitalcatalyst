import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Home, Search as SearchIcon, Film, MessageCircle } from "lucide-react";
import InboxHeader from "./InboxHeader";
import SearchBar from "./SearchBar";
import StoryRing from "./StoryRing";
import ConversationRow from "./ConversationRow";
import type { Conversation } from "../../data/conversationsData";
import { myProfile } from "../../data/conversationsData";

interface InboxPageProps {
  conversations: Conversation[];
  onSelectChat: (id: string) => void;
  onBellClick: () => void;
  onProfileClick: () => void;
  onHomeClick: () => void;
  hasUnread: boolean;
}

export default function InboxPage({
  conversations,
  onSelectChat,
  onBellClick,
  onProfileClick,
  onHomeClick,
  hasUnread,
}: InboxPageProps) {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"primary" | "general">("primary");

  const storiedConvos = conversations.filter((c) => c.hasStory);

  const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return conversations.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.username.toLowerCase().includes(q) ||
        c.lastMessage.toLowerCase().includes(q)
    );
  }, [search, conversations]);

  return (
    <div className="flex h-full flex-col bg-white">
      <InboxHeader onBellClick={onBellClick} hasUnread={hasUnread} />

      <SearchBar value={search} onChange={setSearch} />

      {/* Stories strip */}
      {!search && (
        <div className="scrollbar-none border-b border-gray-100 pb-3">
          <div className="flex gap-1 overflow-x-auto px-3">
            {/* Your Story */}
            <div className="flex shrink-0 flex-col items-center gap-1.5 px-1">
              <div className="relative">
                <div className="rounded-full border-2 border-dashed border-gray-300 p-[2.5px]">
                  <img
                    src={myProfile.avatar}
                    alt="Your story"
                    className="h-[62px] w-[62px] rounded-full object-cover opacity-80"
                  />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-blue-500 text-white ring-[2.5px] ring-white text-[11px] font-bold leading-none">
                  +
                </span>
              </div>
              <span className="w-[72px] truncate text-center text-[11px] text-gray-700">
                Your story
              </span>
            </div>

            {storiedConvos.map((c) => (
              <StoryRing key={c.id} conversation={c} />
            ))}
          </div>
        </div>
      )}

      {/* Tabs */}
      {!search && (
        <div className="flex border-b border-gray-100 px-4">
          <button
            onClick={() => setActiveTab("primary")}
            className={`relative flex-1 py-3 text-center text-[13px] font-semibold transition-colors ${
              activeTab === "primary" ? "text-gray-900" : "text-gray-400"
            }`}
          >
            Primary
            {activeTab === "primary" && (
              <motion.div
                layoutId="inbox-tab-indicator"
                className="absolute bottom-0 left-2 right-2 h-[2px] rounded-full bg-gray-900"
              />
            )}
          </button>
          <button
            onClick={() => setActiveTab("general")}
            className={`relative flex-1 py-3 text-center text-[13px] font-semibold transition-colors ${
              activeTab === "general" ? "text-gray-900" : "text-gray-400"
            }`}
          >
            General
            {activeTab === "general" && (
              <motion.div
                layoutId="inbox-tab-indicator"
                className="absolute bottom-0 left-2 right-2 h-[2px] rounded-full bg-gray-900"
              />
            )}
          </button>
          <button
            className="relative flex-1 py-3 text-center text-[13px] font-semibold text-gray-400"
          >
            Requests
          </button>
        </div>
      )}

      {/* Conversation list */}
      <div className="scrollbar-none flex-1 overflow-y-auto">
        {activeTab === "primary" || search ? (
          filtered.length > 0 ? (
            <div>
              {filtered.map((c, i) => (
                <ConversationRow
                  key={c.id}
                  conversation={c}
                  onClick={() => onSelectChat(c.id)}
                  index={i}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-3 py-20 text-gray-400">
              <span className="text-4xl">💬</span>
              <p className="text-sm">No conversations found</p>
            </div>
          )
        ) : (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-gray-400">
            <span className="text-4xl">📨</span>
            <p className="text-sm font-medium text-gray-500">General messages</p>
            <p className="text-xs text-gray-400">No messages here yet</p>
          </div>
        )}
      </div>

      {/* Bottom navigation bar – Instagram style */}
      <div className="flex items-center justify-around border-t border-gray-200 bg-white px-2 pb-1 pt-2">
        <button onClick={onHomeClick} className="flex flex-col items-center gap-0.5 px-3 py-1">
          <Home size={24} className="text-gray-500" />
        </button>
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <SearchIcon size={24} className="text-gray-500" />
        </button>
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <Film size={24} className="text-gray-500" />
        </button>
        <button className="relative flex flex-col items-center gap-0.5 px-3 py-1" disabled>
          <MessageCircle size={24} className="text-gray-900" fill="currentColor" />
          {totalUnread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
              {totalUnread}
            </span>
          )}
        </button>
        <button onClick={onProfileClick} className="flex flex-col items-center gap-0.5 px-3 py-1">
          <div className="h-7 w-7 overflow-hidden rounded-full ring-2 ring-gray-300">
            <img src={myProfile.avatar} alt="Profile" className="h-full w-full object-cover" />
          </div>
        </button>
      </div>
    </div>
  );
}
