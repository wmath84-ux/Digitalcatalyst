import { Bell, ChevronDown, Edit } from "lucide-react";
import { myProfile } from "../../data/conversationsData";

interface InboxHeaderProps {
  onBellClick: () => void;
  hasUnread: boolean;
}

export default function InboxHeader({ onBellClick, hasUnread }: InboxHeaderProps) {
  return (
    <div className="flex items-center justify-between border-b border-gray-100 bg-white px-4 py-3">
      <div className="flex items-center gap-1">
        <img
          src={myProfile.avatar}
          alt="Me"
          className="h-8 w-8 rounded-full object-cover ring-2 ring-gray-200"
        />
        <div className="flex items-center gap-0.5">
          <h1 className="text-xl font-bold text-gray-900 pl-1.5">{myProfile.username}</h1>
          <ChevronDown size={18} className="text-gray-900 mt-0.5" />
        </div>
      </div>
      <div className="flex items-center gap-1">
        <button
          onClick={onBellClick}
          className="relative flex h-10 w-10 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Notifications"
        >
          <Bell size={24} />
          {hasUnread && (
            <span className="absolute right-2 top-2 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white" />
          )}
        </button>
        <button
          className="flex h-10 w-10 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="New message"
        >
          <Edit size={22} />
        </button>
      </div>
    </div>
  );
}
