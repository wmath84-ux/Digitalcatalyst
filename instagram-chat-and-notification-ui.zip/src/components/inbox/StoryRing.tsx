import type { Conversation } from "../../data/conversationsData";

interface StoryRingProps {
  conversation: Conversation;
}

export default function StoryRing({ conversation }: StoryRingProps) {
  if (!conversation.hasStory) return null;

  return (
    <div className="flex shrink-0 flex-col items-center gap-1.5 px-1">
      <div
        className={`rounded-full bg-gradient-to-br ${conversation.storyRingColor || "from-amber-400 via-pink-500 to-purple-600"} p-[2.5px]`}
      >
        <div className="rounded-full bg-white p-[2px]">
          <img
            src={conversation.avatar}
            alt={conversation.name}
            className="h-[62px] w-[62px] rounded-full object-cover"
          />
        </div>
      </div>
      <span className="w-[72px] truncate text-center text-[11px] text-gray-700">
        {conversation.name.split(" ")[0]}
      </span>
    </div>
  );
}
