import { motion } from "framer-motion";
import { Camera, VolumeX } from "lucide-react";
import Avatar from "../Avatar";
import type { Conversation } from "../../data/conversationsData";

interface ConversationRowProps {
  conversation: Conversation;
  onClick: () => void;
  index: number;
}

export default function ConversationRow({ conversation, onClick, index }: ConversationRowProps) {
  const c = conversation;

  return (
    <motion.button
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.035, duration: 0.28, ease: "easeOut" }}
      onClick={onClick}
      className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors active:bg-gray-50"
    >
      {/* Avatar with story ring or active dot */}
      <div className="relative shrink-0">
        {c.hasStory ? (
          <div
            className={`rounded-full bg-gradient-to-br ${c.storyRingColor || "from-amber-400 via-pink-500 to-purple-600"} p-[2px]`}
          >
            <div className="rounded-full bg-white p-[1.5px]">
              <img
                src={c.avatar}
                alt={c.name}
                className="h-[50px] w-[50px] rounded-full object-cover"
              />
            </div>
          </div>
        ) : (
          <Avatar src={c.avatar} size={54} />
        )}
        {c.isActive && (
          <span className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-white bg-green-500" />
        )}
      </div>

      {/* Text content */}
      <div className="min-w-0 flex-1">
        <p
          className={`truncate text-[15px] leading-tight ${
            c.unreadCount > 0 ? "font-bold text-gray-900" : "font-normal text-gray-900"
          }`}
        >
          {c.name}
        </p>
        <div className="flex items-center gap-1 mt-0.5">
          <p
            className={`flex-1 truncate text-[13px] leading-tight ${
              c.unreadCount > 0 ? "font-semibold text-gray-800" : "text-gray-500"
            }`}
          >
            {c.lastSender === "me" && (
              <span className="text-gray-400">You: </span>
            )}
            {c.lastMessage}
          </p>
          <span className="shrink-0 px-0.5 text-gray-300">·</span>
          <span
            className={`shrink-0 text-xs ${
              c.unreadCount > 0 ? "font-semibold text-gray-900" : "text-gray-400"
            }`}
          >
            {c.lastMessageTime}
          </span>
        </div>
      </div>

      {/* Right side icons */}
      <div className="flex shrink-0 items-center gap-2">
        {c.isMuted && <VolumeX size={16} className="text-gray-300" />}
        {c.unreadCount > 0 ? (
          <span className="flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-blue-500 px-1 text-[10px] font-bold text-white leading-none">
            {c.unreadCount}
          </span>
        ) : (
          <Camera size={20} className="text-gray-400" />
        )}
      </div>
    </motion.button>
  );
}
