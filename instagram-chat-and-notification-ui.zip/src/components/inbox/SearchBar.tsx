import { Search } from "lucide-react";
import { useState } from "react";

interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
}

export default function SearchBar({ value, onChange }: SearchBarProps) {
  const [focused, setFocused] = useState(false);

  return (
    <div className="px-4 py-2">
      <div
        className={`flex items-center gap-2 rounded-xl px-3 py-2.5 transition-colors ${
          focused ? "bg-gray-100 ring-1 ring-gray-300" : "bg-gray-100/80"
        }`}
      >
        <Search size={16} className="shrink-0 text-gray-500" />
        <input
          type="text"
          placeholder="Search"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="flex-1 bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-500"
        />
      </div>
    </div>
  );
}
