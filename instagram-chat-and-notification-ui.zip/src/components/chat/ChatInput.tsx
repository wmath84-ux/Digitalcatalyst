import { useRef, useState } from "react";
import { Camera, Image as ImageIcon, Mic, Send, Smile } from "lucide-react";

interface ChatInputProps {
  onSend: (text: string) => void;
}

export default function ChatInput({ onSend }: ChatInputProps) {
  const [text, setText] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    const el = textareaRef.current;
    if (el) {
      el.style.height = "auto";
      el.style.height = `${Math.min(el.scrollHeight, 110)}px`;
    }
  };

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setText("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex items-end gap-2 border-t border-gray-200 bg-white px-2.5 py-2">
      <button
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-gray-800 active:bg-gray-100"
        aria-label="Camera"
      >
        <Camera size={24} />
      </button>

      <div className="flex flex-1 items-end gap-1.5 rounded-3xl bg-gray-100 px-3 py-1.5">
        <button
          className="mb-1 flex h-7 w-7 shrink-0 items-center justify-center text-gray-500"
          aria-label="Gallery"
        >
          <ImageIcon size={20} />
        </button>
        <textarea
          ref={textareaRef}
          rows={1}
          value={text}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder="Message..."
          className="max-h-[110px] flex-1 resize-none bg-transparent py-1.5 text-[15px] leading-tight text-gray-900 outline-none placeholder:text-gray-500"
        />
        <button
          className="mb-1 flex h-7 w-7 shrink-0 items-center justify-center text-gray-500"
          aria-label="Emoji"
        >
          <Smile size={20} />
        </button>
      </div>

      {text.trim() ? (
        <button
          onClick={handleSend}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-500 to-orange-400 text-white shadow-md active:scale-95"
          aria-label="Send"
        >
          <Send size={18} />
        </button>
      ) : (
        <button
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-gray-800 active:bg-gray-100"
          aria-label="Voice note"
        >
          <Mic size={23} />
        </button>
      )}
    </div>
  );
}
