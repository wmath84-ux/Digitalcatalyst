import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, CheckCheck } from "lucide-react";
import type { ChatMessage } from "../../data/chatData";

interface MessageBubbleProps {
  message: ChatMessage;
  onReact: (id: string, reaction: string) => void;
}

export default function MessageBubble({ message, onReact }: MessageBubbleProps) {
  const isMe = message.sender === "me";
  const [showBurst, setShowBurst] = useState(false);
  const lastTap = useRef(0);

  const handleTap = () => {
    const now = Date.now();
    if (now - lastTap.current < 300) {
      onReact(message.id, "❤️");
      setShowBurst(true);
      setTimeout(() => setShowBurst(false), 700);
    }
    lastTap.current = now;
  };

  return (
    <div className={`flex flex-col px-3 ${isMe ? "items-end" : "items-start"}`}>
      <motion.div
        initial={{ opacity: 0, scale: 0.85, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 400, damping: 28 }}
        onClick={handleTap}
        className={`relative max-w-[75%] select-none ${isMe ? "" : ""}`}
      >
        {message.type === "image" ? (
          <div className="relative overflow-hidden rounded-2xl">
            <img
              src={message.imageUrl}
              alt="shared"
              className="max-h-72 w-full object-cover"
              draggable={false}
            />
            <AnimatePresence>
              {showBurst && (
                <motion.span
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1.3, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="pointer-events-none absolute inset-0 flex items-center justify-center text-6xl drop-shadow-lg"
                >
                  ❤️
                </motion.span>
              )}
            </AnimatePresence>
          </div>
        ) : (
          <div
            className={`relative rounded-3xl px-4 py-2.5 text-[15px] leading-snug ${
              isMe
                ? "rounded-br-md bg-gradient-to-br from-fuchsia-500 via-pink-500 to-orange-400 text-white"
                : "rounded-bl-md bg-gray-100 text-gray-900"
            }`}
          >
            {message.text}
            <AnimatePresence>
              {showBurst && (
                <motion.span
                  initial={{ scale: 0, opacity: 0, y: 0 }}
                  animate={{ scale: 1.6, opacity: 1, y: -30 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.6 }}
                  className="pointer-events-none absolute -top-2 right-0 text-3xl"
                >
                  ❤️
                </motion.span>
              )}
            </AnimatePresence>
          </div>
        )}

        {message.type === "image" && message.text && (
          <p className={`mt-1 text-[13px] ${isMe ? "text-right" : "text-left"} text-gray-600`}>
            {message.text}
          </p>
        )}

        {message.reaction && (
          <div
            className={`absolute -bottom-3 ${
              isMe ? "left-1" : "right-1"
            } flex h-6 w-6 items-center justify-center rounded-full bg-white text-xs shadow ring-1 ring-gray-200`}
          >
            {message.reaction}
          </div>
        )}
      </motion.div>

      <div className={`mt-1.5 flex items-center gap-1 px-1 text-[11px] text-gray-400`}>
        <span>{message.time}</span>
        {isMe && message.status === "seen" && (
          <span className="flex items-center gap-0.5 text-sky-500">
            <CheckCheck size={13} /> Seen
          </span>
        )}
        {isMe && message.status === "delivered" && (
          <span className="flex items-center gap-0.5 text-gray-400">
            <Check size={13} /> Sent
          </span>
        )}
      </div>
    </div>
  );
}
