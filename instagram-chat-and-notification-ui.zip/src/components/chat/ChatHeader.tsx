import { ChevronLeft, Phone, Video, Bell } from "lucide-react";
import Avatar from "../Avatar";

interface ChatHeaderProps {
  name: string;
  avatar: string;
  isActive: boolean;
  onBack: () => void;
  onBellClick: () => void;
  hasUnread: boolean;
}

export default function ChatHeader({
  name,
  avatar,
  isActive,
  onBack,
  onBellClick,
  hasUnread,
}: ChatHeaderProps) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-gray-200 bg-white/95 px-3 py-2.5 backdrop-blur-sm">
      <div className="flex min-w-0 items-center gap-2">
        <button
          onClick={onBack}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Back"
        >
          <ChevronLeft size={24} />
        </button>
        <Avatar src={avatar} isActive={isActive} size={38} />
        <div className="min-w-0 leading-tight">
          <p className="truncate text-[15px] font-semibold text-gray-900">{name}</p>
          <p className="truncate text-xs text-gray-500">
            {isActive ? "Active now" : "Offline"}
          </p>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-1">
        <button
          className="flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Audio call"
        >
          <Phone size={21} />
        </button>
        <button
          className="flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Video call"
        >
          <Video size={22} />
        </button>
        <button
          onClick={onBellClick}
          className="relative flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Notifications"
        >
          <Bell size={21} />
          {hasUnread && (
            <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
          )}
        </button>
      </div>
    </div>
  );
}
