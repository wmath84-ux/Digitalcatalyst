import { useEffect, useRef } from "react";
import { AnimatePresence } from "framer-motion";
import type { ChatMessage } from "../../data/chatData";
import MessageBubble from "./MessageBubble";
import TypingIndicator from "./TypingIndicator";

interface MessageListProps {
  messages: ChatMessage[];
  isTyping: boolean;
  onReact: (id: string, reaction: string) => void;
}

export default function MessageList({ messages, isTyping, onReact }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  return (
    <div className="scrollbar-none flex-1 overflow-y-auto py-4 [&::-webkit-scrollbar]:hidden">
      <div className="flex flex-col gap-4">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <MessageBubble key={m.id} message={m} onReact={onReact} />
          ))}
          {isTyping && <TypingIndicator key="typing" />}
        </AnimatePresence>
      </div>
      <div ref={bottomRef} />
    </div>
  );
}
