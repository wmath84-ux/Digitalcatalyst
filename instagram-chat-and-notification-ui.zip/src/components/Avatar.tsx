interface AvatarProps {
  src?: string;
  initials?: string;
  colorClass?: string;
  size?: number;
  isActive?: boolean;
  className?: string;
}

export default function Avatar({
  src,
  initials,
  colorClass = "bg-indigo-500",
  size = 40,
  isActive,
  className = "",
}: AvatarProps) {
  const dim = { width: size, height: size };
  return (
    <div className={`relative shrink-0 ${className}`} style={dim}>
      {src ? (
        <img
          src={src}
          alt={initials ?? "avatar"}
          className="h-full w-full rounded-full object-cover"
          style={dim}
        />
      ) : (
        <div
          className={`flex h-full w-full items-center justify-center rounded-full ${colorClass} text-white font-semibold`}
          style={{ ...dim, fontSize: size * 0.38 }}
        >
          {initials}
        </div>
      )}
      {isActive && (
        <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full border-2 border-white bg-green-500" />
      )}
    </div>
  );
}
