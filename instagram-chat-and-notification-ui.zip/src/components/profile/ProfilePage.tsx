import { useState } from "react";
import ProfileHeader from "./ProfileHeader";
import ProfileInfo from "./ProfileInfo";
import StoryHighlights from "./StoryHighlights";
import ProfileTabs from "./ProfileTabs";
import ProfileGrid from "./ProfileGrid";
import { profileData } from "../../data/profileData";

interface ProfilePageProps {
  onBack?: () => void;
}

export default function ProfilePage({ onBack }: ProfilePageProps) {
  const [activeTab, setActiveTab] = useState<"posts" | "reels" | "saved" | "tagged">("posts");

  const displayedPosts =
    activeTab === "reels"
      ? profileData.posts.filter((p) => p.isReel)
      : activeTab === "saved"
      ? []
      : activeTab === "tagged"
      ? []
      : profileData.posts;

  return (
    <div className="flex h-full flex-col bg-white">
      <ProfileHeader username={profileData.username} onBack={onBack} />

      <div className="scrollbar-none flex-1 overflow-y-auto">
        <ProfileInfo
          username={profileData.username}
          fullName={profileData.fullName}
          avatar={profileData.avatar}
          bio={profileData.bio}
          link={profileData.link}
          stats={profileData.stats}
        />

        <StoryHighlights highlights={profileData.highlights} />

        <ProfileTabs active={activeTab} onChange={setActiveTab} />

        {displayedPosts.length > 0 ? (
          <ProfileGrid posts={displayedPosts} />
        ) : (
          <EmptyState tab={activeTab} />
        )}
      </div>
    </div>
  );
}

function EmptyState({ tab }: { tab: "posts" | "reels" | "saved" | "tagged" }) {
  const messages: Record<"posts" | "reels" | "saved" | "tagged", { icon: string; title: string; subtitle: string }> = {
    posts: { icon: "📸", title: "No posts yet", subtitle: "Share your first photo or video" },
    reels: { icon: "🎬", title: "No reels yet", subtitle: "Start creating and sharing short videos" },
    saved: { icon: "🔖", title: "Save", subtitle: "Save photos and videos you want to see again" },
    tagged: { icon: "👤", title: "Photos of you", subtitle: "When people tag you in photos, they'll appear here" },
  };

  const m = messages[tab];
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-8 py-16 text-center text-gray-500">
      <span className="rounded-full bg-gray-100 p-4 text-3xl">{m.icon}</span>
      <p className="text-base font-semibold text-gray-900">{m.title}</p>
      <p className="text-sm text-gray-500">{m.subtitle}</p>
    </div>
  );
}
