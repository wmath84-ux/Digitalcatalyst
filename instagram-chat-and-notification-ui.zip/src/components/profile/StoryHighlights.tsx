import { motion } from "framer-motion";
import type { StoryHighlight } from "../../data/profileData";

interface StoryHighlightsProps {
  highlights: StoryHighlight[];
}

export default function StoryHighlights({ highlights }: StoryHighlightsProps) {
  return (
    <div className="scrollbar-none mt-4 border-b border-gray-100 pb-3">
      <div className="flex gap-4 overflow-x-auto px-4">
        {highlights.map((h, i) => (
          <motion.button
            key={h.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
            className="flex shrink-0 flex-col items-center gap-1.5"
          >
            <div
              className={`flex h-[62px] w-[62px] items-center justify-center rounded-full bg-gradient-to-br ${h.gradient} p-[2px] shadow-sm`}
            >
              <div className="flex h-full w-full items-center justify-center rounded-full bg-white">
                <span className="text-2xl">{h.icon}</span>
              </div>
            </div>
            <span className="w-[68px] truncate text-center text-[11px] text-gray-700">
              {h.title}
            </span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
