import { ChevronDown, Plus, Menu, ChevronLeft } from "lucide-react";

interface ProfileHeaderProps {
  username: string;
  onBack?: () => void;
}

export default function ProfileHeader({ username, onBack }: ProfileHeaderProps) {
  return (
    <div className="flex items-center justify-between border-b border-gray-100 bg-white px-3 py-2">
      <div className="flex items-center gap-1">
        {onBack && (
          <button
            onClick={onBack}
            className="mr-0.5 flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
            aria-label="Back"
          >
            <ChevronLeft size={24} />
          </button>
        )}
        <span className="text-lg font-bold text-gray-900">
          {username}
        </span>
        <ChevronDown size={18} className="mt-0.5 text-gray-900" />
      </div>
      <div className="flex items-center gap-1">
        <button
          className="flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Add"
        >
          <Plus size={26} strokeWidth={2.2} />
        </button>
        <button
          className="flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Menu"
        >
          <Menu size={24} />
        </button>
      </div>
    </div>
  );
}
