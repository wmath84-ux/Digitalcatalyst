import { motion } from "framer-motion";
import { Grid3X3, Clapperboard, Bookmark, UserSquare } from "lucide-react";

interface ProfileTabsProps {
  active: "posts" | "reels" | "saved" | "tagged";
  onChange: (tab: "posts" | "reels" | "saved" | "tagged") => void;
}

export default function ProfileTabs({ active, onChange }: ProfileTabsProps) {
  const tabs: { key: "posts" | "reels" | "saved" | "tagged"; icon: React.ReactNode }[] = [
    { key: "posts", icon: <Grid3X3 size={22} /> },
    { key: "reels", icon: <Clapperboard size={22} /> },
    { key: "saved", icon: <Bookmark size={22} /> },
    { key: "tagged", icon: <UserSquare size={22} /> },
  ];

  return (
    <div className="flex border-b border-gray-200">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => onChange(tab.key)}
          className={`relative flex flex-1 items-center justify-center py-2.5 transition-colors ${
            active === tab.key ? "text-gray-900" : "text-gray-400"
          }`}
        >
          {tab.icon}
          {active === tab.key && (
            <motion.div
              layoutId="profile-tab-line"
              className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-gray-900"
              transition={{ type: "tween", duration: 0.25 }}
            />
          )}
        </button>
      ))}
    </div>
  );
}
