import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Layers, Film } from "lucide-react";
import type { ProfilePost } from "../../data/profileData";

interface ProfileGridProps {
  posts: ProfilePost[];
}

export default function ProfileGrid({ posts }: ProfileGridProps) {
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <div className="grid grid-cols-3 gap-[2px] bg-white">
      {posts.map((post, i) => (
        <motion.div
          key={post.id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.02 }}
          onMouseEnter={() => setHovered(post.id)}
          onMouseLeave={() => setHovered(null)}
          className="relative aspect-square cursor-pointer overflow-hidden bg-gray-100"
        >
          {post.imageUrl ? (
            <img
              src={post.imageUrl}
              alt="post"
              className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
            />
          ) : (
            <div className={`h-full w-full bg-gradient-to-br ${post.gradient}`} />
          )}

          {/* Badges */}
          {post.hasMultiple && (
            <div className="absolute right-2 top-2 text-white drop-shadow-md">
              <Layers size={18} fill="white" />
            </div>
          )}
          {post.isReel && (
            <div className="absolute right-2 top-2 text-white drop-shadow-md">
              <Film size={18} />
            </div>
          )}

          {/* Hover overlay */}
          <AnimatePresence>
            {hovered === post.id && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center gap-5 bg-black/40 text-white"
              >
                <div className="flex items-center gap-1.5 font-semibold">
                  <Heart size={18} fill="white" />
                  <span className="text-sm">{formatNumber(post.likes)}</span>
                </div>
                <div className="flex items-center gap-1.5 font-semibold">
                  <MessageCircle size={18} fill="white" />
                  <span className="text-sm">{formatNumber(post.comments)}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      ))}
    </div>
  );
}

function formatNumber(num: number): string {
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (num >= 1_000) return (num / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return num.toString();
}
