import { Link as LinkIcon } from "lucide-react";

interface ProfileInfoProps {
  username: string;
  fullName: string;
  avatar: string;
  bio: string;
  link: string;
  stats: {
    posts: number;
    followers: number;
    following: number;
  };
}

function formatNumber(num: number): string {
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (num >= 1_000) return (num / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return num.toString();
}

export default function ProfileInfo({
  username,
  fullName,
  avatar,
  bio,
  link,
  stats,
}: ProfileInfoProps) {
  return (
    <div className="px-4 pt-4">
      {/* Avatar + Stats row */}
      <div className="flex items-center gap-7">
        <div className="shrink-0">
          <div className="h-[82px] w-[82px] overflow-hidden rounded-full border border-gray-200 bg-white p-[1.5px]">
            <img src={avatar} alt={username} className="h-full w-full rounded-full object-cover" />
          </div>
        </div>
        <div className="flex flex-1 justify-between pr-1">
          <StatItem value={stats.posts} label="Posts" />
          <StatItem value={stats.followers} label="Followers" />
          <StatItem value={stats.following} label="Following" />
        </div>
      </div>

      {/* Name + Bio */}
      <div className="mt-3">
        <p className="text-[15px] font-semibold text-gray-900">{fullName}</p>
        <p className="mt-0.5 whitespace-pre-line text-[14px] leading-snug text-gray-900">
          {bio}
        </p>
        <a
          href="#"
          className="mt-1 flex items-center gap-1 text-[13px] font-semibold text-sky-700 active:opacity-60"
        >
          <LinkIcon size={13} />
          {link}
        </a>
      </div>

      {/* Action buttons */}
      <div className="mt-3.5 flex gap-2">
        <button className="flex-1 rounded-lg bg-gray-100 px-4 py-1.5 text-[13px] font-semibold text-gray-900 active:bg-gray-200">
          Edit profile
        </button>
        <button className="flex-1 rounded-lg bg-gray-100 px-4 py-1.5 text-[13px] font-semibold text-gray-900 active:bg-gray-200">
          Share profile
        </button>
        <button
          className="flex shrink-0 items-center justify-center rounded-lg bg-gray-100 px-3 py-1.5 text-gray-900 active:bg-gray-200"
          aria-label="Discover people"
        >
          <UserPlusIcon />
        </button>
      </div>
    </div>
  );
}

function StatItem({ value, label }: { value: number; label: string }) {
  return (
    <button className="flex flex-col items-center">
      <span className="text-[16px] font-bold leading-tight text-gray-900">{formatNumber(value)}</span>
      <span className="text-[13px] leading-tight text-gray-700">{label}</span>
    </button>
  );
}

function UserPlusIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="8.5" cy="7" r="4" />
      <line x1="20" y1="8" x2="20" y2="14" />
      <line x1="23" y1="11" x2="17" y2="11" />
    </svg>
  );
}
