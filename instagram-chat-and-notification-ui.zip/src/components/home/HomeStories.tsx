import { motion } from "framer-motion";
import { myProfile } from "../../data/conversationsData";
import type { Conversation } from "../../data/conversationsData";

interface HomeStoriesProps {
  storiedConvos: Conversation[];
}

export default function HomeStories({ storiedConvos }: HomeStoriesProps) {
  return (
    <div className="scrollbar-none border-b border-gray-200 bg-white py-3">
      <div className="flex gap-2 overflow-x-auto px-3">
        {/* Your Story */}
        <div className="flex shrink-0 flex-col items-center gap-1.5 px-0.5">
          <div className="relative">
            <div className="rounded-full bg-gradient-to-br from-amber-400 via-pink-500 to-purple-600 p-[2.5px]">
              <div className="rounded-full bg-white p-[2px]">
                <img
                  src={myProfile.avatar}
                  alt="Your story"
                  className="h-16 w-16 rounded-full object-cover opacity-70"
                />
              </div>
            </div>
            <span className="absolute -bottom-1 right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-blue-500 text-white ring-[2.5px] ring-white text-[11px] font-bold leading-none">
              +
            </span>
          </div>
          <span className="w-[72px] truncate text-center text-[11px] text-gray-700">
            Your story
          </span>
        </div>

        {storiedConvos.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, x: 8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex shrink-0 flex-col items-center gap-1.5 px-0.5"
          >
            <div
              className={`rounded-full bg-gradient-to-br ${
                c.storyRingColor || "from-amber-400 via-pink-500 to-purple-600"
              } p-[2.5px]`}
            >
              <div className="rounded-full bg-white p-[2px]">
                <img
                  src={c.avatar}
                  alt={c.username}
                  className="h-16 w-16 rounded-full object-cover"
                />
              </div>
            </div>
            <span className="w-[72px] truncate text-center text-[11px] text-gray-700">
              {c.username.split(".")[0]}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
