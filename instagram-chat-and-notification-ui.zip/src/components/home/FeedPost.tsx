import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Play,
} from "lucide-react";
import type { FeedPostData } from "../../data/feedData";

interface FeedPostProps {
  post: FeedPostData;
  index: number;
}

function formatLikes(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return n.toString();
}

export default function FeedPost({ post, index }: FeedPostProps) {
  const [liked, setLiked] = useState(post.liked);
  const [saved, setSaved] = useState(post.saved);
  const [likes, setLikes] = useState(post.likes);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [currentImage, setCurrentImage] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const lastTap = useState({ current: 0 })[0];

  const handleDoubleTap = () => {
    const now = Date.now();
    if (now - lastTap.current < 350) {
      if (!liked) {
        setLiked(true);
        setLikes((p) => p + 1);
        setShowHeartBurst(true);
        setTimeout(() => setShowHeartBurst(false), 800);
      }
    }
    lastTap.current = now;
  };

  const toggleLike = () => {
    if (liked) {
      setLiked(false);
      setLikes((p) => p - 1);
    } else {
      setLiked(true);
      setLikes((p) => p + 1);
      setShowHeartBurst(true);
      setTimeout(() => setShowHeartBurst(false), 500);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06, duration: 0.35, ease: "easeOut" }}
      className="border-b border-gray-200"
    >
      {/* Post Header */}
      <div className="flex items-center justify-between px-3 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <img
            src={post.avatar}
            alt={post.username}
            className="h-9 w-9 rounded-full object-cover ring-2 ring-amber-400/60"
          />
          <div className="min-w-0">
            <p className="truncate text-[13px] font-semibold text-gray-900 pr-1">
              {post.username}
            </p>
            {post.location && (
              <p className="flex items-center gap-0.5 text-[11px] text-gray-500">
                <MapPin size={10} /> {post.location}
              </p>
            )}
          </div>
        </div>
        <button className="flex h-9 w-9 items-center justify-center rounded-full text-gray-900 active:bg-gray-100">
          <MoreHorizontal size={20} />
        </button>
      </div>

      {/* Post Image / Carousel */}
      <div
        className="relative select-none bg-gray-100"
        onClick={handleDoubleTap}
      >
        <div className="relative aspect-square overflow-hidden">
          {post.images[currentImage].url ? (
            <img
              src={post.images[currentImage].url}
              alt={`Post by ${post.username}`}
              className="h-full w-full object-cover"
              draggable={false}
            />
          ) : (
            <div
              className={`h-full w-full bg-gradient-to-br ${post.images[currentImage].gradient} flex items-center justify-center`}
            >
              {post.isReel && (
                <div className="flex items-center gap-2 rounded-full bg-black/50 px-4 py-2 text-white backdrop-blur-sm">
                  <Play size={18} fill="white" /> <span className="text-sm font-semibold">Reel</span>
                </div>
              )}
            </div>
          )}

          {/* Double-tap heart animation */}
          <AnimatePresence>
            {showHeartBurst && (
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.5, opacity: 0 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center"
              >
                <Heart size={96} className="text-white drop-shadow-lg" fill="white" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Multi-image arrows */}
          {post.images.length > 1 && (
            <>
              {currentImage > 0 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentImage((p) => p - 1);
                  }}
                  className="absolute left-2 top-1/2 z-10 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-white/80 shadow active:bg-white"
                >
                  <ChevronLeft size={18} />
                </button>
              )}
              {currentImage < post.images.length - 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentImage((p) => p + 1);
                  }}
                  className="absolute right-2 top-1/2 z-10 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-white/80 shadow active:bg-white"
                >
                  <ChevronRight size={18} />
                </button>
              )}
              {/* Dots */}
              <div className="absolute bottom-3 left-0 right-0 z-10 flex justify-center gap-1">
                {post.images.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 rounded-full transition-all ${
                      i === currentImage ? "w-5 bg-blue-500" : "w-1.5 bg-white/70"
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex items-center justify-between px-1 py-1.5">
        <div className="flex items-center gap-1">
          <motion.button
            whileTap={{ scale: 1.3 }}
            onClick={toggleLike}
            className="flex h-10 w-10 items-center justify-center"
            aria-label="Like"
          >
            <Heart
              size={24}
              className={liked ? "text-red-500" : "text-gray-900"}
              fill={liked ? "#ef4444" : "none"}
            />
          </motion.button>
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex h-10 w-10 items-center justify-center"
            aria-label="Comment"
          >
            <MessageCircle size={24} className="text-gray-900" />
          </button>
          <button
            className="flex h-10 w-10 items-center justify-center"
            aria-label="Share"
          >
            <Send size={23} className="text-gray-900" />
          </button>
        </div>
        <motion.button
          whileTap={{ scale: 1.2 }}
          onClick={() => setSaved(!saved)}
          className="flex h-10 w-10 items-center justify-center"
          aria-label="Save"
        >
          <Bookmark
            size={24}
            className={saved ? "text-gray-900" : "text-gray-900"}
            fill={saved ? "currentColor" : "none"}
          />
        </motion.button>
      </div>

      {/* Likes */}
      {likes > 0 && (
        <div className="px-3 pb-1">
          <p className="text-[13px] font-semibold text-gray-900">{formatLikes(likes)} likes</p>
        </div>
      )}

      {/* Caption */}
      <div className="px-3 pb-1">
        <p className="text-[13px] leading-snug text-gray-900">
          <span className="font-semibold">{post.username}</span>{" "}
          {post.caption}
        </p>
      </div>

      {/* Comments */}
      {post.comments.length > 0 && (
        <div className="px-3 pb-1">
          {!showComments ? (
            <button
              onClick={() => setShowComments(true)}
              className="text-[13px] text-gray-500"
            >
              View all {post.comments.length} comments
            </button>
          ) : (
            <div className="space-y-0.5">
              {post.comments.map((c) => (
                <p key={c.id} className="text-[13px] leading-snug text-gray-900">
                  <span className="font-semibold">{c.username}</span>{" "}
                  {c.text}
                </p>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Timestamp */}
      <div className="px-3 pb-3 pt-0.5">
        <span className="text-[11px] uppercase text-gray-400 tracking-wide">{post.time}</span>
      </div>
    </motion.div>
  );
}
