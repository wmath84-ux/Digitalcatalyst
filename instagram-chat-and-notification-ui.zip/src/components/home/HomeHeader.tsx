import { Camera, Heart, MessageCircle } from "lucide-react";

interface HomeHeaderProps {
  onBellClick: () => void;
  onInboxClick: () => void;
  hasUnread: boolean;
  inboxUnread: number;
}

export default function HomeHeader({
  onBellClick,
  onInboxClick,
  hasUnread,
  inboxUnread,
}: HomeHeaderProps) {
  return (
    <div className="flex items-center justify-between border-b border-gray-100 bg-white px-4 py-2.5">
      {/* Instagram wordmark */}
      <div className="flex items-center gap-3">
        <svg
          viewBox="0 0 24 24"
          className="h-7 w-7 text-gray-900"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
          <circle cx="12" cy="12" r="5" />
          <circle cx="17.5" cy="6.5" r="1.5" fill="currentColor" stroke="none" />
        </svg>
        <span className="text-xl font-bold tracking-tight text-gray-900">
          Instagram
        </span>
      </div>

      <div className="flex items-center gap-1">
        <button
          className="flex h-10 w-10 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="New post"
        >
          <Camera size={23} />
        </button>
        <button
          onClick={onBellClick}
          className="relative flex h-10 w-10 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Notifications"
        >
          <Heart size={24} />
          {hasUnread && (
            <span className="absolute right-2 top-2.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
          )}
        </button>
        <button
          onClick={onInboxClick}
          className="relative flex h-10 w-10 items-center justify-center rounded-full text-gray-900 active:bg-gray-100"
          aria-label="Messages"
        >
          <MessageCircle size={24} />
          {inboxUnread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white leading-none">
              {inboxUnread}
            </span>
          )}
        </button>
      </div>
    </div>
  );
}
