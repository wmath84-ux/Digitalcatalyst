import { Home, Search, Film, MessageCircle, PlusSquare } from "lucide-react";
import HomeHeader from "./HomeHeader";
import HomeStories from "./HomeStories";
import FeedPost from "./FeedPost";
import { feedPosts } from "../../data/feedData";
import { myProfile } from "../../data/conversationsData";
import type { Conversation } from "../../data/conversationsData";

interface HomePageProps {
  onBellClick: () => void;
  onInboxClick: () => void;
  onProfileClick: () => void;
  hasUnread: boolean;
  conversations: Conversation[];
}

export default function HomePage({
  onBellClick,
  onInboxClick,
  onProfileClick,
  hasUnread,
  conversations: convos,
}: HomePageProps) {
  const storiedConvos = convos.filter((c) => c.hasStory);
  const totalInboxUnread = convos.reduce((sum, c) => sum + c.unreadCount, 0);

  return (
    <div className="flex h-full flex-col bg-white">
      <HomeHeader
        onBellClick={onBellClick}
        onInboxClick={onInboxClick}
        hasUnread={hasUnread}
        inboxUnread={totalInboxUnread}
      />

      <HomeStories storiedConvos={storiedConvos} />

      {/* Feed */}
      <div className="scrollbar-none flex-1 overflow-y-auto bg-gray-50">
        {feedPosts.map((post, i) => (
          <FeedPost key={post.id} post={post} index={i} />
        ))}
        <div className="py-8 text-center text-[13px] text-gray-400">
          — You're all caught up —
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="flex items-center justify-around border-t border-gray-200 bg-white px-2 pb-1.5 pt-2">
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <Home size={24} className="text-gray-900" fill="currentColor" />
        </button>
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <Search size={24} className="text-gray-500" />
        </button>
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <PlusSquare size={24} className="text-gray-500" />
        </button>
        <button className="flex flex-col items-center gap-0.5 px-3 py-1">
          <Film size={24} className="text-gray-500" />
        </button>
        <button
          onClick={onInboxClick}
          className="relative flex flex-col items-center gap-0.5 px-3 py-1"
        >
          <MessageCircle size={24} className="text-gray-500" />
          {totalInboxUnread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white leading-none">
              {totalInboxUnread}
            </span>
          )}
        </button>
        <button
          onClick={onProfileClick}
          className="flex flex-col items-center gap-0.5 px-3 py-1"
        >
          <div className="h-7 w-7 overflow-hidden rounded-full ring-1 ring-gray-300">
            <img src={myProfile.avatar} alt="Profile" className="h-full w-full object-cover" />
          </div>
        </button>
      </div>
    </div>
  );
}
