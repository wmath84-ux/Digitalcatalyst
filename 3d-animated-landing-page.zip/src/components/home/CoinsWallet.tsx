"use client";

import { useState } from "react";
import { motion } from "framer-motion";

interface CoinsWalletProps {
  coins: number;
  onClaim: () => Promise<{ ok: boolean; message: string }>;
}

export default function CoinsWallet({ coins, onClaim }: CoinsWalletProps) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const claim = async () => {
    setLoading(true);
    const result = await onClaim();
    setMessage(result.message);
    setLoading(false);
    setTimeout(() => setMessage(null), 4000);
  };

  return (
    <div className="glass-panel relative overflow-hidden rounded-3xl p-7">
      <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-amber-400/20 blur-3xl" />
      <p className="text-xs font-bold uppercase tracking-[0.2em] text-amber-300">EduCoin Wallet</p>
      <div className="mt-3 flex items-end gap-2">
        <span className="text-5xl font-black text-white">🪙 {coins}</span>
      </div>
      <p className="mt-2 text-sm text-slate-400">
        Earn EduCoins daily and spend them across the marketplace to unlock premium content.
      </p>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.97 }}
        onClick={claim}
        disabled={loading}
        className="pulse-glow mt-6 w-full rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-3 text-sm font-bold text-slate-950 transition disabled:opacity-60"
      >
        {loading ? "Claiming…" : "🎁 Claim +50 Daily EduCoins"}
      </motion.button>

      {message && (
        <div className="mt-3 rounded-xl border border-amber-400/30 bg-amber-400/10 px-4 py-2.5 text-xs text-amber-200">
          {message}
        </div>
      )}
    </div>
  );
}
