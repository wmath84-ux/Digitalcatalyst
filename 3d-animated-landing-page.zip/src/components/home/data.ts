export interface MarketItem {
  id: string;
  title: string;
  description: string;
  price: number;
  type: "pdf" | "video";
  tag: string;
  meta: string;
  emoji: string;
}

export const libraryItems: MarketItem[] = [
  {
    id: "pdf-physics-12",
    title: "Complete Physics Notes — Class 12",
    description: "Chapter-wise handwritten notes with solved numericals and diagrams.",
    price: 0,
    type: "pdf",
    tag: "Free",
    meta: "182 pages",
    emoji: "📘",
  },
  {
    id: "pdf-organic-chem",
    title: "Organic Chemistry Handbook",
    description: "Reaction mechanisms, named reactions, and quick-revision flowcharts.",
    price: 120,
    type: "pdf",
    tag: "Premium",
    meta: "96 pages",
    emoji: "🧪",
  },
  {
    id: "pdf-dsa-cheat",
    title: "Data Structures & Algorithms Cheat Sheet",
    description: "Time complexities, patterns, and interview-ready code snippets.",
    price: 80,
    type: "pdf",
    tag: "Premium",
    meta: "64 pages",
    emoji: "🧮",
  },
  {
    id: "pdf-fullstack-ebook",
    title: "Full-Stack Web Dev E-Book",
    description: "From HTML basics to deploying production-grade Next.js apps.",
    price: 200,
    type: "pdf",
    tag: "Bestseller",
    meta: "310 pages",
    emoji: "💻",
  },
  {
    id: "pdf-formula-bank",
    title: "Competitive Exam Formula Bank",
    description: "Every formula you need for maths & physics competitive exams.",
    price: 60,
    type: "pdf",
    tag: "Premium",
    meta: "48 pages",
    emoji: "📐",
  },
  {
    id: "pdf-english-grammar",
    title: "English Grammar Mastery",
    description: "Rules, exercises, and common mistakes — explained simply.",
    price: 0,
    type: "pdf",
    tag: "Free",
    meta: "72 pages",
    emoji: "📗",
  },
];

export const videoLectures: MarketItem[] = [
  {
    id: "vid-react-master",
    title: "React.js Masterclass",
    description: "Build production-ready UIs with hooks, context, and performance patterns.",
    price: 250,
    type: "video",
    tag: "Bestseller",
    meta: "8h 20m",
    emoji: "⚛️",
  },
  {
    id: "vid-calculus-30",
    title: "Calculus in 30 Days",
    description: "Limits to integrals — an intuitive, visual walkthrough for exam prep.",
    price: 150,
    type: "video",
    tag: "Premium",
    meta: "12h 05m",
    emoji: "📈",
  },
  {
    id: "vid-digital-marketing",
    title: "Digital Marketing Bootcamp",
    description: "SEO, paid ads, and funnels — go from zero to campaign-ready.",
    price: 180,
    type: "video",
    tag: "Premium",
    meta: "6h 40m",
    emoji: "📣",
  },
  {
    id: "vid-python-beginners",
    title: "Python for Beginners",
    description: "Your first steps into programming with hands-on mini projects.",
    price: 0,
    type: "video",
    tag: "Free",
    meta: "5h 10m",
    emoji: "🐍",
  },
  {
    id: "vid-public-speaking",
    title: "Public Speaking Confidence",
    description: "Overcome stage fear and deliver presentations that captivate.",
    price: 90,
    type: "video",
    tag: "Premium",
    meta: "3h 15m",
    emoji: "🎤",
  },
  {
    id: "vid-uiux-sprint",
    title: "UI/UX Design Sprint",
    description: "Design, prototype, and test a product in one intensive week.",
    price: 210,
    type: "video",
    tag: "Premium",
    meta: "9h 00m",
    emoji: "🎨",
  },
];
