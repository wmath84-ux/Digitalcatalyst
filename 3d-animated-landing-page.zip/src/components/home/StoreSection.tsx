"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import type { MarketItem } from "./data";

interface StoreSectionProps {
  title: string;
  subtitle: string;
  icon: string;
  items: MarketItem[];
  ownedIds: Set<string>;
  coins: number;
  onPurchase: (item: MarketItem) => Promise<{ ok: boolean; message?: string }>;
}

export default function StoreSection({
  title,
  subtitle,
  icon,
  items,
  ownedIds,
  coins,
  onPurchase,
}: StoreSectionProps) {
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const handleBuy = async (item: MarketItem) => {
    setPendingId(item.id);
    const result = await onPurchase(item);
    setPendingId(null);
    if (result.message) {
      setToast(result.message);
      setTimeout(() => setToast(null), 3200);
    }
  };

  return (
    <section className="relative">
      <div className="mb-6 flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/5 text-2xl">
          {icon}
        </span>
        <div>
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <p className="text-sm text-slate-400">{subtitle}</p>
        </div>
      </div>

      {toast && (
        <div className="mb-4 rounded-xl border border-violet-400/30 bg-violet-500/10 px-4 py-2.5 text-sm text-violet-200">
          {toast}
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => {
          const owned = item.price === 0 || ownedIds.has(item.id);
          const canAfford = coins >= item.price;
          return (
            <motion.div
              key={item.id}
              whileHover={{ y: -6 }}
              className="glass-panel flex flex-col justify-between rounded-2xl p-5"
            >
              <div>
                <div className="flex items-start justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-white/5 text-2xl">
                    {item.emoji}
                  </span>
                  <span
                    className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${
                      item.tag === "Free"
                        ? "bg-emerald-400/15 text-emerald-300"
                        : item.tag === "Bestseller"
                          ? "bg-amber-400/15 text-amber-300"
                          : "bg-fuchsia-400/15 text-fuchsia-300"
                    }`}
                  >
                    {item.tag}
                  </span>
                </div>
                <h3 className="mt-4 text-base font-bold text-white">{item.title}</h3>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">{item.description}</p>
                <p className="mt-3 text-[11px] uppercase tracking-wide text-slate-500">{item.meta}</p>
              </div>

              <div className="mt-5 flex items-center justify-between">
                <span className="text-sm font-bold text-amber-300">
                  {item.price === 0 ? "Free" : `🪙 ${item.price}`}
                </span>
                {owned ? (
                  <span className="rounded-xl bg-emerald-400/15 px-4 py-2 text-xs font-bold text-emerald-300">
                    ✓ {item.type === "pdf" ? "Open" : "Watch"}
                  </span>
                ) : (
                  <button
                    onClick={() => handleBuy(item)}
                    disabled={pendingId === item.id || !canAfford}
                    className="rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-2 text-xs font-bold text-white transition disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {pendingId === item.id
                      ? "Unlocking…"
                      : canAfford
                        ? "Unlock"
                        : "Not enough coins"}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
