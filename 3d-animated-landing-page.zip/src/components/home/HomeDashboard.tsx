"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import StoreSection from "./StoreSection";
import CoinsWallet from "./CoinsWallet";
import ApkCard from "./ApkCard";
import AiMentorChat from "./AiMentorChat";
import { libraryItems, videoLectures, type MarketItem } from "./data";

export default function HomeDashboard({
  initialName,
  initialCoins,
}: {
  initialName: string;
  initialCoins: number;
}) {
  const { user, setUser, logout } = useAuth();
  const router = useRouter();
  const [ownedIds, setOwnedIds] = useState<Set<string>>(new Set());

  const name = user?.name ?? initialName;
  const coins = user?.coins ?? initialCoins;

  useEffect(() => {
    fetch("/api/store/purchases")
      .then((res) => res.json())
      .then((data) => {
        const ids = new Set<string>(
          (data.purchases ?? []).map((p: { itemId: string }) => p.itemId),
        );
        setOwnedIds(ids);
      })
      .catch(() => {});
  }, []);

  const handleLogout = async () => {
    await logout();
    router.push("/");
  };

  const handlePurchase = async (item: MarketItem) => {
    try {
      const res = await fetch("/api/store/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId: item.id,
          itemName: item.title,
          itemType: item.type,
          price: item.price,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        return { ok: false, message: data.error ?? "Purchase failed." };
      }

      setOwnedIds((prev) => new Set(prev).add(item.id));
      if (user) setUser({ ...user, coins: data.coins });

      return { ok: true, message: `🎉 Unlocked "${item.title}"!` };
    } catch {
      return { ok: false, message: "Network error. Please try again." };
    }
  };

  const handleClaim = async () => {
    try {
      const res = await fetch("/api/coins/earn", { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        return { ok: false, message: data.error ?? "Unable to claim right now." };
      }

      if (user) setUser({ ...user, coins: data.coins });
      return { ok: true, message: `✨ You claimed +${data.claimed} EduCoins!` };
    } catch {
      return { ok: false, message: "Network error. Please try again." };
    }
  };

  return (
    <div className="min-h-screen bg-[#05060f]">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#05060f]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 sm:px-8">
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-lg font-black text-white">
              E
            </span>
            <span className="text-lg font-bold text-white">Eduvora Dashboard</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1 rounded-xl bg-white/5 px-3 py-2 text-xs font-semibold text-amber-300 sm:flex">
              🪙 {coins}
            </span>
            <button
              onClick={handleLogout}
              className="rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white transition hover:bg-white/10"
            >
              Log Out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-16 px-6 py-10 sm:px-8">
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-sm text-slate-400">Welcome back,</p>
          <h1 className="text-3xl font-black text-white sm:text-4xl">
            {name} <span className="gradient-text">👋</span>
          </h1>
          <p className="mt-2 max-w-xl text-slate-400">
            Your digital catalyst dashboard — libraries, lectures, your AI mentor, and rewards,
            all in one place.
          </p>
        </motion.section>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <CoinsWallet coins={coins} onClaim={handleClaim} />
          <ApkCard />
          <div className="glass-panel rounded-3xl p-7">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-300">
              Seamless E-Commerce
            </p>
            <div className="mt-3 flex items-center gap-3">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-cyan-400/15 text-3xl">
                🛒
              </span>
              <div>
                <h3 className="text-lg font-bold text-white">EduCoin Marketplace</h3>
                <p className="text-xs text-slate-400">Secure · Instant · Simple</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-slate-400">
              Every unlock below is a real checkout — spend EduCoins securely to own PDFs,
              e-books, and video courses instantly.
            </p>
          </div>
        </div>

        <StoreSection
          title="Premium Digital Library"
          subtitle="PDFs, e-books & comprehensive notes"
          icon="📚"
          items={libraryItems}
          ownedIds={ownedIds}
          coins={coins}
          onPurchase={handlePurchase}
        />

        <StoreSection
          title="Interactive Video Lectures"
          subtitle="High-retention courses from expert instructors"
          icon="🎬"
          items={videoLectures}
          ownedIds={ownedIds}
          coins={coins}
          onPurchase={handlePurchase}
        />

        <section>
          <div className="mb-6 flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/5 text-2xl">
              🤖
            </span>
            <div>
              <h2 className="text-xl font-bold text-white">Smart AI Mentor</h2>
              <p className="text-sm text-slate-400">
                24/7 personalized guidance powered by Google Gemini Flash
              </p>
            </div>
          </div>
          <AiMentorChat />
        </section>
      </main>
    </div>
  );
}
