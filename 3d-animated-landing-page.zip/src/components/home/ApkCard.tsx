export default function ApkCard() {
  return (
    <div className="glass-panel relative overflow-hidden rounded-3xl p-7">
      <div className="pointer-events-none absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-emerald-400/20 blur-3xl" />
      <p className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-300">
        Cross-Platform
      </p>
      <div className="mt-3 flex items-center gap-3">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-emerald-400/15 text-3xl">
          📱
        </span>
        <div>
          <h3 className="text-lg font-bold text-white">Eduvora Android App</h3>
          <p className="text-xs text-slate-400">v1.0 · Fast · Offline-friendly</p>
        </div>
      </div>
      <p className="mt-4 text-sm text-slate-400">
        Get the dedicated Android APK for a native, distraction-free learning experience with
        push notifications for new coins and courses.
      </p>
      <a
        href="/downloads/eduvora-app.apk"
        download
        className="pulse-glow mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 py-3 text-sm font-bold text-slate-950 transition hover:brightness-110"
      >
        ⬇️ Download APK
      </a>
    </div>
  );
}
