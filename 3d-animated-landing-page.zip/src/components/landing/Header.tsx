"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

export default function Header() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    await logout();
    router.refresh();
  };

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="fixed inset-x-0 top-0 z-50"
    >
      <div className="glass-panel mx-auto mt-3 flex max-w-7xl items-center justify-between gap-3 rounded-2xl px-4 py-3 sm:mt-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-lg font-black text-white shadow-lg shadow-fuchsia-500/30">
            E
          </span>
          <span className="hidden text-lg font-bold tracking-tight text-white sm:block">
            Eduvora <span className="text-slate-400 font-medium">| Digital Catalyst</span>
          </span>
        </Link>

        <div className="flex flex-1 items-center justify-end gap-2 sm:gap-3">
          <a
            href="/downloads/eduvora-app.apk"
            download
            className="pulse-glow flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 px-3 py-2 text-xs font-bold text-slate-950 shadow-lg shadow-emerald-500/30 transition hover:brightness-110 sm:px-4 sm:text-sm"
          >
            <span aria-hidden>⬇️</span>
            <span className="hidden sm:inline">Download APK</span>
            <span className="sm:hidden">APK</span>
          </a>

          {loading ? (
            <div className="h-9 w-24 animate-pulse rounded-xl bg-white/10" />
          ) : user ? (
            <>
              <span className="hidden items-center gap-1 rounded-xl bg-white/5 px-3 py-2 text-xs font-semibold text-amber-300 md:flex">
                🪙 {user.coins}
              </span>
              <button
                onClick={handleLogout}
                className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/10 sm:px-4 sm:text-sm"
              >
                Log Out
              </button>
            </>
          ) : (
            <>
              <Link
                href="/auth?mode=login"
                className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/10 sm:px-4 sm:text-sm"
              >
                Login
              </Link>
              <Link
                href="/auth?mode=signup"
                className="rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-3 py-2 text-xs font-semibold text-white shadow-lg shadow-violet-500/30 transition hover:brightness-110 sm:px-4 sm:text-sm"
              >
                Sign Up
              </Link>
            </>
          )}
        </div>
      </div>
    </motion.header>
  );
}
