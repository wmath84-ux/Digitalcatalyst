export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#05060f] px-6 py-10 text-slate-500 sm:px-8">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-sm font-black text-white">
            E
          </span>
          <span className="text-sm font-semibold text-slate-300">
            Eduvora <span className="text-slate-500">| Digital Catalyst</span>
          </span>
        </div>
        <p className="text-xs">© {new Date().getFullYear()} Eduvora. All rights reserved.</p>
        <div className="flex gap-4 text-xs">
          <a href="#features" className="hover:text-slate-300">Features</a>
          <a href="/downloads/eduvora-app.apk" download className="hover:text-slate-300">APK</a>
          <a href="/auth" className="hover:text-slate-300">Login</a>
        </div>
      </div>
    </footer>
  );
}
