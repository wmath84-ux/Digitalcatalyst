import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";

const mentorSchema = z.object({
  message: z.string().min(1).max(2000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "model"]),
        content: z.string(),
      }),
    )
    .optional()
    .default([]),
});

const MODEL = "gemini-2.0-flash";

const SYSTEM_PROMPT =
  "You are the Eduvora Smart AI Mentor, an encouraging, sharp, and fast study companion for students on the Eduvora / Digital Catalyst learning platform. " +
  "Give concise, accurate, well-structured answers with examples when helpful. Keep responses focused on studying, exam prep, career guidance, and problem solving. " +
  "Be warm and motivating, and use short paragraphs or bullet points for clarity.";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Please log in to chat with your AI mentor." }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = mentorSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid input" },
      { status: 400 },
    );
  }

  const { message, history } = parsed.data;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return NextResponse.json({
      reply:
        "⚡ AI Mentor is running in demo mode because no GEMINI_API_KEY is configured yet. " +
        `Once an admin adds the key, I'll answer instantly using Google Gemini Flash. For now, here's a quick tip about "${message.slice(0, 120)}": break the topic into smaller concepts, practice with past questions, and review your weak spots daily for 20 minutes.`,
      demo: true,
    });
  }

  try {
    const contents = [
      ...history.slice(-10).map((turn) => ({
        role: turn.role,
        parts: [{ text: turn.content }],
      })),
      { role: "user", parts: [{ text: message }] },
    ];

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        }),
      },
    );

    if (!response.ok) {
      const errText = await response.text();
      console.error("Gemini API error", response.status, errText);
      return NextResponse.json(
        { error: "AI Mentor is momentarily unavailable. Please try again shortly." },
        { status: 502 },
      );
    }

    const data = await response.json();
    const reply: string =
      data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ??
      "I couldn't generate a response just now — please try rephrasing your question.";

    return NextResponse.json({ reply, demo: false });
  } catch (error) {
    console.error("AI mentor error", error);
    return NextResponse.json(
      { error: "AI Mentor is momentarily unavailable. Please try again shortly." },
      { status: 500 },
    );
  }
}
