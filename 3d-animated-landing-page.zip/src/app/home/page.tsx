import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import HomeDashboard from "@/components/home/HomeDashboard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/auth?mode=login");
  }

  return <HomeDashboard initialName={user.name} initialCoins={user.coins} />;
}
