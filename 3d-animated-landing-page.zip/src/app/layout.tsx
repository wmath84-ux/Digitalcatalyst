import type { Metadata } from "next";
import type { ReactNode } from "react";
import { AuthProvider } from "@/context/AuthContext";
import "./globals.css";

export const metadata: Metadata = {
  title: "Eduvora | Digital Catalyst — Learn. Earn. Evolve.",
  description:
    "Eduvora is your all-in-one digital learning universe — premium PDFs & e-books, interactive video lectures, a Gemini-powered AI mentor, EduCoin rewards, and a seamless marketplace, all wrapped in a cinematic 3D experience.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 antialiased">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
